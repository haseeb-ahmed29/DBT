import { useEffect, useRef, useState } from 'react';
import { Outlet, Link } from 'react-router-dom';
import Brand from '../components/Brand';
import training from '../assets/images/training.png';

export default function AuthLayout() {
  const video = useRef(null);
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = () => {
      if (preference.matches) video.current?.pause();
      else video.current?.play().catch(() => {});
    };
    sync();
    preference.addEventListener('change', sync);
    return () => preference.removeEventListener('change', sync);
  }, []);
  return (
    <main className="auth-layout gym-login">
      <video
        ref={video}
        className="gym-backdrop"
        muted
        loop
        playsInline
        poster={training}
        src="/media/barbell-curl.mp4"
        aria-hidden="true"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      />
      <section className="auth-form-side">
        <Link to="/login" className="brand-link">
          <Brand />
        </Link>
        <div className="auth-form">
          <Outlet />
        </div>
      </section>
      <aside className="gym-caption">
        <h2>
          Build habits.
          <br />
          Feel the change.
        </h2>
        <button
          type="button"
          onClick={() => (playing ? video.current.pause() : video.current.play().catch(() => {}))}
        >
          {playing ? 'Pause' : 'Play'} background
        </button>
        <small>
          Barbell curl · Goulart via wger ·{' '}
          <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>
        </small>
      </aside>
    </main>
  );
}
