"""Refresh the openly licensed English exercise catalogue from the public wger API."""
import html
import json
import re
import urllib.request
from pathlib import Path

BASE = 'https://wger.de/api/v2/'
DEST = Path(__file__).resolve().parents[1] / 'data' / 'training.json'

def pages(endpoint):
    url = BASE + endpoint + '/?limit=1000'
    while url:
        with urllib.request.urlopen(url, timeout=90) as response:
            page = json.load(response)
        yield from page['results']
        url = page['next']

def normalize(rows, licenses):
    def credit(item):
        license_id = item['license']
        if isinstance(license_id, dict):
            license_id = license_id['id']
        lic = licenses[license_id]
        return {'author': ', '.join(dict.fromkeys(filter(None, [item.get('license_author'), *(item.get('author_history') or [])]))) or 'wger contributors',
                'license': lic['short_name'], 'url': lic['url'], 'source':item.get('license_object_url') or '',
                'originalTitle':item.get('license_title') or '', 'authorUrl':item.get('license_author_url') or ''}
    def muscles(values):
        return [m.get('name_en') or m['name'] for m in values]
    result = []
    for row in rows:
        trans = next((t for t in row['translations'] if t['language']==2 and t['name']),None)
        if not trans: continue
        steps = re.split(r'</(?:li|p)>|<br\s*/?>', trans['description'])
        videos = [{'path': v['video'], 'label':'View '+str(i+1), 'credit':credit(v)} for i,v in enumerate(row['videos'])
                  if v['license'] in (1,2,3,4) and v['video'].startswith('https://wger.de/media/')]
        image = next((i for i in row['images'] if i['license'] in (1,2,3,4) and i['image'].startswith('https://wger.de/media/')),None)
        result.append({'id':row['id'],'name':trans['name'],'group':row['category']['name'],'muscles':muscles(row['muscles']),
                       'secondary':muscles(row['muscles_secondary']),'tools':[e['name'] for e in row['equipment']],
                       'steps':[s for x in steps if (s:=html.unescape(re.sub('<[^>]+>','',x)).strip())],
                       'videos':videos,'poster':image['image'] if image else None,'imageCredit':credit(image) if image else None,
                       'credit':credit(trans),'dataCredit':credit(row)})
    return sorted(result,key=lambda x:(not x['videos'],x['name'].casefold()))

if __name__=='__main__':
    rows=normalize(pages('exerciseinfo'),{l['id']:l for l in pages('license')})
    if not rows: raise RuntimeError('Empty catalogue')
    temp=DEST.with_suffix('.tmp')
    temp.write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
    temp.replace(DEST)

    names=sorted({r['name'] for r in rows if len(r['name'])<=100})
    (DEST.parents[2]/'frontend/src/lib/workoutNames.json').write_text(json.dumps(names),encoding='utf-8')
