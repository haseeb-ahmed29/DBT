import { getConfig } from '../src/config/env.js';
import { createEmailService } from '../src/services/email.js';
import mongoose from 'mongoose';

let config;
try { config=getConfig(); } catch { console.error('Check MONGODB_URI, SESSION_SECRET and CLIENT_URL in backend/.env.'); process.exit(1); }
async function check(label,task){
  try {await task(); console.log(label+' OK');}
  catch(err){ console.error(label+' failed ('+(err.code || err.name || 'unavailable')+'). See README.md.');process.exitCode=1; }
}
await Promise.all([
  check('Database connection',async()=>{
    const conn=mongoose.createConnection(config.mongoUri,{serverSelectionTimeoutMS:8000});
    try {await conn.asPromise();await conn.db.command({ping:1});}finally{await conn.close();}
  }),
  check('SMTP connection and authentication',async()=>{const mail=createEmailService(config.smtp);mail.requireConfigured();await mail.verify();}),
  check('Local AI model',async()=>{
    const res=await fetch('http://127.0.0.1:11434/api/tags',{signal:AbortSignal.timeout(6000)});
    if(!res.ok || !(await res.json()).models?.some(m=>m.name===(process.env.OLLAMA_MODEL||'qwen2.5:1.5b'))) throw new Error('Missing model');
  })
]);
