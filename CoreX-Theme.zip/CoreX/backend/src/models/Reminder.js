import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    emailRetryAt: {type:Date, default:null, index:true},
    emailAttempts: {type:Number, default:0},
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: String,
    type: String,
    time: String,
    days: [Number],
    enabled: { type: Boolean, default: true },
    email: { type: Boolean, default: false },
    lastSentDate: String,
    lastEmailAt: Date,
    lastEmailError: { type: String, default: '' }
  },
  { timestamps: true }
);
schema.index({ enabled: 1 });
export default mongoose.model('Reminder', schema);
