import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    emailRetryAt: {type:Date, default:null, index:true},
    emailAttempts: {type:Number, default:0},
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    kind: { type: String, enum: ['session', 'routine'], required: true },
    title: String,
    date: String,
    category: String,
    tags: [String],
    notes: String,
    status: { type: String, enum: ['planned', 'completed'], default: 'completed' },
    duration: Number,
    scheduledTime: { type: String, default: '' },
    reminderEnabled: { type: Boolean, default: false },
    reminderEmail: { type: Boolean, default: true },
    reminderSentAt: { type: Date, default: null },
    reminderEmailError: { type: String, default: '' },
    exercises: [
      {
        name: String,
        sets: Number,
        reps: Number,
        weightKg: Number,
        restSeconds: Number,
        distanceKm: Number,
        minutes: Number,
        notes: String
      }
    ]
  },
  { timestamps: true }
);
schema.index({ userId: 1, kind: 1, date: -1 });
schema.index({ kind: 1, reminderEnabled: 1, reminderSentAt: 1 });
export default mongoose.model('Workout', schema);
