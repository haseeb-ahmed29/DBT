import { Router } from 'express';
import { readFileSync } from 'node:fs';
const catalogue = JSON.parse(
  readFileSync(new URL('../../data/training.json', import.meta.url), 'utf8')
);
const options = (key) => [...new Set(catalogue.flatMap((row) => row[key]))].filter(Boolean).sort();
export default function freeTraining() {
  const router = Router();
  router.get('/filters', (req, res) =>
    res.json({
      muscles: [...new Set([...options('muscles'), ...options('group')])].sort(),
      categories: options('tools'),
      difficulties: []
    })
  );
  router.get('/names', (req, res) => {
    const query = String(req.query.search || '').toLowerCase();
    res.json({
      names: catalogue
        .map((e) => e.name)
        .filter((name) => name.length <= 100 && name.toLowerCase().includes(query))
    });
  });
  router.get('/', (req, res) => {
    const { search = '', category = '', muscles = [], page = '1' } = req.query;
    if (!Number.isSafeInteger(Number(page)) || Number(page) < 1)
      return res.status(400).json({ message: 'Invalid page.' });
    const groups = [].concat(muscles);
    const rows = catalogue.filter(
      (e) =>
        e.name.toLowerCase().includes(String(search).toLowerCase()) &&
        (!category || e.tools.includes(category)) &&
        (!groups.length || [e.group, ...e.muscles].some((m) => groups.includes(m)))
    );
    const pageSize = 8,
      offset = (Number(page) - 1) * pageSize;
    res.json({
      page: Number(page),
      pageSize,
      total: rows.length,
      exercises: rows
        .slice(offset, offset + pageSize)
        .map((e) => ({ ...e, equipment: e.tools.join(', ') }))
    });
  });
  return router;
}
