import mongoose from 'mongoose';
import User from '../models/User.js';
import Workout from '../models/Workout.js';
import Meal from '../models/Meal.js';
import Progress from '../models/Progress.js';
import Reminder from '../models/Reminder.js';
import Notification from '../models/Notification.js';
import AuthToken from '../models/AuthToken.js';
import SupportTicket from '../models/SupportTicket.js';
import { Follow, Post, Reply } from '../models/Community.js';
import { ApiError, requireResult } from '../utils/errors.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { publicUser } from './authController.js';

export function userController({ media }) {
  return {
    profile: async (req, res) => {
      const { name, username, email, currentPassword, discoverable } = req.body;
      const changingEmail = email !== req.user.email;
      if (changingEmail) {
        const stored = await User.findById(req.user._id).select('+passwordHash');
        if (!currentPassword || !(await verifyPassword(currentPassword, stored.passwordHash)))
          throw new ApiError(400, 'Enter your current password to change your email.');
      }
      const changes = { name, username, email, discoverable };
      const user = await User.findByIdAndUpdate(req.user._id, changes, { new: true });
      res.json({ user: publicUser(user), message: 'Profile saved.' });
    },
    theme: async (req,res) => {
      await User.updateOne({_id:req.user._id},{$set:{'settings.theme':req.body.theme}});
      res.json({theme:req.body.theme});
    },
    preferences: async (req, res) => {
      const { goals, ...settings } = req.body;
      const user = await User.findByIdAndUpdate(req.user._id, { settings, goals }, { new: true });
      res.json({ user: publicUser(user), message: 'Preferences saved.' });
    },
    password: async (req, res) => {
      const user = await User.findById(req.user._id).select('+passwordHash');
      if (!(await verifyPassword(req.body.currentPassword, user.passwordHash)))
        throw new ApiError(400, 'Your current password is incorrect.');
      const updated = await User.findOneAndUpdate(
        { _id: user._id, sessionVersion: user.sessionVersion },
        {
          $set: { passwordHash: await hashPassword(req.body.newPassword) },
          $inc: { sessionVersion: 1 }
        },
        { new: true }
      );
      if (!updated)
        throw new ApiError(409, 'Your password was changed in another session. Sign in again.');
      req.session.version = updated.sessionVersion;
      await AuthToken.deleteMany({ userId: user._id, purpose: 'reset' });
      res.json({ message: 'Password changed. Other sessions have been signed out.' });
    },
    uploadAvatar: async (req, res) => {
      const avatar = await media.uploadAvatar(req.file, req.user._id.toString());
      let previous;
      try {
        previous = requireResult(await User.findByIdAndUpdate(req.user._id, { avatar }));
      } catch (error) {
        await media.remove(avatar.publicId).catch(() => {});
        throw error;
      }
      await media
        .remove(previous.avatar?.publicId)
        .catch(() => console.error('Old avatar cleanup failed.'));
      const user = await User.findById(req.user._id);
      res.json({ user: publicUser(user), message: 'Profile photo updated.' });
    },
    avatar: async (req, res) => {
      const user = requireResult(await User.findById(req.params.id));
      if (user.id !== req.user.id && !user.discoverable)
        throw new ApiError(404, 'Profile photo not found.');
      if (!user.avatar?.publicId) throw new ApiError(404, 'Profile photo not found.');
      const image = await media.read(user.avatar);
      res.set('Cache-Control', 'private, no-store').type('webp').send(image);
    },
    deleteAvatar: async (req, res) => {
      const previous = await User.findByIdAndUpdate(req.user._id, { $unset: { avatar: '' } });
      await media
        .remove(previous.avatar?.publicId)
        .catch(() => console.error('Avatar cleanup failed.'));
      const user = await User.findById(req.user._id);
      res.json({ user: publicUser(user), message: 'Photo removed.' });
    },
    deleteAccount: async (req, res) => {
      const user = await User.findById(req.user._id).select('+passwordHash');
      if (!(await verifyPassword(req.body.password || '', user.passwordHash)))
        throw new ApiError(400, 'Your password is incorrect.');
      await mongoose.connection.transaction(async (session) => {
        // Serial operations are intentional inside a MongoDB transaction.
        for (const model of [
          Workout,
          Meal,
          Progress,
          Reminder,
          Notification,
          AuthToken,
          SupportTicket
        ]) {
          await model.deleteMany({ userId: user._id }, { session });
        }
        const posts = await Post.find({ userId: user._id }).select('_id').session(session);
        await Reply.deleteMany(
          { $or: [{ userId: user._id }, { postId: { $in: posts.map((post) => post._id) } }] },
          { session }
        );
        await Post.deleteMany({ userId: user._id }, { session });
        await Follow.deleteMany(
          { $or: [{ follower: user._id }, { following: user._id }] },
          { session }
        );
        await User.deleteOne({ _id: user._id }, { session });
      });
      await media
        .remove(user.avatar?.publicId)
        .catch(() => console.error('Deleted account avatar cleanup failed.'));
      req.session.destroy(() => {});
      res
        .clearCookie('corex.sid', { path: '/' })
        .json({ message: 'Your account and personal records have been deleted.' });
    }
  };
}
