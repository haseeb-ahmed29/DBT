import PDFDocument from 'pdfkit';
export function csvCell(value) {
  let text = value == null ? '' : String(value);
  // Prevent spreadsheet formula execution, including whitespace-prefixed formulas.
  if (/^[\s]*[=+@\-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}
export function toCsv(rows) {
  return '\uFEFF' + rows.map((row) => row.map(csvCell).join(',')).join('\r\n');
}

export function sendPdf(res, rows, user, range) {
  const doc = new PDFDocument({ size: 'A4', margin: 42, bufferPages: true });
  res.type('application/pdf');
  doc.pipe(res);
  const widths = [65, 65, 110, 47, 224];
  let y;
  function header(first = false) {
    doc.rect(0, 0, 596, 98).fill('#18252D');
    doc.font('Helvetica-Bold').fontSize(25).fillColor('#FF987E').text('CoreX', 42, 28);
    doc.fontSize(10).fillColor('#FFFFFF').text('PERSONAL FITNESS REPORT', 42, 61);
    doc.font('Helvetica').fontSize(9).text(range, 310, 34, { width: 243, align: 'right' });
    y = 122;
    if (first) {
      doc
        .font('Helvetica-Bold')
        .fontSize(18)
        .fillColor('#18252D')
        .text(user.name, 42, y, { width: 511 });
      y = doc.y + 14;
      const counts = ['Workout', 'Nutrition', 'Progress'].map(
        (type) => rows.slice(1).filter((row) => row[0] === type).length
      );
      ['Workout records', 'Nutrition records', 'Progress records'].forEach((label, i) => {
        const x = 42 + i * 174;
        doc.roundedRect(x, y, 163, 65, 6).fill('#F1F5F4');
        doc
          .font('Helvetica-Bold')
          .fontSize(21)
          .fillColor('#18252D')
          .text(String(counts[i]), x + 12, y + 10, { width: 139 });
        doc
          .font('Helvetica')
          .fontSize(9)
          .fillColor('#58656B')
          .text(label, x + 12, y + 40, { width: 139 });
      });
      y += 85;
      doc
        .fontSize(9)
        .fillColor('#58656B')
        .text(
          'Recorded activity • Metric units • Generated ' + new Date().toISOString().slice(0, 10),
          42,
          y
        );
      y += 28;
    }
    doc.rect(42, y, 511, 26).fill('#18252D');
    let x = 42;
    rows[0].forEach((label, i) => {
      doc
        .font('Helvetica-Bold')
        .fontSize(8)
        .fillColor('#FFFFFF')
        .text(String(label), x + 6, y + 8, { width: widths[i] - 12 });
      x += widths[i];
    });
    y += 26;
  }
  function lines(value, width) {
    const words = String(value ?? '').split(/\s+/),
      result = [];
    let line = '';
    for (const word of words) {
      // Split long unbroken values too, so user-entered text cannot escape a cell.
      for (const char of (line ? ' ' : '') + word) {
        if (doc.widthOfString(line + char) > width) {
          result.push(line);
          line = '';
        }
        line += char;
      }
    }
    if (line || !result.length) result.push(line);
    return result;
  }
  header(true);
  if (rows.length === 1)
    doc
      .fontSize(12)
      .fillColor('#58656B')
      .text('No records in this date range.', 42, y + 24);
  rows.slice(1).forEach((row, index) => {
    doc.font('Helvetica').fontSize(8);
    const cells = row.map((value, i) => lines(value, widths[i] - 12));
    const count = Math.max(...cells.map((cell) => cell.length));
    let offset = 0;
    while (offset < count) {
      if (y + 28 > 755) {
        doc.addPage();
        header();
      }
      const take = Math.min(count - offset, Math.floor((755 - y - 12) / 12));
      const height = take * 12 + 12;
      doc.rect(42, y, 511, height).fill(index % 2 ? '#FFFFFF' : '#F1F5F4');
      let x = 42;
      cells.forEach((cell, i) => {
        doc.font('Helvetica').fontSize(8).fillColor('#24343C');
        cell
          .slice(offset, offset + take)
          .forEach((line, j) => doc.text(line, x + 6, y + 6 + j * 12, { lineBreak: false }));
        x += widths[i];
      });
      y += height;
      offset += take;
      if (offset < count) {
        doc.addPage();
        header();
      }
    }
  });
  const pages = doc.bufferedPageRange();
  for (let page = 0; page < pages.count; page++) {
    doc.switchToPage(page);
    doc.moveTo(42, 780).lineTo(553, 780).strokeColor('#DCE3E3').stroke();
    doc
      .font('Helvetica')
      .fontSize(8)
      .fillColor('#58656B')
      .text('CoreX • Personal activity records', 42, 795, { lineBreak: false });
    doc.text(page + 1 + ' / ' + pages.count, 500, 795, { lineBreak: false });
  }
  doc.end();
}
