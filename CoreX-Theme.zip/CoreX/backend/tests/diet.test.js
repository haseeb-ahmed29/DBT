import test from 'node:test';
import assert from 'node:assert/strict';
import { dietSchema, generateDiet } from '../src/routes/dietRoutes.js';

const profile = {
  weightKg: 75,
  heightCm: 175,
  age: 30,
  goal: 'Maintain weight',
  activity: 'Lightly active',
  preference: 'Vegetarian',
  allergies: 'Peanuts',
  eligible: true,
  consent: true
};
test('Diet guide validates adult eligibility and explicit sharing consent', () => {
  assert.equal(dietSchema.parse(profile).weightKg, 75);
  for (const input of [
    { age: 17 },
    { consent: false },
    { eligible: false },
    { weightKg: Infinity }
  ])
    assert.equal(dietSchema.safeParse({ ...profile, ...input }).success, false);
});
test('Local guide sends the confirmed profile to Ollama and rejects incomplete or missing models',async()=>{
  const result=await generateDiet(profile,async(url,options)=>{
    assert.equal(url,'http://127.0.0.1:11434/api/chat');
    const body=JSON.parse(options.body);
    assert.equal(JSON.parse(body.messages[1].content).allergies,'Peanuts');
    return Response.json({done:true,message:{content:'Test guide'}});
  });
  assert.equal(result.guide,'Test guide');
  await assert.rejects(generateDiet(profile,async()=>new Response(null,{status:404})),{status:503});
  await assert.rejects(generateDiet(profile,async()=>Response.json({done:false})),{status:502});
});
