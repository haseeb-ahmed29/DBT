import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import request from 'supertest';
import freeTraining from '../src/routes/freeTraining.js';

test('Free catalogue supports complete pages, name search and inline licensed media',async()=>{
 const app=express();app.use(freeTraining());
 const {body:first}=await request(app).get('/').expect(200);
 const {body:last}=await request(app).get('/?page='+Math.ceil(first.total/first.pageSize)).expect(200);
 assert.ok(last.exercises.length);
 const {body}=await request(app).get('/?search=Biceps%20Curls%20With%20Barbell').expect(200);
 assert.ok(body.exercises.some(e=>e.videos.some(v=>v.path.startsWith('https://wger.de/media/') && v.credit.url)));
 assert.ok((await request(app).get('/names')).body.names.length>100);
 await request(app).get('/?page=-1').expect(400);
});
