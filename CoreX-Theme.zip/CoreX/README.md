# CoreX • Fitness Tracker

## Local setup

Node.js 22.12+ aur MongoDB chahiye. ZIP extract karke CoreX folder mein terminal kholein. Apni existing database configuration aur session secret backend/.env mein rakhein. Fresh setup mein backend/.env.example ko backend/.env ke naam se copy karein. Windows PowerShell mein:

```powershell
Copy-Item backend/.env.example backend/.env
npm ci
npm run dev
```

Browser mein http://localhost:5173 kholein. Existing backend/.env ho to copy step skip karein. Production build ke liye npm run build aur npm start use karein. Production mein CLIENT_URL ko deployed origin par set karein. Server aur database ko reminders ke waqt running rehna chahiye.

## Free services aur setup links

| Feature | Kahan se aur kaise |
|---|---|
| Exercise catalogue aur videos | Public wger API key ke baghair exercise data deta hai. Project mein 979 English exercises ki copy hai. 92 ke paas licensed clips hain. Search, filters aur workout names local data se chalte hain. Training videos detail view mein play hoti hain. Remote media ke liye internet chahiye. [wger API docs](https://wger.readthedocs.io/en/latest/api/api.html) |
| AI diet guide | CoreX chalane wale computer/server par [Ollama download](https://ollama.com/download) install karein. Terminal mein `ollama pull qwen2.5:1.5b` chalayein. Ollama app running rakhein, ya service chalane ke liye `ollama serve` use karein. CoreX localhost port 11434 par model ko call karta hai. Model locally chalta hai, API key aur per-request provider charge ki zarurat nahi. Pehli download ko internet, disk aur inference ke liye RAM chahiye. [Model](https://ollama.com/library/qwen2.5:1.5b) · [Local API](https://docs.ollama.com/api/chat) |
| Gmail reminder email | [Google 2-Step Verification](https://myaccount.google.com/security) enable karein. Phir [App passwords](https://myaccount.google.com/apppasswords) se CoreX ke liye app password banayein. Ye option eligible Google accounts mein available hai. Gmail sending limits apply hoti hain. [Google instructions](https://support.google.com/accounts/answer/185833) |
| User accounts aur records | Existing MongoDB URI reuse karein. Free Atlas cluster ke liye [Atlas free cluster guide](https://www.mongodb.com/docs/atlas/tutorial/deploy-free-tier-cluster/) dekhein. Database user banayein aur deployment IP allow karein. URI ko MONGODB_URI mein rakhein. Account-deletion transactions ke liye replica set chahiye. |
| Profile images (optional) | Existing Cloudinary settings reuse karein ya [Cloudinary free plan](https://cloudinary.com/pricing) se cloud name, API key aur secret backend/.env mein copy karein. |

OpenAI aur MuscleWiki keys is version mein use nahi hoti. Aapke uploaded ZIP mein private credentials the. Updated ZIP mein sirf examples hain. Agar uploaded ZIP aapne kisi aur ko diya hai to shared credentials replace karein.

## Backend environment

```dotenv
NODE_ENV=development
PORT=5000
CLIENT_URL=http://localhost:5173
MONGODB_URI=
SESSION_SECRET=
OLLAMA_MODEL=qwen2.5:1.5b
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_REQUIRE_TLS=true
SMTP_USER=
SMTP_PASS=
SMTP_FROM=
SUPPORT_EMAIL=
```

SMTP_USER mein poora Gmail address, SMTP_PASS mein app password aur SMTP_FROM mein wahi Gmail address ya verified alias likhein. SUPPORT_EMAIL support tickets ka destination hai. Reminder email signed-in account ke address par jati hai. Env change ke baad backend restart karein. Session secret generate karne ke liye `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` use karein.

Project root se `node backend/scripts/check-local-services.js` chalane par database ping, SMTP authentication aur installed local model verify honge. Ye command email send nahi karti. Server startup par bhi SMTP verification ka result terminal mein milta hai.

## Workout reminders

1. Settings → Preferences mein timezone aur reminder/email preferences check karein.
2. Log workout mein naam aur exercise select karein. “Schedule workout notification & reminder” enable karke future date aur local time choose karein. Email chahiye to “Also send reminder email” select karein aur workout save karein.
3. Dashboard mein interaction se audio unlock hota hai. Sound button mute/unmute karta hai. Open, active tab mein worker aur dashboard har 5 seconds check karte hain. Browser autoplay restrictions, suspended tabs, mute settings aur device sleep sound ko rok sakte hain. Browser band hone par server email bhej sakta hai jab server aur database online hon.
4. Temporary SMTP failure par worker backoff ke saath paanch retries tak karta hai. Scheduled workouts ka catch-up window 24 hours aur recurring reminder ka window uska local calendar day hai. SMTP acceptance ke baad actual delivery Gmail par depend karti hai. Inbox aur Spam dono dekhein.

## Forms and media

Workout aur routine title dropdown mein named sessions aur exercise catalogue hai. Exercise, food, portion aur body weight mein custom entry available hai. Foods aur quantities select karne ke baad apne serving label ke mutabiq calories aur macros enter karein. Diet guide mein age, activity, goal, preference aur feet/inches select karein. Decimal weight ke liye custom weight choose karein. Height ko backend calculation ke liye internally cm mein convert kiya jata hai.

Login background aur Training barbell-curl demonstration ka source Goulart via wger hai. Bundled clip has been resized and re-encoded; the adapted clip is distributed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Original clip](https://wger.de/media/exercise-video/91/1dc0dbef-ae06-4938-991a-65c24cde5c38.mp4). Reduced-motion preference pauses automatic login playback. Each wger entry retains source authors and individual licences in backend/data/training.json. Catalogue changes include English selection, normalized fields, and conversion of instructions to plain text. Preserve the original data and media licences when redistributing. Refresh with Python 3.8+ using `python backend/scripts/refresh-training.py` at project root, then rebuild the frontend and restart the server.

## Local checks

Use `npm run check` for backend syntax and production build, and `npm test` for the complete backend suite. MongoDB integration tests launch a temporary replica set. In the build environment, the OS blocked the MongoDB binary during startup. HTTP contract tests instead used the existing isolated model harness and a real local SMTP test inbox. Gmail login, real inbox placement, personal Atlas/Cloudinary account access and actual local model inference require checks on your configured machine. No personal database records were written during testing.

Local browser run also verified account registration, workout save, food/portion selectors, 5 ft 9 in to 175.26 cm conversion, muted inline playback, and scheduled five-note Web Audio playback events. The unit, service, HTTP contract, diet and training suites passed 38 tests, including SMTP recovery without duplicate in-app notifications. Twenty real-MongoDB integration tests were blocked at replica set startup. The provided Gmail host and port matched STARTTLS configuration, and app-password spaces are now normalized. The live SMTP hostname could not be resolved from this environment. Private MongoDB and Cloudinary connectivity checks were also blocked here. These results do not establish personal credential validity.
