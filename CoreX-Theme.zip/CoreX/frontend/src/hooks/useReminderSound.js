import { useEffect, useRef, useState } from 'react';

export function useReminderSound(userId) {
  const context = useRef(null);
  const [enabled, setEnabled] = useState(false);
  const [error, setError] = useState('');
  useEffect(
    () => () => {
      context.current?.close().catch(() => {});
    },
    []
  );
  useEffect(() => {
    setEnabled(false);
    setError('');
  }, [userId]);
  useEffect(() => {
    // Browser audio must be unlocked during a real user gesture on each visit.
    const unlock = (event) => {
      if (
        event.target?.closest?.('[data-sound-toggle]') ||
        localStorage.getItem('corex-muted:' + userId) === 'yes'
      )
        return;
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return;
      context.current ||= new Audio();
      context.current
        .resume()
        .then(() => setEnabled(context.current?.state === 'running'))
        .catch(() => {});
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [userId]);
  function play(workout = false) {
    const audio = context.current;
    if (!audio || audio.state !== 'running') return;
    (workout ? [392, 493.88, 587.33, 783.99, 587.33] : [523.25, 659.25, 783.99, 1046.5]).forEach(
      (frequency, index) => {
        const oscillator = audio.createOscillator(),
          gain = audio.createGain(),
          start = audio.currentTime + index * 0.21;
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.12, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.5);
        oscillator.connect(gain);
        gain.connect(audio.destination);
        oscillator.start(start);
        oscillator.stop(start + 0.54);
        oscillator.onended = () => {
          oscillator.disconnect();
          gain.disconnect();
        };
      }
    );
  }
  async function toggle() {
    if (enabled) {
      localStorage.setItem('corex-muted:' + userId, 'yes');
      setEnabled(false);
      return;
    }
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) throw new Error('Unsupported');
      context.current ||= new Audio();
      await context.current.resume();
      if (context.current.state !== 'running') throw new Error('Blocked');
      localStorage.removeItem('corex-muted:' + userId);
      setEnabled(true);
      setError('');
      play();
    } catch {
      setError('Sound is unavailable in this browser. Try again after interacting with the page.');
    }
  }
  function notify(items) {
    if (!enabled) return;
    let fresh = false;
    for (const item of items.filter((item) => item.type === 'reminder')) {
      const key = 'corex-reminder-sound:' + userId + ':' + item._id;
      try {
        if (localStorage.getItem(key)) continue;
        localStorage.setItem(key, String(Date.now()));
      } catch {
        /* Sound remains available when browser storage is restricted. */
      }
      fresh = true;
    }
    if (fresh) play(items.some((item) => item.type === 'reminder' && item.link === '/workouts'));
  }
  return { enabled, error, toggle, notify };
}
