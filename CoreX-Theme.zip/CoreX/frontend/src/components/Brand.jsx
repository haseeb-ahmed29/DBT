import logo from '../assets/brand/corex-logo.png';

// Both views use the same transparent artwork. The angled crop follows the
// space between the E and X so the X keeps its complete orbit.
export default function Brand({ compact = false }) {
  return <svg className={compact ? 'brand brand-compact' : 'brand'} role="img"
    aria-label="CoreX Fit Track" viewBox={compact ? '1428 40 540 502' : '77 39 1892 521'}>
    <image href={logo} width="2048" height="682"
      style={compact ? {clipPath:'polygon(1490px 39px, 1969px 39px, 1969px 542px, 1428px 542px, 1428px 459px, 1462px 398px, 1495px 280px, 1500px 215px, 1488px 190px)'} : undefined}/>
  </svg>;
}
