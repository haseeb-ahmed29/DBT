import { Moon, Sun } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function ThemeSwitch() {
  const { theme, changeTheme, savingTheme, themeError } = useAuth();
  const dark = theme === 'dark';
  return <div className="appearance-control">
    <button type="button" role="switch" aria-label="Dark mode" aria-checked={dark}
      title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
      aria-disabled={savingTheme} onClick={() => changeTheme(dark ? 'light' : 'dark')}
      className="appearance-switch">
      <span className="appearance-orbit" aria-hidden="true"><Sun/><Moon/></span>
    </button>
    {themeError && <span className="appearance-error" role="alert">{themeError}</span>}
  </div>;
}
