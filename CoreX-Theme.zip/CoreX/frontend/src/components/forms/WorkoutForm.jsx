import NameSelect from './NameSelect';
import catalogueNames from '../../lib/workoutNames.json';
import ExerciseSelect from './ExerciseSelect';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../lib/api';
import { today, nextHalfHourTime, displayValue, storedValue, unit } from '../../lib/format';
import { Button, Field, Select, Check, Textarea, ErrorMessage } from '../UI';
const emptyExercise = () => ({
  name: '',
  sets: 3,
  reps: 10,
  weightKg: 0,
  restSeconds: 0,
  distanceKm: 0,
  minutes: 0,
  notes: ''
});
export default function WorkoutForm({ item, kind, exerciseName = '', onSaved, onClose }) {
  const { user, setUser, services } = useAuth(),
    toast = useToast(),
    units = user.settings.units;
  const [form, setForm] = useState(() =>
    item
      ? {
          ...item,
          scheduledTime: item.scheduledTime || '',
          reminderEnabled: Boolean(item.reminderEnabled),
          reminderEmail: item.reminderEmail !== false,
          tags: item.tags.join(', '),
          exercises: item.exercises.map((e) => ({
            ...e,
            weightKg: displayValue(e.weightKg, 'lift', units),
            distanceKm:
              units === 'imperial' ? Number((e.distanceKm / 1.609344).toFixed(3)) : e.distanceKm
          }))
        }
      : {
          kind,
          title: exerciseName,
          date: today(user.settings.timezone),
          category: 'strength',
          tags: '',
          notes: '',
          status: 'completed',
          duration: 30,
          scheduledTime: '',
          reminderEnabled: false,
          reminderEmail: true,
          exercises: [{ ...emptyExercise(), name: exerciseName }]
        }
  );
  const [busy, setBusy] = useState(false),
    [enablingEmail, setEnablingEmail] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const setExercise = (index, key, value) =>
    setForm((f) => ({
      ...f,
      exercises: f.exercises.map((e, i) => (i === index ? { ...e, [key]: value } : e))
    }));
  function toggleReminder(checked) {
    setForm((current) => ({
      ...current,
      reminderEnabled: checked,
      date:
        checked && !current.scheduledTime && current.date === today(user.settings.timezone)
          ? today(user.settings.timezone, new Date(Date.now() + 30 * 60000))
          : current.date,
      scheduledTime:
        checked && !current.scheduledTime
          ? nextHalfHourTime(user.settings.timezone)
          : current.scheduledTime,
      status: checked && !item?._id && current.status === 'completed' ? 'planned' : current.status
    }));
  }
  async function enableAccountEmail() {
    setEnablingEmail(true);
    try {
      const data = await api('/users/me/preferences', {
        method: 'PATCH',
        body: {
          ...user.settings,
          notifications: { ...user.settings.notifications, email: true },
          goals: user.goals
        }
      });
      setUser(data.user);
      toast('Email notifications enabled for ' + data.user.email);
    } catch (err) {
      toast(err.message, 'danger');
    } finally {
      setEnablingEmail(false);
    }
  }
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const payload = {
        ...form,
        duration: Number(form.duration),
        scheduledTime: form.kind === 'session' && form.reminderEnabled ? form.scheduledTime : '',
        reminderEnabled: form.kind === 'session' ? Boolean(form.reminderEnabled) : false,
        reminderEmail: form.kind === 'session' ? Boolean(form.reminderEmail) : true,
        tags: form.tags
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        exercises: form.exercises.map((exercise) => ({
          ...exercise,
          sets: Number(exercise.sets),
          restSeconds: Number(exercise.restSeconds || 0),
          reps: Number(exercise.reps),
          weightKg: storedValue(exercise.weightKg, 'lift', units),
          distanceKm:
            units === 'imperial'
              ? Number(exercise.distanceKm) * 1.609344
              : Number(exercise.distanceKm),
          minutes: Number(exercise.minutes)
        }))
      };
      await api('/workouts' + (item?._id ? '/' + item._id : ''), {
        method: item?._id ? 'PUT' : 'POST',
        body: payload
      });
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="form-stack">
      <NameSelect
        label={kind === 'routine' ? 'Routine name' : 'Workout name'}
        value={form.title}
        onChange={(name) => set('title', name)}
        choices={[
          'Full body strength',
          'Upper body',
          'Lower body',
          'Push day',
          'Pull day',
          'Leg day',
          'Cardio',
          'HIIT',
          'Mobility',
          'Recovery',
          ...catalogueNames
        ]}
      />
      <div className="form-grid">
        <Field
          label="Date"
          type="date"
          required
          value={form.date}
          onChange={(e) => set('date', e.target.value)}
        />
        <Select
          label="Category"
          value={form.category}
          onChange={(e) => set('category', e.target.value)}
        >
          {['strength', 'cardio', 'mobility', 'other'].map((v) => (
            <option key={v} value={v}>
              {v[0].toUpperCase() + v.slice(1)}
            </option>
          ))}
        </Select>
        <Field
          label="Duration (minutes)"
          type="number"
          min="0"
          max="1440"
          required
          value={form.duration}
          onChange={(e) => set('duration', e.target.value)}
        />
        {kind === 'session' && (
          <Select
            label="Status"
            value={form.status}
            onChange={(e) => set('status', e.target.value)}
          >
            <option value="completed">Completed</option>
            <option value="planned">Planned</option>
          </Select>
        )}
      </div>
      {form.kind === 'session' && (
        <div className="preference-box form-stack">
          <Check checked={form.reminderEnabled} onChange={(e) => toggleReminder(e.target.checked)}>
            Schedule workout notification &amp; reminder
          </Check>
          {form.reminderEnabled && (
            <>
              <div className="form-grid">
                <Field
                  label="Scheduled time"
                  type="time"
                  required
                  value={form.scheduledTime}
                  onChange={(e) => set('scheduledTime', e.target.value)}
                  hint={'Timezone: ' + user.settings.timezone}
                />
              </div>
              <Check
                checked={form.reminderEmail}
                onChange={(e) => set('reminderEmail', e.target.checked)}
              >
                Also send reminder email to {user.email}
              </Check>
              {form.reminderEmail && user.settings?.notifications?.email === false && (
                <div className="alert">
                  Global email notifications are turned off in Preferences.
                  <button
                    type="button"
                    className="text-button"
                    disabled={enablingEmail}
                    onClick={enableAccountEmail}
                  >
                    {enablingEmail ? 'Enabling…' : 'Enable now'}
                  </button>
                </div>
              )}
              {form.reminderEmail && !services.email && (
                <p className="small muted">
                  Note: Server SMTP email delivery is not configured in backend/.env yet; in-app
                  notifications will still be delivered.
                </p>
              )}
            </>
          )}
        </div>
      )}
      <div className="section-heading">
        <h3>Exercises</h3>
        <Button
          type="button"
          tone="quiet"
          disabled={form.exercises.length >= 40}
          onClick={() => set('exercises', [...form.exercises, emptyExercise()])}
        >
          + Add exercise
        </Button>
      </div>
      {form.exercises.map((exercise, index) => (
        <div className="entry-box" key={index}>
          <div className="entry-box-head">
            <strong>Exercise {index + 1}</strong>
            {form.exercises.length > 1 && (
              <button
                type="button"
                className="text-button danger"
                onClick={() =>
                  set(
                    'exercises',
                    form.exercises.filter((_, i) => i !== index)
                  )
                }
              >
                Remove
              </button>
            )}
          </div>
          <ExerciseSelect
            label="Exercise name"
            value={exercise.name}
            onChange={(name) => setExercise(index, 'name', name)}
          />
          <div className="form-grid three">
            {[
              ['sets', 'Sets', 100],
              ['reps', 'Reps', 1000],
              ['restSeconds', 'Rest between sets (seconds)', 86400],
              ['weightKg', 'Weight (' + unit('lift', units) + ')', 100000],
              ['distanceKm', 'Distance (' + (units === 'imperial' ? 'mi' : 'km') + ')', 100000],
              ['minutes', 'Minutes', 1440]
            ].map(([key, label, max]) => (
              <Field
                key={key}
                label={label}
                type="number"
                min="0"
                max={max}
                step={['sets', 'reps', 'restSeconds'].includes(key) ? '1' : 'any'}
                required
                value={exercise[key] ?? 0}
                onChange={(e) => setExercise(index, key, e.target.value)}
              />
            ))}
          </div>
          <Field
            label="Exercise note (optional)"
            value={exercise.notes}
            maxLength={1500}
            onChange={(e) => setExercise(index, 'notes', e.target.value)}
          />
        </div>
      ))}
      <Field
        label="Tags (comma separated, up to 8)"
        value={form.tags}
        onChange={(e) => set('tags', e.target.value)}
        placeholder="upper body, home"
      />
      <Textarea
        label="Session notes"
        maxLength={1500}
        value={form.notes}
        onChange={(e) => set('notes', e.target.value)}
      />
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button type="button" tone="quiet" onClick={onClose}>
          Cancel
        </Button>
        <Button busy={busy} type="submit">
          {item?._id ? 'Save changes' : kind === 'routine' ? 'Save routine' : 'Save workout'}
        </Button>
      </div>
    </form>
  );
}
