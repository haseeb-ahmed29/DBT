import { useState } from 'react';
import { Field, Select } from '../UI';

export default function NameSelect({ label, choices, value, onChange, maxLength = 100 }) {
  const [custom, setCustom] = useState(false);
  const names = [...new Set([value, ...choices].filter(Boolean))];
  return (
    <div className="form-stack">
      <Select
        label={label}
        required
        value={custom ? 'custom' : value ? 'name:' + value : ''}
        onChange={(e) => {
          const next = e.target.value;
          setCustom(next === 'custom');
          onChange(next === 'custom' ? '' : next.slice(5));
        }}
      >
        <option value="" disabled>
          Choose {label.toLowerCase()}
        </option>
        {names.map((name) => (
          <option key={name} value={'name:' + name}>
            {name}
          </option>
        ))}
        <option value="custom">Enter another name…</option>
      </Select>
      {custom && (
        <Field
          label={'Custom ' + label.toLowerCase()}
          required
          maxLength={maxLength}
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
    </div>
  );
}
