import { useEffect, useState } from 'react';
import { Field, Select } from '../UI';
import { api } from '../../lib/api';

const common = [
  'Bench press', 'Biceps curl', 'Burpee', 'Calf raise', 'Chest fly', 'Crunch',
  'Cycling', 'Deadlift', 'Dumbbell row', 'Glute bridge', 'Hip thrust', 'Jump rope',
  'Lat pulldown', 'Lateral raise', 'Leg curl', 'Leg extension', 'Leg press', 'Lunge',
  'Overhead press', 'Plank', 'Pull-up', 'Push-up', 'Romanian deadlift', 'Rowing',
  'Running', 'Seated row', 'Squat', 'Triceps extension', 'Walking'
];

export default function ExerciseSelect({ label, value, onChange }) {
  const [custom, setCustom] = useState(false);
  const [search, setSearch] = useState('');
  const [remote, setRemote] = useState([]);
  const [message, setMessage] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    setRemote([]);
    setMessage('');
    const term = search.trim();
    if (custom) return;
    const timer = setTimeout(async () => {
      try {
        const data = await api('/training/names?search=' + encodeURIComponent(term), { signal: controller.signal });
        if (!controller.signal.aborted) setRemote(data.names);
      } catch {
        if (!controller.signal.aborted) setMessage('Exercise catalogue unavailable. Choose a common exercise or enter a custom name.');
      }
    }, 300);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [search, custom]);
  const names = [...new Set([value, ...common.filter(name => name.toLowerCase().includes(search.trim().toLowerCase())), ...remote].filter(Boolean))];
  return <div className="form-stack">
    {!custom && <Field label="Filter exercise choices" type="search" maxLength={100} value={search} onChange={event => setSearch(event.target.value)} />}
    <Select label={label} required value={custom ? 'custom' : value ? 'name:' + value : ''} onChange={event => {
      const next = event.target.value;
      setCustom(next === 'custom');
      onChange(next.startsWith('name:') ? next.slice(5) : '');
    }}>
      <option value="" disabled>Choose an exercise</option>
      {names.map(name => <option key={name} value={'name:' + name}>{name}</option>)}
      <option value="custom">Enter a custom exercise…</option>
    </Select>
    {custom && <Field label="Custom exercise name" required maxLength={100} value={value} onChange={event => onChange(event.target.value)} />}
    {message && <small role="status">{message}</small>}
  </div>;
}
