import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useData } from '../hooks/useData';
import { useToast } from '../context/ToastContext';
import { api, queryString } from '../lib/api';
import { dateLabel, number } from '../lib/format';
import {
  PageTitle,
  Button,
  Badge,
  Empty,
  Loading,
  ErrorMessage,
  Actions,
  Pagination
} from '../components/UI';
import { TrendChart } from '../components/Charts';
import Modal, { Confirm } from '../components/Modal';
import MealForm from '../components/forms/MealForm';
export default function Meals() {
  const [params, setParams] = useSearchParams(),
    toast = useToast();
  const [page, setPage] = useState(1),
    [filters, setFilters] = useState({ q: '', mealType: '', from: '', to: '' }),
    [editing, setEditing] = useState(null),
    [deleting, setDeleting] = useState(null),
    [busy, setBusy] = useState(false);
  const { data, error, loading, reload } = useData('/meals?' + queryString({ ...filters, page }));
  const summary = useData('/dashboard');
  useEffect(() => {
    if (params.get('new')) {
      setEditing({});
      setParams({}, { replace: true });
    }
  }, [params, setParams]);
  function filter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  }
  function saved() {
    setEditing(null);
    reload();
    summary.reload();
    toast('Meal saved.');
  }
  async function remove() {
    setBusy(true);
    try {
      await api('/meals/' + deleting._id, { method: 'DELETE' });
      setDeleting(null);
      setPage(1);
      reload();
      summary.reload();
      toast('Meal deleted.');
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Link className="button quiet" to="/diet-guide">AI diet guide</Link>
      <PageTitle
        eyebrow="NOURISH YOUR EVERYDAY"
        title="Your meals"
        description="A simple picture of what fuels you."
      >
        <Button onClick={() => setEditing({})}>+ Log meal</Button>
      </PageTitle>
      <section className="card">
        <div className="card-head">
          <div>
            <span className="eyebrow">LAST 30 DAYS</span>
            <h2>Daily calorie intake</h2>
          </div>
          <span className="muted small">From your food entries</span>
        </div>
        {summary.error ? (
          <ErrorMessage message={summary.error} retry={summary.reload} />
        ) : (
          <TrendChart
            data={summary.data?.calories}
            dataKey="calories"
            label="Calories (kcal)"
            height={200}
          />
        )}
      </section>
      <div className="filter-bar">
        <input
          aria-label="Search meals"
          placeholder="Search food…"
          value={filters.q}
          onChange={(e) => filter('q', e.target.value)}
        />
        <select
          aria-label="Meal type"
          value={filters.mealType}
          onChange={(e) => filter('mealType', e.target.value)}
        >
          <option value="">All meals</option>
          {['breakfast', 'lunch', 'dinner', 'snack'].map((v) => (
            <option key={v} value={v}>
              {v[0].toUpperCase() + v.slice(1)}
            </option>
          ))}
        </select>
        <input
          aria-label="From date"
          type="date"
          value={filters.from}
          onChange={(e) => filter('from', e.target.value)}
        />
        <input
          aria-label="To date"
          type="date"
          value={filters.to}
          onChange={(e) => filter('to', e.target.value)}
        />
      </div>
      <ErrorMessage message={error} retry={reload} />
      {loading ? (
        <Loading />
      ) : data?.items.length ? (
        <div className="record-grid">
          {data.items.map((item) => (
            <article className="card" key={item._id}>
              <div className="card-head">
                <Badge>{item.mealType}</Badge>
                <span className="muted small">{dateLabel(item.date)}</span>
              </div>
              <h2 className="meal-calories">
                {number(item.calories)} <small>kcal</small>
              </h2>
              <div className="exercise-list">
                {item.foods.map((food, i) => (
                  <div key={i}>
                    <span>
                      {food.name}
                      <small className="table-sub">{food.quantity}</small>
                    </span>
                    <small>{number(food.calories)} kcal</small>
                  </div>
                ))}
              </div>
              <div className="meal-macros">
                <span>
                  Protein <b>{number(item.protein)}g</b>
                </span>
                <span>
                  Carbs <b>{number(item.carbs)}g</b>
                </span>
                <span>
                  Fat <b>{number(item.fat)}g</b>
                </span>
              </div>
              {item.notes && <p className="record-note">{item.notes}</p>}
              <Actions onEdit={() => setEditing(item)} onDelete={() => setDeleting(item)} />
            </article>
          ))}
        </div>
      ) : (
        !error && (
          <div className="card">
            <Empty title="Your food diary starts here">
              Log a meal to see calories and macros.
            </Empty>
          </div>
        )
      )}
      <Pagination data={data} page={page} setPage={setPage} />
      {editing && (
        <Modal
          wide
          title={editing._id ? 'Edit meal' : 'Log a meal'}
          onClose={() => setEditing(null)}
        >
          <MealForm
            item={editing._id ? editing : null}
            onSaved={saved}
            onClose={() => setEditing(null)}
          />
        </Modal>
      )}
      {deleting && (
        <Confirm
          title="Delete this meal?"
          busy={busy}
          onConfirm={remove}
          onCancel={() => setDeleting(null)}
        >
          This meal and its food entries will be permanently removed.
        </Confirm>
      )}
    </>
  );
}
