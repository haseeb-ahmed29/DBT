import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useData } from '../hooks/useData';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { api, queryString } from '../lib/api';
import { dateLabel, displayValue, unit, today } from '../lib/format';
import {
  PageTitle,
  Button,
  Badge,
  Empty,
  Loading,
  ErrorMessage,
  Actions,
  Pagination
} from '../components/UI';
import Modal, { Confirm } from '../components/Modal';
import WorkoutForm from '../components/forms/WorkoutForm';
export default function Workouts() {
  const [params, setParams] = useSearchParams(),
    { user } = useAuth(),
    toast = useToast();
  const [kind, setKind] = useState('session'),
    [page, setPage] = useState(1),
    [filters, setFilters] = useState({ q: '', category: '', from: '', to: '' }),
    [editing, setEditing] = useState(null),
    [deleting, setDeleting] = useState(null),
    [busy, setBusy] = useState(false);
  const { data, error, loading, reload } = useData(
    '/workouts?' + queryString({ ...filters, kind, page })
  );
  useEffect(() => {
    if (params.get('new')) {
      setEditing({});
      setParams({}, { replace: true });
    }
  }, [params, setParams]);
  function filter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  }
  function saved() {
    setEditing(null);
    reload();
    toast('Workout saved.');
  }
  async function remove() {
    setBusy(true);
    try {
      await api('/workouts/' + deleting._id, { method: 'DELETE' });
      setDeleting(null);
      setPage(1);
      reload();
      toast('Workout deleted.');
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      setBusy(false);
    }
  }
  async function complete(item) {
    try {
      await api('/workouts/' + item._id, {
        method: 'PUT',
        body: {
          ...item,
          tags: item.tags || [],
          notes: item.notes || '',
          exercises: (item.exercises || []).map((e) => ({
            ...e,
            restSeconds: e.restSeconds ?? 0,
            notes: e.notes || ''
          })),
          status: 'completed',
          reminderEnabled: false,
          scheduledTime: ''
        }
      });
      reload();
      toast('Workout completed.');
    } catch (e) {
      toast(e.message, 'danger');
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="MOVE WITH INTENTION"
        title="Your workouts"
        description="Build a routine. Record a session. Keep moving."
      >
        <Button onClick={() => setEditing({})}>
          + {kind === 'routine' ? 'New routine' : 'Log workout'}
        </Button>
      </PageTitle>
      <div className="tabs">
        {[
          ['session', 'Workout log'],
          ['routine', 'My routines']
        ].map(([value, label]) => (
          <button
            key={value}
            className={kind === value ? 'active' : ''}
            onClick={() => {
              setKind(value);
              setPage(1);
            }}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="filter-bar">
        <input
          aria-label="Search workouts"
          placeholder="Search workouts, exercises or tags…"
          value={filters.q}
          onChange={(e) => filter('q', e.target.value)}
        />
        <select
          aria-label="Category"
          value={filters.category}
          onChange={(e) => filter('category', e.target.value)}
        >
          <option value="">All categories</option>
          {['strength', 'cardio', 'mobility', 'other'].map((value) => (
            <option key={value} value={value}>
              {value[0].toUpperCase() + value.slice(1)}
            </option>
          ))}
        </select>
        <input
          aria-label="From date"
          type="date"
          value={filters.from}
          onChange={(e) => filter('from', e.target.value)}
        />
        <input
          aria-label="To date"
          type="date"
          value={filters.to}
          onChange={(e) => filter('to', e.target.value)}
        />
      </div>
      <ErrorMessage message={error} retry={reload} />
      {loading ? (
        <Loading />
      ) : data?.items.length ? (
        <div className="record-grid">
          {data.items.map((item) => (
            <article className="card workout-card" key={item._id}>
              <div className="card-head">
                <div className="badge-row">
                  <Badge>{item.category}</Badge>
                  {item.reminderEnabled && item.scheduledTime && (
                    <Badge tone={item.reminderSentAt ? 'success' : 'neutral'}>
                      {item.reminderSentAt
                        ? 'Reminded ' + item.scheduledTime
                        : 'Scheduled ' + item.scheduledTime}
                    </Badge>
                  )}
                </div>
                {kind === 'session' && (
                  <Badge tone={item.status === 'completed' ? 'success' : 'warning'}>
                    {item.status}
                  </Badge>
                )}
              </div>
              {item.reminderEmailError && (
                <p className="small danger">Reminder email failed: {item.reminderEmailError}</p>
              )}
              <h2>{item.title}</h2>
              <p className="muted">
                {kind === 'session' ? dateLabel(item.date) + ' · ' : ''}
                {item.duration} min · {item.exercises.length} exercises
              </p>
              <div className="exercise-list">
                {item.exercises.map((e, index) => (
                  <div key={index}>
                    <span>{e.name}</span>
                    <small>
                      {e.sets > 0 || e.reps > 0 ? e.sets + ' × ' + e.reps : e.minutes + ' min'}
                      {e.weightKg > 0
                        ? ' · ' +
                          displayValue(e.weightKg, 'lift', user.settings.units) +
                          ' ' +
                          unit('lift', user.settings.units)
                        : ''}
                      {e.restSeconds > 0 && " · " + e.restSeconds + " s rest"}
                      {e.distanceKm > 0
                        ? ' · ' +
                          (user.settings.units === 'imperial'
                            ? (e.distanceKm / 1.609344).toFixed(2) + ' mi'
                            : e.distanceKm + ' km')
                        : ''}
                    </small>
                  </div>
                ))}
              </div>
              {item.tags.length > 0 && (
                <div className="tags">
                  {item.tags.map((tag) => (
                    <span key={tag}>#{tag}</span>
                  ))}
                </div>
              )}
              {item.notes && <p className="record-note">{item.notes}</p>}
              <Actions onEdit={() => setEditing(item)} onDelete={() => setDeleting(item)}>
                {kind === 'routine' ? (
                  <button
                    className="text-button"
                    onClick={() => {
                      setKind('session');
                      setEditing({
                        ...item,
                        _id: undefined,
                        kind: 'session',
                        status: 'completed',
                        date: today(user.settings.timezone)
                      });
                    }}
                  >
                    Log this routine
                  </button>
                ) : (
                  item.status === 'planned' && (
                    <button className="text-button success" onClick={() => complete(item)}>
                      Mark done
                    </button>
                  )
                )}
              </Actions>
            </article>
          ))}
        </div>
      ) : (
        !error && (
          <div className="card">
            <Empty
              title={
                kind === 'routine' ? 'Build your first routine' : 'Ready for your first session?'
              }
            >
              Use the button above to add your exercises, sets and notes.
            </Empty>
          </div>
        )
      )}
      <Pagination data={data} page={page} setPage={setPage} />
      {editing && (
        <Modal
          wide
          title={
            editing._id ? 'Edit workout' : kind === 'routine' ? 'Create a routine' : 'Log a workout'
          }
          onClose={() => setEditing(null)}
        >
          <WorkoutForm
            item={editing.title ? editing : null}
            kind={kind}
            onSaved={saved}
            onClose={() => setEditing(null)}
          />
        </Modal>
      )}
      {deleting && (
        <Confirm
          title="Delete this workout?"
          busy={busy}
          onCancel={() => setDeleting(null)}
          onConfirm={remove}
        >
          “{deleting.title}” will be permanently removed.
        </Confirm>
      )}
    </>
  );
}
