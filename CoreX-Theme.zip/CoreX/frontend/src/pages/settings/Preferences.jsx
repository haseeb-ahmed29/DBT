import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../lib/api';
import { displayValue, storedValue, unit } from '../../lib/format';
import { Button, Field, Select, Check, ErrorMessage } from '../../components/UI';
export default function Preferences() {
  const { user, setUser } = useAuth(),
    toast = useToast();
  const [form, setForm] = useState({
      ...user.settings,
      goals: {
        ...user.goals,
        targetWeight:
          user.goals.targetWeight == null
            ? ''
            : displayValue(user.goals.targetWeight, 'weight', user.settings.units)
      }
    }),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  useEffect(() => {
    setForm(current=>({...current,theme:user.settings.theme}));
  },[user.settings.theme]);
  function set(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }
  function goal(key, value) {
    setForm((f) => ({ ...f, goals: { ...f.goals, [key]: value } }));
  }
  function units(value) {
    setForm((f) => ({
      ...f,
      units: value,
      goals: {
        ...f.goals,
        targetWeight:
          f.goals.targetWeight === ''
            ? ''
            : displayValue(storedValue(f.goals.targetWeight, 'weight', f.units), 'weight', value)
      }
    }));
  }
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const data = await api('/users/me/preferences', {
        method: 'PATCH',
        body: {
          ...form,
          goals: {
            weeklyWorkouts: Number(form.goals.weeklyWorkouts),
            dailyCalories: Number(form.goals.dailyCalories),
            targetWeight:
              form.goals.targetWeight === ''
                ? null
                : storedValue(form.goals.targetWeight, 'weight', form.units)
          }
        }
      });
      setUser(data.user);
      toast(data.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="form-stack" onSubmit={submit}>
      <section className="card">
        <h2>Make it feel like you</h2>
        <div className="form-grid">
          <Select
            label="Measurement units"
            value={form.units}
            onChange={(e) => units(e.target.value)}
          >
            <option value="metric">Metric · kg, cm, km</option>
            <option value="imperial">Imperial · lb, in, mi</option>
          </Select>
          <Select
            label="Appearance"
            value={form.theme}
            onChange={(e) => set('theme', e.target.value)}
          >
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </Select>
        </div>
        <Field
          label="Timezone"
          required
          value={form.timezone}
          onChange={(e) => set('timezone', e.target.value)}
          list="timezones"
          hint="Controls your daily dashboard and scheduled reminders."
        />
        <datalist id="timezones">
          {[
            'Asia/Karachi',
            'Asia/Dubai',
            'Asia/Kolkata',
            'Europe/London',
            'America/New_York',
            'America/Los_Angeles',
            'Australia/Sydney',
            'UTC'
          ].map((zone) => (
            <option key={zone}>{zone}</option>
          ))}
        </datalist>
      </section>
      <section className="card">
        <h2>Your personal goals</h2>
        <p className="muted">
          Choose targets that suit you. These values organize your tracking; they are not medical
          recommendations.
        </p>
        <div className="form-grid">
          <Field
            label="Workouts per week"
            type="number"
            min="1"
            max="30"
            required
            value={form.goals.weeklyWorkouts}
            onChange={(e) => goal('weeklyWorkouts', e.target.value)}
          />
          <Field
            label="Daily calorie target (kcal)"
            type="number"
            min="1"
            max="20000"
            required
            value={form.goals.dailyCalories}
            onChange={(e) => goal('dailyCalories', e.target.value)}
          />
          <Field
            label={'Target weight (' + unit('weight', form.units) + ') · optional'}
            type="number"
            min="1"
            step="any"
            value={form.goals.targetWeight}
            onChange={(e) => goal('targetWeight', e.target.value)}
          />
        </div>
        <div className="status-legend">
          <span className="success">Green · Closer to your target</span>
          <span className="warning">Yellow · Holding steady</span>
          <span className="danger">Red · Further from your target</span>
        </div>
      </section>
      <section className="card">
        <h2>Notifications</h2>
        <div className="preference-list">
          {[
            ['workout', 'Workout completion'],
            ['goal', 'Weekly workout goal achieved'],
            ['reminder', 'Scheduled reminders'],
            ['follow', 'New community followers'],
            ['forum', 'Replies to your posts'],
            ['email', 'Email reminders & scheduled workout notifications']
          ].map(([key, label]) => (
            <Check
              key={key}
              checked={form.notifications[key]}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  notifications: { ...f.notifications, [key]: e.target.checked }
                }))
              }
            >
              {label}
            </Check>
          ))}
        </div>
      </section>
      <ErrorMessage message={error} />
      <div className="form-footer">
        <Button busy={busy} type="submit">
          Save preferences
        </Button>
      </div>
    </form>
  );
}
