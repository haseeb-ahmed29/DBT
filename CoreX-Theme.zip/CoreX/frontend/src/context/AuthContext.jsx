import { createContext, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { api, setCsrf } from '../lib/api';
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(''),
    [services, setServices] = useState({});
  const [guestTheme,setGuestTheme] = useState(() => {
    try {
      const stored=localStorage.getItem('corex-appearance');
      if(stored==='dark' || stored==='light')return stored;
    } catch { /* Storage can be disabled in private browsing. */ }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });
  const [pendingTheme,setPendingTheme]=useState(null), [themeError,setThemeError]=useState('');
  const saving=useRef(false);
  const theme = pendingTheme || user?.settings?.theme || guestTheme;
  useLayoutEffect(()=>{
    document.documentElement.dataset.theme=theme;
    document.documentElement.style.colorScheme=theme;
  },[theme]);
  function remember(value){
    setGuestTheme(value);
    try { localStorage.setItem('corex-appearance',value); } catch { /* Session-only appearance. */ }
  }
  async function changeTheme(next) {
    if(saving.current)return;
    setThemeError('');
    if(!user){remember(next);return;}
    saving.current=true;
    setPendingTheme(next);
    try {
      await api('/users/me/theme',{method:'PATCH',body:{theme:next}});
      setUser(current=>current?._id===user._id ? {...current,settings:{...current.settings,theme:next}} : current);
      remember(next);
    } catch {setThemeError('Could not save appearance. Try again.');}
    finally {saving.current=false;setPendingTheme(null);}
  }
  async function refresh() {
    setError('');
    try {
      const data = await api('/auth/session');
      setUser(data.user);
      setServices(data.services);
      return data;
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    refresh();
    const expire = () => {
      setUser(null);
      refresh();
    };
    window.addEventListener('corex-session-expired', expire);
    return () => window.removeEventListener('corex-session-expired', expire);
  }, []);
  async function authenticate(path, body) {
    const data = await api('/auth/' + path, { method: 'POST', body });
    setUser(data.user);
    return data;
  }
  async function logout() {
    await api('/auth/logout', { method: 'POST' });
    setUser(null);
    setCsrf('');
    await refresh();
  }
  return (
    <AuthContext.Provider
      value={{ user, setUser, loading, error, services, refresh, authenticate, logout, theme, changeTheme, savingTheme:Boolean(pendingTheme), themeError }}
    >
      {children}
    </AuthContext.Provider>
  );
}
export const useAuth = () => useContext(AuthContext);
