# Diet guidance, reminder sound and report template

## Use the features

Open Meals and choose AI diet guide. Enter weight in kg, height in cm, age, activity, fitness goal, food preference and allergens. Eligible adults can explicitly consent to sending these form values to the locally hosted Ollama model. The returned guide is displayed inside the dashboard with a shortcut to log a meal. Profile identifiers, email addresses and historical records are not sent. The guide is held in page memory and clears when its inputs change or the page is left.

Click Enable sound in the dashboard header. A short three-note tune confirms activation. Newly received reminders then play the tune. Click Sound on to disable it. After a reload, interact with the page to unlock browser audio. Reminder polling runs every 5 seconds while the dashboard is active. Initial historical notifications stay silent. The browser may suspend background tabs, and closing the browser stops in-page audio. Existing email reminders remain configured through SMTP.

Download a PDF from Settings → Reports. The new template contains a CoreX header, owner and date range, record counts, alternating table rows, repeated column headings and page numbers. Long entries continue across pages. Rest time is included in workout exports. Counts reflect recorded entries, including planned sessions and routines.


See the project root README.md for the current free providers and service checks.
