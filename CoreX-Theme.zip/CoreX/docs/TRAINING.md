# Training

Training uses the wger catalogue and licensed inline videos. See the project root README.md for coverage, credits, and catalogue refresh instructions.
