import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';

dotenv.config({ path: fileURLToPath(new URL('../../.env', import.meta.url)), quiet: true });

export function cleanEnv(value) {
  if (typeof value !== 'string') return value;
  let cleaned = value.trim();
  if (
    (cleaned.startsWith('"') && cleaned.endsWith('"')) ||
    (cleaned.startsWith("'") && cleaned.endsWith("'"))
  ) {
    cleaned = cleaned.slice(1, -1).trim();
  }
  return cleaned;
}

export function getConfig(overrides = {}) {
  const rawClientUrl = cleanEnv(process.env.CLIENT_URL) || 'http://localhost:5173';
  const config = {
    nodeEnv: cleanEnv(process.env.NODE_ENV) || 'development',
    port: Number(cleanEnv(process.env.PORT) || 5000),
    clientUrl: rawClientUrl.replace(/\/+$/, ''),
    mongoUri: cleanEnv(process.env.MONGODB_URI) || '',
    sessionSecret: cleanEnv(process.env.SESSION_SECRET) || '',
    cloudinary: {
      cloud_name: cleanEnv(process.env.CLOUDINARY_CLOUD_NAME),
      api_key: cleanEnv(process.env.CLOUDINARY_API_KEY),
      api_secret: cleanEnv(process.env.CLOUDINARY_API_SECRET)
    },
    smtp: {
      host: cleanEnv(process.env.SMTP_HOST),
      port: Number(cleanEnv(process.env.SMTP_PORT) || 587),
      secure: cleanEnv(process.env.SMTP_SECURE) === 'true',
      requireTLS: cleanEnv(process.env.SMTP_REQUIRE_TLS) !== 'false',
      user: cleanEnv(process.env.SMTP_USER),
      pass: cleanEnv(process.env.SMTP_PASS),
      from: cleanEnv(process.env.SMTP_FROM),
      supportEmail: cleanEnv(process.env.SUPPORT_EMAIL)
    },
    openai: {
      apiKey: cleanEnv(process.env.OPENAI_API_KEY) || '',
      model: cleanEnv(process.env.OPENAI_MODEL) || 'gpt-4.1-mini'
    },
    musclewiki: {
      apiKey: cleanEnv(process.env.MUSCLEWIKI_API_KEY) || ''
    },
    ...overrides
  };
  config.clientUrl = String(config.clientUrl || 'http://localhost:5173').replace(/\/+$/, '');
  if (!config.mongoUri || config.mongoUri.includes('YOUR_')) {
    throw new Error('Add your MongoDB Atlas connection string to backend/.env MONGODB_URI.');
  }
  if (config.sessionSecret.length < 32) {
    throw new Error(
      'Set SESSION_SECRET in backend/.env to a random value of at least 32 characters.'
    );
  }
  new URL(config.clientUrl);
  return config;
}
