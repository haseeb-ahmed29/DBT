import mongoose from 'mongoose';
import { getConfig } from './config/env.js';
import { connectDatabase } from './config/database.js';
import { createApp } from './app.js';
import { getLocalLanIps } from './middleware/auth.js';
import { startReminderWorker } from './services/reminders.js';

try {
  const config = getConfig();
  await connectDatabase(config.mongoUri);
  const { app, email, media, store } = createApp(config);
  // Wait for unique username/email and token indexes before accepting registrations.
  await Promise.all(Object.values(mongoose.models).map((model) => model.init()));
  console.log(
    'CoreX services:',
    JSON.stringify({
      media: media.enabled,
      email: email.enabled,
      ai: Boolean(config.openai?.apiKey),
      training: Boolean(config.musclewiki?.apiKey),
      clientUrl: config.clientUrl
    })
  );
  if (email.enabled) {
    email
      .verify()
      .then(() => console.log('SMTP transport verified.'))
      .catch((error) =>
        console.error('SMTP verification warning:', error?.code || '', error?.message || error)
      );
  }
  const stopReminders = startReminderWorker(email, config.clientUrl);
  const server = app.listen(config.port, '0.0.0.0', () => {
    console.log('CoreX API ready at http://127.0.0.1:' + config.port + ' (bound to 0.0.0.0)');
    const lanIps = getLocalLanIps();
    const webPort = new URL(config.clientUrl).port || '5173';
    if (lanIps.length) {
      console.log(
        'Mobile / LAN access URLs: ' +
          lanIps.map((ip) => 'http://' + ip + ':' + webPort).join(', ')
      );
    }
  });
  async function shutdown() {
    stopReminders();
    server.close(async () => {
      await store.close();
      await mongoose.disconnect();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  }
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
} catch (error) {
  console.error('CoreX could not start: ' + error.message);
  process.exit(1);
}
