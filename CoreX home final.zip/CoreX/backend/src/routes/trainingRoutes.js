import { Router } from 'express';
import { z } from 'zod';
import { cleanEnv } from '../config/env.js';
import { ApiError } from '../utils/errors.js';

const origin = 'https://api.musclewiki.com';
const pageSize = 8;
const filter = z.string().trim().max(100).optional();
const searchSchema = z.object({
  search: filter,
  muscles: z.union([filter, z.array(z.string().max(100)).max(50)]),
  category: filter,
  difficulty: filter,
  page: z.coerce.number().int().min(1).max(100000).default(1)
});

function mediaPath(raw, prefix) {
  if (!raw) return null;
  try {
    const url = new URL(raw, origin);
    return url.origin === origin && url.pathname.startsWith(prefix) ? url.pathname : null;
  } catch {
    return null;
  }
}

export default function trainingRoutes(
  request = fetch,
  key = () => cleanEnv(process.env.MUSCLEWIKI_API_KEY)
) {
  const router = Router(),
    cache = new Map(),
    pending = new Map();
  let retryAt = 0;
  router.use((req, res, next) => {
    res.set('Cache-Control', 'private, no-store');
    next();
  });
  async function load(path, method = 'GET') {
    const apiKey = cleanEnv(key());
    if (!apiKey)
      throw new ApiError(
        503,
        'Training needs a MuscleWiki API key. Contact your dashboard administrator.'
      );
    if (method === 'GET' && cache.get(path)?.until > Date.now()) return cache.get(path).value;
    if (retryAt > Date.now())
      throw new ApiError(429, 'Exercise provider limit reached. Try again later.');
    if (method === 'GET' && pending.has(path)) return pending.get(path);
    const job = (async () => {
      const res = await request(origin + path, {
        method,
        headers: { 'X-API-Key': apiKey },
        redirect: 'error',
        signal: AbortSignal.timeout(12000)
      }).catch(() => {
        throw new ApiError(502, 'Exercise provider is unreachable. Please retry.');
      });
      if (res.status === 429) {
        const after = res.headers.get('retry-after');
        const delay =
          after && !isNaN(after) ? Number(after) * 1000 : Date.parse(after) - Date.now();
        retryAt = Date.now() + Math.max(1000, delay || 60000);
        throw new ApiError(429, 'Exercise provider limit reached. Try again later.');
      }
      if (!res.ok) {
        const errBody = await res.json().catch(() => null);
        const detail = errBody?.detail || errBody?.message || '';
        console.error(
          JSON.stringify({
            level: 'error',
            service: 'musclewiki',
            path,
            status: res.status,
            message: detail || 'MuscleWiki request failed'
          })
        );
        if ([401, 403].includes(res.status)) {
          throw new ApiError(
            502,
            detail
              ? 'Exercise provider access denied: ' + detail
              : 'Check the exercise provider key and plan.'
          );
        }
        throw new ApiError(
          res.status === 404 ? 404 : 502,
          'Exercise provider request failed. Please retry.'
        );
      }
      const value = await res.json();
      if (method === 'GET') {
        if (cache.size >= 1024) cache.delete(cache.keys().next().value);
        cache.set(path, { value, until: Date.now() + 900000 });
      }
      return value;
    })();
    if (method === 'GET') pending.set(path, job);
    try {
      return await job;
    } finally {
      pending.delete(path);
    }
  }
  router.get('/names', async (req, res) => {
    const search = z.string().trim().min(2).max(100).parse(req.query.search);
    const query = new URLSearchParams({ search, offset: '0', limit: '30' });
    const { results = [] } = await load('/exercises?' + query);
    res.json({ names: results.map(row => row.name).filter(name => typeof name === 'string' && name.length <= 100) });
  });
  router.get('/filters', async (req, res) => {
    const { muscles, categories, difficulties } = await load('/filters');
    res.json({ muscles, categories, difficulties });
  });
  router.get('/media-token', async (req, res) => {
    let media = req.session.trainingMedia;
    if (!media || media.until <= Date.now() + 30000) {
      const { token, expires_in } = await load('/media/token', 'POST');
      media = { token, until: Date.now() + expires_in * 1000 };
      req.session.trainingMedia = media;
    }
    res.json(media);
  });
  router.get('/', async (req, res) => {
    const { page, ...filters } = searchSchema.parse(req.query);
    const query = new URLSearchParams({
      offset: String((page - 1) * pageSize),
      limit: String(pageSize)
    });
    for (const [name, value] of Object.entries(filters))
      for (const part of [].concat(value || [])) query.append(name, part);
    const { results = [], total = 0 } = await load('/exercises?' + query);
    const exercises = await Promise.all(
      results.map(async (row) => {
        const e = await load('/exercises/' + encodeURIComponent(row.id));
        const videos = (e.videos || [])
          .map((v) => ({
            path: mediaPath(v.url, '/stream/videos/branded/'),
            poster: mediaPath(v.og_image, '/stream/images/og_images/'),
            label: [v.gender, v.angle].filter(Boolean).join(' · ')
          }))
          .filter((v) => v.path);
        return {
          id: e.id,
          name: e.name,
          muscles: e.primary_muscles,
          secondary: e.secondary_muscles,
          equipment: e.category,
          difficulty: e.difficulty,
          steps: e.steps,
          videos
        };
      })
    );
    res.json({ exercises, total, page, pageSize });
  });
  return router;
}
