import User from '../models/User.js';
import AuthToken from '../models/AuthToken.js';
import { ApiError } from '../utils/errors.js';
import { hashPassword, verifyPassword, randomToken, tokenHash } from '../utils/password.js';
import { isOriginAllowed } from '../middleware/auth.js';
import { passwordResetEmail, welcomeEmail } from '../services/emailTemplates.js';

export function publicUser(user) {
  const data = user.toObject ? user.toObject() : { ...user };
  delete data.passwordHash;
  delete data.sessionVersion;
  delete data.emailVerifiedAt;
  delete data.__v;
  data.avatarUrl = data.avatar?.publicId
    ? '/api/users/' + data._id + '/avatar?v=' + data.avatar.version
    : '';
  delete data.avatar;
  return data;
}

async function signInSession(req, user) {
  await new Promise((resolve, reject) =>
    req.session.regenerate((error) => (error ? reject(error) : resolve()))
  );
  req.session.userId = user._id.toString();
  req.session.version = user.sessionVersion;
  req.session.csrfToken = randomToken();
  await new Promise((resolve, reject) =>
    req.session.save((error) => (error ? reject(error) : resolve()))
  );
}

export function authController({ config, email }) {
  async function issueToken(user, purpose) {
    const token = randomToken();
    await AuthToken.findOneAndUpdate(
      { userId: user._id, purpose },
      {
        digest: tokenHash(token),
        expiresAt: new Date(Date.now() + (purpose === 'reset' ? 30 : 1440) * 60000),
        sessionVersion: user.sessionVersion,
        email: user.email
      },
      { upsert: true }
    );
    return token;
  }
  return {
    session: async (req, res) => {
      if (!req.session.csrfToken) req.session.csrfToken = randomToken();
      let user = req.session.userId ? await User.findById(req.session.userId) : null;
      if (user?.sessionVersion !== req.session.version) user = null;
      res.json({
        user: user ? publicUser(user) : null,
        csrfToken: req.session.csrfToken,
        services: {
          email: email.enabled,
          media: Boolean(
            config.cloudinary.cloud_name &&
              config.cloudinary.api_key &&
              config.cloudinary.api_secret
          )
        }
      });
    },
    register: async (req, res) => {
      const { name, username, password, email: address } = req.body;
      const user = await User.create({
        name,
        username,
        email: address,
        passwordHash: await hashPassword(password),
        consentAt: new Date()
      });
      await signInSession(req, user);
      const requestOrigin = req.headers.origin;
      const appUrl =
        requestOrigin && isOriginAllowed(requestOrigin, config.clientUrl, config.nodeEnv, config.port)
          ? requestOrigin
          : config.clientUrl;
      if (email.enabled) {
        const welcome = welcomeEmail({ name: user.name, appUrl });
        email
          .send(user.email, welcome.subject, welcome)
          .catch((error) =>
            console.error('Welcome email could not be delivered:', error?.message || error)
          );
      }
      res.status(201).json({ user: publicUser(user), csrfToken: req.session.csrfToken });
    },
    login: async (req, res) => {
      const identifier = req.body.identifier.trim().toLowerCase();
      const user = await User.findOne({
        $or: [{ email: identifier }, { username: identifier }]
      }).select('+passwordHash');
      if (!user || !(await verifyPassword(req.body.password, user.passwordHash)))
        throw new ApiError(401, 'Email, username or password is incorrect.');
      await signInSession(req, user);
      res.json({ user: publicUser(user), csrfToken: req.session.csrfToken });
    },
    logout: async (req, res) => {
      await new Promise((resolve, reject) =>
        req.session.destroy((error) => (error ? reject(error) : resolve()))
      );
      res.clearCookie('corex.sid', {
        path: '/',
        httpOnly: true,
        sameSite: 'lax',
        secure: config.nodeEnv === 'production'
      });
      res.json({ message: 'Signed out.' });
    },
    forgot: async (req, res) => {
      email.requireConfigured();
      const user = await User.findOne({ email: req.body.email });
      if (user) {
        const token = await issueToken(user, 'reset');
        const requestOrigin = req.headers.origin;
        const appUrl =
          requestOrigin && isOriginAllowed(requestOrigin, config.clientUrl, config.nodeEnv, config.port)
            ? requestOrigin
            : config.clientUrl;
        const resetMail = passwordResetEmail({
          name: user.name,
          resetUrl: appUrl + '/reset-password?token=' + token,
          expiresMinutes: 30
        });
        try {
          await email.send(user.email, resetMail.subject, resetMail);
        } catch (error) {
          console.error('Password reset email could not be delivered:', error?.message || error);
        }
      }
      res.json({ message: 'If an account matches that email, a reset link has been sent.' });
    },
    reset: async (req, res) => {
      const passwordHash = await hashPassword(req.body.password);
      const token = await AuthToken.findOneAndDelete({
        digest: tokenHash(req.body.token),
        purpose: 'reset',
        expiresAt: { $gt: new Date() }
      });
      if (!token)
        throw new ApiError(400, 'This reset link is invalid or expired. Request a new one.');
      const user = await User.findOneAndUpdate(
        { _id: token.userId, sessionVersion: token.sessionVersion, email: token.email },
        { $set: { passwordHash }, $inc: { sessionVersion: 1 } }
      );
      if (!user) throw new ApiError(400, 'This reset link is no longer valid.');
      res.json({ message: 'Password updated. Sign in with your new password.' });
    }
  };
}
