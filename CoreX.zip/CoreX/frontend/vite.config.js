import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiTarget = env.API_PROXY_TARGET || 'http://127.0.0.1:5000';
  let lastProxyErrorAt = 0;

  return {
    plugins: [react()],
    server: {
      host: '0.0.0.0',
      port: 5173,
      strictPort: true,
      allowedHosts: true,
      proxy: {
        '/api': {
          target: apiTarget,
          changeOrigin: false,
          ws: true,
          xfwd: true,
          configure(proxy) {
            proxy.on('error', (error, _req, res) => {
              const now = Date.now();
              if (now - lastProxyErrorAt > 5000) {
                lastProxyErrorAt = now;
                console.error(
                  `[CoreX proxy] Cannot reach backend API at ${apiTarget} (${error.code || error.message}). Start both servers from the CoreX root folder using: npm run dev`
                );
              }
              if (res && !res.headersSent && typeof res.writeHead === 'function') {
                res.writeHead(503, { 'Content-Type': 'application/json' });
                res.end(
                  JSON.stringify({
                    message:
                      'Backend API is offline or still starting. Run "npm run dev" from the CoreX root folder.'
                  })
                );
              }
            });
          }
        }
      }
    },
    build: { chunkSizeWarningLimit: 650 }
  };
});
