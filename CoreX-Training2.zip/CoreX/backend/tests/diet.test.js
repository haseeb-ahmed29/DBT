import test from 'node:test';
import assert from 'node:assert/strict';
import { dietSchema, generateDiet } from '../src/routes/dietRoutes.js';

const profile = {
  weightKg: 75,
  heightCm: 175,
  age: 30,
  goal: 'Maintain weight',
  activity: 'Lightly active',
  preference: 'Vegetarian',
  allergies: 'Peanuts',
  eligible: true,
  consent: true
};
test('Diet guide validates adult eligibility and explicit sharing consent', () => {
  assert.equal(dietSchema.parse(profile).weightKg, 75);
  for (const input of [
    { age: 17 },
    { consent: false },
    { eligible: false },
    { weightKg: Infinity }
  ])
    assert.equal(dietSchema.safeParse({ ...profile, ...input }).success, false);
});
test('Diet guide handles provider success, incomplete responses and quota errors', async () => {
  const previous = process.env.OPENAI_API_KEY;
  process.env.OPENAI_API_KEY = 'test-only';
  try {
    const result = await generateDiet(profile, async (url, options) => {
      const body = JSON.parse(options.body);
      assert.equal(body.store, false);
      assert.equal(JSON.parse(body.input).allergies, 'Peanuts');
      return Response.json({
        status: 'completed',
        output: [{ content: [{ type: 'output_text', text: 'Test guide' }] }]
      });
    });
    assert.equal(result.guide, 'Test guide');
    await assert.rejects(
      generateDiet(profile, async () => Response.json({ status: 'incomplete', output: [] })),
      { status: 502 }
    );
    await assert.rejects(
      generateDiet(profile, async () => new Response(null, { status: 429 })),
      { status: 429 }
    );
    delete process.env.OPENAI_API_KEY;
    await assert.rejects(generateDiet(profile), { status: 503 });
  } finally {
    if (previous === undefined) delete process.env.OPENAI_API_KEY;
    else process.env.OPENAI_API_KEY = previous;
  }
});
