import dietRoutes from './routes/dietRoutes.js';
import express from 'express';
import trainingRoutes from './routes/trainingRoutes.js';
import helmet from 'helmet';
import cors from 'cors';
import session from 'express-session';
import MongoStore from 'connect-mongo';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import mongoose from 'mongoose';
import { createEmailService } from './services/email.js';
import { createMediaService } from './services/cloudinary.js';
import { csrfProtection, isOriginAllowed, requireAuth } from './middleware/auth.js';
import { errorHandler } from './middleware/error.js';
import { validateQuery } from './middleware/validate.js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import { recordRoutes } from './routes/recordRoutes.js';
import toolsRoutes from './routes/toolsRoutes.js';
import { workoutSchema, mealSchema, progressSchema } from './validators/index.js';
import {
  listWorkouts,
  createWorkout,
  updateWorkout,
  deleteWorkout
} from './controllers/workoutController.js';
import { listMeals, createMeal, updateMeal, deleteMeal } from './controllers/mealController.js';
import {
  listProgress,
  createProgress,
  updateProgress,
  deleteProgress
} from './controllers/progressController.js';
import { dashboard } from './controllers/dashboardController.js';

export function createApp(config, overrides = {}) {
  const email = overrides.email || createEmailService(config.smtp);
  const media = overrides.media || createMediaService(config.cloudinary);
  const store =
    overrides.store ||
    MongoStore.create({
      client: mongoose.connection.getClient(),
      collectionName: 'sessions',
      ttl: 7 * 86400
    });
  store.on('error', () => console.error('Session database operation failed.'));
  const deps = { config, email, media };
  const isHttpsClient = config.clientUrl.startsWith('https://');
  const useSecureCookie = config.nodeEnv === 'production' && isHttpsClient;
  const app = express();
  app.disable('x-powered-by');
  // Trust loopback proxy in dev (Vite /api proxy) and a single reverse proxy in production.
  app.set('trust proxy', config.nodeEnv === 'production' ? 1 : 'loopback');
  app.use(
    helmet({
      contentSecurityPolicy:
        config.nodeEnv === 'production'
          ? {
              directives: {
                mediaSrc: ["'self'", 'https://api.musclewiki.com'],
                imgSrc: ['https://api.musclewiki.com', "'self'", 'data:', 'blob:'],
                styleSrc: ["'self'", "'unsafe-inline'"],
                ...(isHttpsClient ? {} : { upgradeInsecureRequests: null })
              }
            }
          : false,
      crossOriginResourcePolicy: {
        policy: config.nodeEnv === 'production' ? 'same-origin' : 'cross-origin'
      }
    })
  );
  app.use(
    cors({
      origin: (origin, callback) =>
        callback(null, isOriginAllowed(origin, config.clientUrl, config.nodeEnv, config.port)),
      credentials: true
    })
  );
  app.use(express.json({ limit: '150kb' }));
  app.use(
    '/api',
    rateLimit({
      windowMs: 60000,
      limit: config.nodeEnv === 'test' ? 2000 : 300,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      message: { message: 'Too many requests. Please wait a minute.' }
    })
  );
  app.get('/api/health', (req, res) =>
    res
      .status(mongoose.connection.readyState === 1 ? 200 : 503)
      .json({ status: mongoose.connection.readyState === 1 ? 'ok' : 'unavailable' })
  );
  app.use(
    '/api',
    session({
      name: 'corex.sid',
      secret: config.sessionSecret,
      store,
      resave: false,
      saveUninitialized: false,
      rolling: true,
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: useSecureCookie,
        maxAge: 7 * 86400000
      }
    })
  );
  app.use(
    '/api',
    (req, res, next) => {
      res.set('Cache-Control', 'no-store');
      next();
    },
    csrfProtection(config.clientUrl, config.nodeEnv, config.port)
  );
  app.use('/api/auth', authRoutes(deps));
  app.use('/api', requireAuth);
  app.use('/api/diet-guide', dietRoutes());
  app.use('/api/training', trainingRoutes());
  app.use('/api/users', userRoutes(deps));
  app.use(
    '/api/workouts',
    recordRoutes(
      { list: listWorkouts, create: createWorkout, update: updateWorkout, remove: deleteWorkout },
      workoutSchema
    )
  );
  app.use(
    '/api/meals',
    recordRoutes(
      { list: listMeals, create: createMeal, update: updateMeal, remove: deleteMeal },
      mealSchema
    )
  );
  app.use(
    '/api/progress',
    recordRoutes(
      {
        list: listProgress,
        create: createProgress,
        update: updateProgress,
        remove: deleteProgress
      },
      progressSchema
    )
  );
  app.get('/api/dashboard', validateQuery, dashboard);
  app.use('/api', toolsRoutes(deps));
  app.use('/api', (req, res) => res.status(404).json({ message: 'API endpoint not found.' }));
  const dist = fileURLToPath(new URL('../../frontend/dist/', import.meta.url));
  if (existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist));
    app.get('/{*path}', (req, res) => res.sendFile(path.join(dist, 'index.html')));
  }
  app.use(errorHandler);
  return { app, email, media, store };
}
