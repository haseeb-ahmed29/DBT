# Diet guidance, reminder sound and report template

## Use the features

Open Meals and choose AI diet guide. Enter weight in kg, height in cm, age, activity, fitness goal, food preference and allergens. Eligible adults can explicitly consent to sending these form values to OpenAI. The returned guide is displayed inside the dashboard with a shortcut to log a meal. Profile identifiers, email addresses and historical records are not sent. The guide is held in page memory and clears when its inputs change or the page is left.

Click Enable sound in the dashboard header. A short three-note tune confirms activation. Newly received reminders then play the tune. Click Sound on to disable it. Sound needs activation again after a reload. Reminder polling runs every 15 seconds while the dashboard is active. Initial historical notifications stay silent. The browser may suspend background tabs, and closing the browser stops in-page audio. Existing email reminders remain configured through SMTP.

Download a PDF from Settings → Reports. The new template contains a CoreX header, owner and date range, record counts, alternating table rows, repeated column headings and page numbers. Long entries continue across pages. Rest time is included in workout exports. Counts reflect recorded entries, including planned sessions and routines.

## Environment setup

Keep the existing CoreX environment settings and add these server values in backend/.env or your host environment.

- OPENAI_API_KEY — your OpenAI API key with API billing enabled.
- OPENAI_MODEL — defaults to gpt-4.1-mini. Use a Responses API compatible model available to your account.
- MUSCLEWIKI_API_KEY — remains required for the online exercise catalogue and licensed media.

Restart the backend after configuring values. Run npm ci, npm run build and npm start from the project root for a fresh deployment. MongoDB, session secret and other original application settings still apply. No private environment values are included in this delivery.

AI generation can incur API usage charges. The endpoint permits ten attempts per signed-in user per hour and times out after 45 seconds. This deployment-local rate limit uses in-memory storage. Multi-instance hosts should use a shared limiter. Responses use store:false. Review OpenAI's applicable data handling terms for your deployment.

## Guidance scope

The guide offers general food ideas and practical portions for adults. It uses multiple profile inputs because body weight alone cannot determine nutrition needs. It does not provide exact calorie prescriptions or medical nutrition therapy. Pregnancy, breastfeeding, eating disorders and conditions requiring a clinical diet should be addressed with a qualified clinician or dietitian. AI output can contain mistakes and ingredient labels need checking.

Reference guidance
https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner
https://www.niddk.nih.gov/health-information/weight-management/healthy-eating-physical-activity-for-life/health-tips-for-adults
https://developers.openai.com/api/reference/resources/responses/methods/create

## Verification and remaining setup

The production build and backend syntax checks passed. Unit, service, contract and provider-adapter tests were run, including eligibility validation, AI failure handling and report generation. Contract tests use the existing in-memory model harness. MongoDB-backed integration tests remain blocked by this execution environment's MongoDB startup failure.

A seven-page PDF with 65 records and an oversized detail cell was generated, rendered and checked for the final record. Browser checks cover desktop and mobile diet form submission, response rendering and reminder tune event dispatch using test service responses and an instrumented audio context. Live AI calls, licensed exercise playback, actual speaker output and production SMTP delivery require your configured environment and deployment verification.

## Changes

Added backend/src/routes/dietRoutes.js, frontend/src/pages/DietGuide.jsx, frontend/src/hooks/useReminderSound.js and backend/tests/diet.test.js. Updated backend/src/app.js, backend/.env.example, backend/src/services/reports.js, backend/src/controllers/reportController.js, backend/src/middleware/auth.js, frontend/src/App.jsx, frontend/src/pages/Meals.jsx and frontend/src/layouts/DashboardLayout.jsx. The frontend distribution is rebuilt.

Bug fixes include graceful LAN discovery when operating-system interface enumeration is unavailable, retaining seen notification IDs to avoid repeated alerts after read-state changes, and handling long PDF rows without overflowing the page. Full absence of bugs cannot be established from these checks.
