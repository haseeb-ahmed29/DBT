import { useEffect, useRef, useState } from 'react';

export function useReminderSound(userId) {
  const context = useRef(null);
  const [enabled, setEnabled] = useState(false);
  const [error, setError] = useState('');
  useEffect(
    () => () => {
      context.current?.close().catch(() => {});
    },
    []
  );
  useEffect(() => {
    setEnabled(false);
    setError('');
  }, [userId]);
  function play() {
    const audio = context.current;
    if (!audio || audio.state !== 'running') return;
    [523.25, 659.25, 783.99].forEach((frequency, index) => {
      const oscillator = audio.createOscillator(),
        gain = audio.createGain(),
        start = audio.currentTime + index * 0.18;
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.12, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.32);
      oscillator.connect(gain);
      gain.connect(audio.destination);
      oscillator.start(start);
      oscillator.stop(start + 0.35);
      oscillator.onended = () => {
        oscillator.disconnect();
        gain.disconnect();
      };
    });
  }
  async function toggle() {
    if (enabled) {
      setEnabled(false);
      return;
    }
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) throw new Error('Unsupported');
      context.current ||= new Audio();
      await context.current.resume();
      if (context.current.state !== 'running') throw new Error('Blocked');
      setEnabled(true);
      setError('');
      play();
    } catch {
      setError('Sound is unavailable in this browser. Try again after interacting with the page.');
    }
  }
  function notify(items) {
    if (!enabled) return;
    let fresh = false;
    for (const item of items.filter((item) => item.type === 'reminder')) {
      const key = 'corex-reminder-sound:' + userId + ':' + item._id;
      try {
        if (localStorage.getItem(key)) continue;
        localStorage.setItem(key, String(Date.now()));
      } catch {
        /* Sound remains available when browser storage is restricted. */
      }
      fresh = true;
    }
    if (fresh) play();
  }
  return { enabled, error, toggle, notify };
}
