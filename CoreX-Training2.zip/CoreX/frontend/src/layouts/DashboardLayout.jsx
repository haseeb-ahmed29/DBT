import { useReminderSound } from '../hooks/useReminderSound';
import { useEffect, useRef, useState } from 'react';
import { NavLink, Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Dumbbell,
  Utensils,
  ChartNoAxesCombined,
  Bell,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import Brand from '../components/Brand';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useData } from '../hooks/useData';
const navigation = [
  { to: '/', name: 'Dashboard', icon: LayoutDashboard },
  { to: '/workouts', name: 'Workouts', icon: Dumbbell },
  { to: '/training', name: 'Training', icon: Dumbbell },
  { to: '/meals', name: 'Meals', icon: Utensils },
  { to: '/progress', name: 'Progress', icon: ChartNoAxesCombined }
];
export default function DashboardLayout() {
  const { user, logout } = useAuth(),
    toast = useToast(),
    navigate = useNavigate(),
    location = useLocation();
  const sound = useReminderSound(user._id);
  const [collapsed, setCollapsed] = useState(
    () => localStorage.getItem('corex-sidebar') === 'closed'
  );
  const [menu, setMenu] = useState(false);
  const [avatarBroken, setAvatarBroken] = useState(false);
  const { data, reload } = useData('/notifications');
  const seenUnreadIds = useRef(null);
  useEffect(() => { seenUnreadIds.current = null; }, [user._id]);
  useEffect(() => {
    setAvatarBroken(false);
  }, [user.avatarUrl]);
  useEffect(() => {
    if (!data?.items) return;
    const unreadItems = data.items.filter((item) => !item.read);
    if (seenUnreadIds.current === null) {
      seenUnreadIds.current = new Set(unreadItems.map((item) => item._id));
      return;
    }
    const fresh = unreadItems.filter((item) => !seenUnreadIds.current.has(item._id));
    if (fresh.length) {
      sound.notify(fresh);
      const latest = fresh[0];
      toast(latest.title + (latest.message ? ' — ' + latest.message : ''));
    }
    unreadItems.forEach(item => seenUnreadIds.current.add(item._id));
  }, [data, toast]);
  useEffect(() => {
    setMenu(false);
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'
    });
    reload();
  }, [location.pathname, reload]);
  useEffect(() => {
    const timer = setInterval(reload, 15000);
    const refreshNotifications = () => reload();
    window.addEventListener('focus', refreshNotifications);
    window.addEventListener('corex-notifications-updated', refreshNotifications);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', refreshNotifications);
      window.removeEventListener('corex-notifications-updated', refreshNotifications);
    };
  }, [reload]);
  useEffect(() => {
    if (!menu) return;
    const close = (event) => {
      if (event.key === 'Escape') setMenu(false);
    };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [menu]);
  function toggle() {
    setCollapsed((value) => {
      localStorage.setItem('corex-sidebar', value ? 'open' : 'closed');
      return !value;
    });
  }
  async function signOut() {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      toast(error.message, 'danger');
    }
  }
  return (
    <div className={'app-shell ' + (collapsed ? 'sidebar-collapsed' : '')}>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <aside className="sidebar">
        <Link to="/" className="sidebar-brand">
          {collapsed ? <span className="brand-x">X</span> : <Brand />}
        </Link>
        <button
          className="collapse-button"
          onClick={toggle}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-expanded={!collapsed}
        >
          {collapsed ? <PanelLeftOpen size={18} /> : <PanelLeftClose size={18} />}
        </button>
        <span className="nav-caption">YOUR SPACE</span>
        <nav aria-label="Main navigation">
          {navigation.map(({ to, name, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === '/'} title={collapsed ? name : undefined}>
              <Icon size={20} />
              <span>{name}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-note">
          <span className="note-dot" />
          <strong>One day at a time.</strong>
          <p>Small steps build lasting habits.</p>
        </div>
        <Link to="/settings" className="sidebar-settings">
          Settings & more
        </Link>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="topbar-label">
            <span className="mobile-wordmark">
              <Brand />
            </span>
            <span className="desktop-label">PERSONAL FITNESS TRACKER</span>
          </div>
          <div className="topbar-actions">
            <button type="button" className="text-button" aria-pressed={sound.enabled} onClick={sound.toggle}>
              {sound.enabled ? 'Sound on' : 'Enable sound'}
            </button>
            {sound.error && <span role="status" className="small">{sound.error}</span>}
            <Link
              to="/notifications"
              className="notification-button"
              aria-label={'Notifications' + (data?.unread ? ', ' + data.unread + ' unread' : '')}
            >
              <Bell size={20} />
              {data?.unread > 0 && <span className="notification-dot" />}
            </Link>
            <div className="profile-control">
              <button
                className="profile-button"
                onClick={() => setMenu(!menu)}
                aria-expanded={menu}
                aria-label="Open account menu"
              >
                {user.avatarUrl && !avatarBroken ? (
                  <img
                    src={user.avatarUrl}
                    className="avatar"
                    alt=""
                    onError={() => setAvatarBroken(true)}
                  />
                ) : (
                  <span className="avatar initials">{user.name.slice(0, 1)}</span>
                )}
                <span className="profile-name">
                  {user.name.split(' ')[0]}
                  <small>My account</small>
                </span>
                <span className="caret">⌄</span>
              </button>
              {menu && (
                <>
                  <button
                    className="menu-backdrop"
                    aria-label="Close account menu"
                    onClick={() => setMenu(false)}
                  />
                  <div className="account-menu">
                    <Link to="/settings" onClick={() => setMenu(false)}>
                      Profile & settings
                    </Link>
                    <Link to="/settings?tab=reminders" onClick={() => setMenu(false)}>
                      Reminders
                    </Link>
                    <Link to="/settings?tab=reports" onClick={() => setMenu(false)}>
                      Reports
                    </Link>
                    <Link to="/settings?tab=support" onClick={() => setMenu(false)}>
                      Help & support
                    </Link>
                    <button onClick={signOut}>Sign out</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>
        <main id="main" className="main-content">
          <Outlet />
        </main>
        <footer className="app-footer">
          CoreX · Fit Zone <span>Made for your everyday progress.</span>
        </footer>
      </div>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {navigation.map(({ to, name, icon: Icon }) => (
          <NavLink key={to} to={to} end={to === '/'}>
            <Icon size={21} />
            <span>{name}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
