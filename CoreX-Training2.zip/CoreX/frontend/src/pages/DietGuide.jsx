import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { Button, Field, Select, Check, ErrorMessage } from '../components/UI';

export default function DietGuide() {
  const [form, setForm] = useState({
    weightKg: '',
    heightCm: '',
    age: '',
    goal: 'Maintain weight',
    activity: 'Lightly active',
    preference: 'Mixed diet',
    allergies: '',
    eligible: false,
    consent: false
  });
  const [result, setResult] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  };
  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    try {
      setResult(
        await api('/diet-guide', {
          method: 'POST',
          body: {
            ...form,
            weightKg: Number(form.weightKg),
            heightCm: Number(form.heightCm),
            age: Number(form.age)
          }
        })
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="form-stack">
      <header>
        <h1>AI diet guide</h1>
        <p className="muted">
          Meal ideas suited to your current weight, activity and fitness goal.
        </p>
      </header>
      <form className="card form-stack" onSubmit={submit}>
        <div className="form-grid three">
          {[
            ['weightKg', 'Current weight (kg)', 25, 400],
            ['heightCm', 'Height (cm)', 100, 250],
            ['age', 'Age', 18, 100]
          ].map(([key, label, min, max]) => (
            <Field
              key={key}
              label={label}
              type="number"
              min={min}
              max={max}
              step={key === 'age' ? 1 : 0.1}
              required
              value={form[key]}
              onChange={(e) => set(key, e.target.value)}
            />
          ))}
          {[
            ['goal', 'Goal', ['Maintain weight', 'Build muscle', 'Manage weight']],
            [
              'activity',
              'Activity',
              ['Mostly seated', 'Lightly active', 'Regular exercise', 'Very active']
            ],
            ['preference', 'Food preference', ['Mixed diet', 'Vegetarian', 'Vegan']]
          ].map(([key, label, values]) => (
            <Select
              key={key}
              label={label}
              value={form[key]}
              onChange={(e) => set(key, e.target.value)}
            >
              {values.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </Select>
          ))}
        </div>
        <Field
          label="Food allergies or foods to avoid"
          maxLength={300}
          value={form.allergies}
          onChange={(e) => set('allergies', e.target.value)}
        />
        <p className="small muted">
          General guidance for adults. For pregnancy, breastfeeding, an eating disorder or a
          condition requiring a medical diet, ask a qualified clinician or dietitian for an
          individual plan.
        </p>
        <Check required checked={form.eligible} onChange={(e) => set('eligible', e.target.checked)}>
          I am 18 or older and the medical situations above do not apply to me.
        </Check>
        <Check required checked={form.consent} onChange={(e) => set('consent', e.target.checked)}>
          Send these form details to OpenAI to create my guide.
        </Check>
        <ErrorMessage message={error} />
        <Button type="submit" busy={busy}>
          Generate my guide
        </Button>
      </form>
      {result && (
        <section className="card form-stack" aria-live="polite">
          <h2>Your AI-generated guide</h2>
          <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.8 }}>{result.guide}</div>
          <p className="small muted">
            Review ingredients and portions for your needs. This guide may contain errors.
          </p>
          <Link to="/meals?new=1">Log a meal</Link>
        </section>
      )}
    </div>
  );
}
