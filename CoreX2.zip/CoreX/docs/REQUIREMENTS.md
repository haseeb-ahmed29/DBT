# Word brief → CoreX implementation

Source: the supplied **MERN-Fitness_Tracker.docx**. The user’s later instructions determine the brand, colors, folder separation and private-by-default behavior.

## Functional coverage

| Brief requirement | Where to use it | Main implementation |
|---|---|---|
| Unique account, login, logout | Register / Log in / account menu | `authController.js`, `User.js`, `AuthPages.jsx` |
| Password recovery and email verification | Forgot password / My profile | Hashed single-use tokens, SMTP service, `AuthToken.js` |
| Profile and avatar | Settings → My profile | `userController.js`, authenticated Cloudinary images, `AccountSettings.jsx` |
| Edit name, email and password | Settings → My profile | Email changes require current password; password changes revoke other sessions |
| Personal workout logging | Workouts → Sessions | Exercises, sets, reps, load, distance, duration, notes and tags |
| Create reusable workout routines | Workouts → Routines | Routine templates can be used to start a session |
| Search and filter workouts | Workouts search / filters | Literal search, categories, tags and dates, paginated results |
| Meal planning / nutrition logging | Meals | Meal entries with food quantities, manually entered nutrition, totals, search and date/type filters |
| Track calories and macronutrients | Dashboard / Meals | Totals computed by the backend; calorie trend chart |
| Body measurements and performance | Progress | Weight, waist, chest, hips, run time and lift records |
| Graphs and summaries | Dashboard / Meals / Progress | Weekly activity, weight/measurement/performance trends, nutrition summaries |
| Personal targets | Settings → Preferences & goals | Weekly workouts, daily calories and target weight |
| Workout/goal notifications | Notifications | Completed sessions and reached weekly-workout goals, deduplicated by event key |
| Scheduled reminders | Settings → Reminders | Repeat days, local time, workout/meal/goal type, in-app/email channels |
| Follows, search people, forum replies | Settings → Community | Optional opt-in profiles, follow/unfollow, posts, replies and notifications |
| Private fitness data | All authenticated record routes | Every private query is scoped to the signed-in owner |
| Personal reports | Settings → Reports | PDF, CSV and JSON by data category/date range |
| Support / feedback | Settings → Help & support | Stored ticket; SMTP notification when configured |
| Units, theme and notifications | Settings → Preferences & goals | Metric/imperial conversion, light/dark mode, timezone and channel preferences |
| Responsive web app | Desktop and mobile | Same four main destinations; mobile bottom navigation; collapsible desktop sidebar |

Meal nutrition is entered by the user; there is no third-party food database or automatic meal prescription. Workouts and progress are entered by the user; there is no wearable-device integration or trainer/admin role.

## Decisions requested after the brief

- **Brand:** CoreX, slogan Fit Zone. Original supplied logo is in `frontend/src/assets/brand/` and is replaceable.
- **Colors:** coral `#FB7359`, white surfaces, pale background, readable dark text. Yellow edit/planned, green completion/toward-target and red delete/error/further-from-target states include text labels.
- **Privacy:** accounts are private by default. Other people cannot find or follow a private account. Community participation is a separate explicit opt-in. Following does not expose workouts, meals, measurements, email, reminders or reports.
- **Navigation:** Dashboard, Workouts, Meals and Progress are the only primary sections on both screen sizes. Settings and other tools are reached from the profile menu.
- **Data/services:** MongoDB Atlas, Cloudinary and SMTP use backend environment variables. No cloud secret is sent to the React bundle.
- **Readable structure:** backend and frontend are separated; routes, models, controllers, services, pages, forms, shared components and assets have their own folders.

## Nonfunctional requirements and evidence

| Requirement | Included / measured status |
|---|---|
| Security and privacy | Owner-scoped records, password hashing, server sessions, CSRF/origin checks, input validation, rate limits and upload normalization implemented. No formal penetration-test claim. |
| Accessibility and usability | Associated labels, keyboard focus styles, native modal behavior, skip link, reduced-motion handling and text status labels. Desktop/mobile inspection completed. Full WCAG conformance not certified. |
| Fast responses / 1–2 second target | Pagination, bounded date ranges, indexes and route splitting are included. No production latency benchmark or guarantee. |
| Hundreds of concurrent users | Deployment-specific load testing remains to be performed. Local contract tests are not a capacity test. |
| 99% uptime | Requires hosted infrastructure and monitoring. A localhost app cannot provide an uptime guarantee. |
| Backups | Manual logical snapshot command and OS scheduling guidance included. Atlas-managed backups and restore drills must be configured by the owner. |
| Error handling and logging | User-facing errors; backend error and integration-failure logs. Centralized production log collection is not configured. |
| Tests | 28 passing unit/service/HTTP-contract checks. Real MongoDB integration suite included but blocked by this build environment. See `TESTING.md`. |
| Documentation | README setup, user guide, API reference, architecture, this mapping and testing notes. |
| Demonstration | Actual browser UI screenshots, short interface-preview video and a live demonstration script. Preview uses synthetic QA records, not a live Atlas account. |

## Final acceptance on your computer

Configure your own services, run the integration suite, register two accounts, repeat the user guide’s main flows and confirm that one account cannot read the other’s records. Then verify your SMTP inbox delivery and Cloudinary upload/replacement. See `TESTING.md` for exact steps.
