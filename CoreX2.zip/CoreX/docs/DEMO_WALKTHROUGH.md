# Academy demonstration — Roman Urdu script

## Before recording

1. README follow karke Atlas, session secret, Cloudinary aur SMTP configure karein.
2. `npm run dev` chalayein. Browser mein `http://localhost:5173` open karein.
3. Real credentials, `.env`, database connection string ya reset tokens recording mein expose na karein.
4. Charts ke liye optional seed account banayein, ya apne demo entries pehle log karein. New registration empty hoti hai.
5. Live database tests aur `TESTING.md` ke acceptance checks apne machine par complete karein.

## 5–6 minute live walkthrough

| Time | Screen / action | Bolne ke liye simple explanation |
|---|---|---|
| 0:00–0:30 | Login / register | “CoreX aik personal fitness tracker hai. User apne workouts, meals aur progress ko aik jagah record karta hai.” |
| 0:30–1:00 | Register, logout, login | “Har account unique hai. Data private hai; doosra user meri personal fitness history access nahi kar sakta.” |
| 1:00–1:40 | Dashboard | “Yahan weekly completed workouts, active time, calories aur weight nazar aate hain. Graphs database ke records se bante hain.” |
| 1:40–2:20 | Workouts | “Workout add karein, exercises/sets/reps fill karein, save aur edit karein. Reusable routine se naya session bhi ban sakta hai.” |
| 2:20–2:55 | Meals | “Food aur uski nutrition enter karte hain. Backend totals calculate karta hai; user entered total par trust nahi karta.” |
| 2:55–3:25 | Progress | “Weight aur measurements log karte hain. Green personal target ke qareeb jane ko show karta hai. Yeh medical diagnosis nahi hai.” |
| 3:25–4:05 | Settings | “Name, profile photo, email, password, units, timezone aur theme yahan change hote hain.” |
| 4:05–4:40 | Reminders / notifications | “Workout ya meal reminder schedule ho sakta hai. Server running ho to selected timezone ke mutabiq reminder milta hai.” |
| 4:40–5:10 | Reports | “PDF ya CSV select karke apne records download kiye ja sakte hain.” |
| 5:10–5:35 | Mobile + sidebar | “Desktop aur phone dono par wahi four sections hain. Desktop sidebar collapse hoti hai; mobile par bottom navigation hai.” |
| 5:35–6:00 | Folder map | “React frontend, Express backend, Mongoose models aur cloud integrations alag folders mein hain. Credentials sirf backend `.env` mein hain.” |

Optional: Community feature dikhate waqt batayein ke profile pehle private hoti hai. User khud opt in kare to search/follow/posts enable hote hain. Personal records tab bhi share nahi hote.

## Included visual preview

`previews/CoreX-UI-preview.mp4` is a short **slideshow of actual browser captures**, without audio or simulated interaction. It shows desktop dashboard, meals, progress, reminders and a mobile layout. Captures use synthetic QA fixtures; values can differ between captures because records were edited during testing. It is an interface preview, not a recording of live Atlas/Cloudinary/SMTP acceptance.

- `previews/CoreX-desktop.jpg` — full desktop dashboard.
- `previews/CoreX-mobile.jpg` — 390×844 mobile viewport shown in a browser canvas.
- Numbered captures — individual pages used in the preview.

For the final academy video, use the script above to record the actual app running on your machine after configuring your own services.

## Common viva questions

**MERN kya hai?** MongoDB data store karta hai; Express API routes handle karta hai; React UI banata hai; Node.js backend JavaScript chalata hai.

**Cloudinary kyun?** Profile images ko backend validate/normalize karke Cloudinary mein authenticated assets ke taur par store karta hai.

**Login kaise secure hai?** Password plain text store nahi hota. Salted scrypt hash use hota hai, session server par hoti hai aur browser ko HTTP-only session cookie milti hai.

**User doosre ka data kyun nahi dekh sakta?** Har private query mein signed-in user ki ID add hoti hai. Request body se owner choose nahi kiya ja sakta.

**Reminder browser band hone par chalega?** Browser band ho sakta hai, lekin Node server aur internet connection chalna zaroori hai. Email channel ke liye SMTP aur verified address bhi chahiye.

**Kya sab tests pass hue?** 28 unit/service/HTTP-contract checks aur build pass hue. Real MongoDB integration suite ko restricted build environment ne block kiya; live cloud-service checks apne credentials ke saath complete karne hain. Actual completed checks honestly report karein.
