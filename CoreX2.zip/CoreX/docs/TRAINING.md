# Training in CoreX

Open **Training** in the authenticated dashboard. Search by exercise name or combine the equipment, muscle and difficulty filters. The page uses MuscleWiki's reported filter values, including cardio when supplied as an equipment category. Open a card, choose an available camera angle and press Play. Select **Log this exercise** to open the existing session form. Saved sessions appear in Workouts with rest time in seconds. Existing sessions without a rest value remain supported.

## Enable on your installation

Keep your existing service configuration. Add MUSCLEWIKI_API_KEY to the backend environment and restart the backend. The value is the permanent key from your own MuscleWiki API account. The browser receives a short-lived media-only token. Never put the permanent key in a VITE_ variable. A fresh installation also requires the existing CoreX configuration, including MongoDB and the session secret, as described in the main README. The ZIP includes the rebuilt frontend. For a source install, use Node 22.12 or newer, run npm ci and npm run build at project root, then npm start.

## Provider selection and costs

MuscleWiki offers a hosted paginated catalogue with branded MP4s and authenticated native media streaming. The catalogue advertises 1,900+ exercises and 7,700+ clips. BASIC is playground-only. TESTING is $10/month for 1,000 calls, GROWTH is $39.99/month for 30,000 calls and PROFESSIONAL is $99.99/month for 100,000 calls. Secondary muscle metadata requires Professional or higher. Confirm current terms and pricing before subscribing. No purchase or account creation is part of this delivery.

ExerciseDB.io offers a licensed download with GIFs and requires self-hosting. RepDB also sells commercial bundles. The buzops9/exercisedb fork did not establish permission for commercial redistribution of its video assets in this review. CoreX uses the hosted MuscleWiki service exclusively.

- https://api.musclewiki.com/
- https://api.musclewiki.com/documentation
- https://api.musclewiki.com/api-terms
- https://exercisedb.io/faq
- https://repdb.co/
- https://github.com/buzops9/exercisedb

## Operations and licence

Exercise data and videos provided by MuscleWiki.com

Include the preceding credit verbatim in the deployed site's Terms or Privacy Policy. Keep provider branding visible. The backend caches metadata for 15 minutes and signs media access per authenticated session. Video bytes stream directly into the player from MuscleWiki. Allow https://api.musclewiki.com for img-src and media-src in any additional reverse-proxy CSP. Exclude token-bearing media URLs from analytics and service-worker caches.

Each uncached eight-card page uses one list call and up to eight metadata calls. Filter discovery, thumbnails, token exchange, and video byte ranges also use provider capacity. The adapter backs off on upstream 429s. The browser loads thumbnails lazily and starts video only on user action.

## Source changes

Backend: src/routes/trainingRoutes.js, src/app.js, src/models/Workout.js, src/validators/index.js, .env.example and tests/training.test.js.
Frontend: src/App.jsx, src/layouts/DashboardLayout.jsx, src/pages/Training.jsx, src/pages/Workouts.jsx, src/components/forms/WorkoutForm.jsx, src/styles/global.css and rebuilt dist.
