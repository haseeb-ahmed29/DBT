import { createContext, useContext, useEffect, useState } from 'react';
import { api, setCsrf } from '../lib/api';
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(''),
    [services, setServices] = useState({});
  async function refresh() {
    setError('');
    try {
      const data = await api('/auth/session');
      setUser(data.user);
      setServices(data.services);
      return data;
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    refresh();
    const expire = () => {
      setUser(null);
      refresh();
    };
    window.addEventListener('corex-session-expired', expire);
    return () => window.removeEventListener('corex-session-expired', expire);
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = user?.settings?.theme || 'light';
  }, [user?.settings?.theme]);
  async function authenticate(path, body) {
    const data = await api('/auth/' + path, { method: 'POST', body });
    setUser(data.user);
    return data;
  }
  async function logout() {
    await api('/auth/logout', { method: 'POST' });
    setUser(null);
    setCsrf('');
    await refresh();
  }
  return (
    <AuthContext.Provider
      value={{ user, setUser, loading, error, services, refresh, authenticate, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}
export const useAuth = () => useContext(AuthContext);
