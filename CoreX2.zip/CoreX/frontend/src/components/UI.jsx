import { useId, useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
export function Button({ children, tone = 'primary', className = '', busy, disabled, ...props }) {
  return (
    <button className={'button ' + tone + ' ' + className} disabled={busy || disabled} {...props}>
      {busy ? 'Please wait…' : children}
    </button>
  );
}
export function Field({ label, hint, children, type, ...props }) {
  const id = useId();
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === 'password' && !children;
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children ? (
        <span className="field-control">{children}</span>
      ) : isPassword ? (
        <span className="password-input-wrap">
          <input
            id={id}
            type={showPassword ? 'text' : 'password'}
            aria-describedby={hint ? id + '-hint' : undefined}
            {...props}
          />
          <button
            type="button"
            className="password-toggle"
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            aria-pressed={showPassword}
            onClick={() => setShowPassword((visible) => !visible)}
          >
            {showPassword ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
          </button>
        </span>
      ) : (
        <input id={id} type={type} aria-describedby={hint ? id + '-hint' : undefined} {...props} />
      )}{' '}
      {hint && <small id={id + '-hint'}>{hint}</small>}
    </div>
  );
}
export function Select({ label, children, ...props }) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <select id={id} {...props}>
        {children}
      </select>
    </div>
  );
}
export function Textarea({ label, ...props }) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <textarea id={id} rows="3" {...props} />
    </div>
  );
}
export function Badge({ tone = 'neutral', children }) {
  return <span className={'badge ' + tone}>{children}</span>;
}
export function PageTitle({ eyebrow, title, description, children }) {
  return (
    <div className="page-title">
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      <div className="title-actions">{children}</div>
    </div>
  );
}
export function Empty({ title = 'Nothing here yet', children }) {
  return (
    <div className="empty">
      <div className="empty-line" />
      <h3>{title}</h3>
      <p>{children || 'Your records will appear here after you add your first entry.'}</p>
    </div>
  );
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <span />
      Loading your space…
    </div>
  );
}
export function ErrorMessage({ message, retry }) {
  return message ? (
    <div className="alert danger" role="alert">
      {message}
      {retry && (
        <button className="text-button" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  ) : null;
}
export function Pagination({ data, page, setPage }) {
  const pages = data?.pages || Math.max(1, Math.ceil((data?.total || 0) / (data?.limit || 20)));
  return pages > 1 ? (
    <div className="pagination">
      <Button tone="quiet" disabled={page <= 1} onClick={() => setPage(page - 1)}>
        Previous
      </Button>
      <span>
        {page} / {pages}
      </span>
      <Button tone="quiet" disabled={page >= pages} onClick={() => setPage(page + 1)}>
        Next
      </Button>
    </div>
  ) : null;
}
export function Actions({ onEdit, onDelete, children }) {
  return (
    <div className="row-actions">
      {children}
      {onEdit && (
        <button className="text-button warning" onClick={onEdit}>
          Edit
        </button>
      )}
      {onDelete && (
        <button className="text-button danger" onClick={onDelete}>
          Delete
        </button>
      )}
    </div>
  );
}
export function Check({ children, ...props }) {
  return (
    <label className="check">
      <input type="checkbox" {...props} />
      <span>{children}</span>
    </label>
  );
}
