import {
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  AreaChart,
  Area,
  LineChart,
  Line,
  ReferenceLine
} from 'recharts';
import { dateLabel } from '../lib/format';
import { Empty } from './UI';
const axis = { fontSize: 11, fill: '#737A86' };
const tooltipStyle = {
  borderRadius: 12,
  border: '1px solid #E8E9EE',
  color: '#22242B',
  background: '#FFFFFF'
};
export function ActivityChart({ data }) {
  return (
    <div className="chart" role="img" aria-label="Completed workouts for each day this week">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} barSize={30} margin={{ top: 16, right: 4, bottom: 0, left: -25 }}>
          <CartesianGrid strokeDasharray="4 5" vertical={false} stroke="var(--border)" />
          <XAxis
            dataKey="date"
            tickFormatter={(v) => dateLabel(v, { weekday: 'short' }).slice(0, 3)}
            tick={axis}
            axisLine={false}
            tickLine={false}
          />
          <YAxis allowDecimals={false} tick={axis} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={tooltipStyle}
            cursor={{ fill: 'var(--accent-soft)' }}
            labelFormatter={(v) => dateLabel(v)}
          />
          <Bar
            isAnimationActive={false}
            dataKey="count"
            name="Workouts"
            fill="#FB7359"
            radius={[7, 7, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
export function TrendChart({
  data,
  dataKey = 'value',
  label = 'Value',
  target,
  height = 240,
  color = '#FB7359'
}) {
  if (!data?.length)
    return (
      <Empty title="Your trend starts here">Add entries to see your progress over time.</Empty>
    );
  return (
    <div
      className="chart"
      style={{ height }}
      role="img"
      aria-label={label + ' trend from your logged records'}
    >
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 15, right: 15, left: -15, bottom: 0 }}>
          <defs>
            <linearGradient id={'fill-' + dataKey} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.2} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="4 5" vertical={false} stroke="var(--border)" />
          <XAxis
            dataKey="date"
            tickFormatter={(v) => dateLabel(v)}
            tick={axis}
            minTickGap={35}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={axis}
            domain={dataKey === 'value' ? ['auto', 'auto'] : [0, 'auto']}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip contentStyle={tooltipStyle} labelFormatter={(v) => dateLabel(v)} />
          {target != null && (
            <ReferenceLine
              ifOverflow="extendDomain"
              y={target}
              stroke="#278563"
              strokeDasharray="5 4"
              label={{ value: 'Goal', fill: '#278563', fontSize: 11 }}
            />
          )}
          <Area
            isAnimationActive={false}
            type="monotone"
            dataKey={dataKey}
            name={label}
            stroke={color}
            strokeWidth={3}
            fill={'url(#fill-' + dataKey + ')'}
            dot={data.length < 12}
            connectNulls={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
