import logo from '../assets/brand/corex-logo.png';
export default function Brand() {
  return (
    <div className="brand">
      <img src={logo} alt="CoreX · Fit Zone" />
    </div>
  );
}
