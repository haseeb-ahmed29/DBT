import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../hooks/useData';
import { useToast } from '../../context/ToastContext';
import { api, queryString } from '../../lib/api';
import {
  Button,
  Field,
  Textarea,
  Empty,
  ErrorMessage,
  Loading,
  Pagination
} from '../../components/UI';
import { Confirm } from '../../components/Modal';
export default function Community() {
  const { user } = useAuth(),
    toast = useToast();
  const [q, setQ] = useState(''),
    [page, setPage] = useState(1),
    [busy, setBusy] = useState(false),
    [deleting, setDeleting] = useState(null);
  const people = useData('/community/people?' + queryString({ q, page })),
    posts = useData('/community/posts?limit=20');
  async function mutate(path, method, body) {
    setBusy(true);
    try {
      await api('/community/' + path, { method, body });
      people.reload();
      posts.reload();
      return true;
    } catch (e) {
      toast(e.message, 'danger');
      return false;
    } finally {
      setBusy(false);
    }
  }
  async function post(e) {
    e.preventDefault();
    const element = e.currentTarget;
    if (await mutate('posts', 'POST', Object.fromEntries(new FormData(element)))) {
      element.reset();
      toast('Post published.');
    }
  }
  async function reply(e, id) {
    e.preventDefault();
    const element = e.currentTarget;
    if (await mutate('posts/' + id + '/replies', 'POST', Object.fromEntries(new FormData(element))))
      element.reset();
  }
  return (
    <>
      <section className="card">
        <h2>Optional community</h2>
        <p className="muted">
          Only people who enable community visibility appear here. Following never shares private
          fitness records.
        </p>
        {!user.discoverable && (
          <div className="alert neutral">
            Your profile is private. Enable community visibility in My profile to follow people or
            publish posts.
          </div>
        )}
        <Field
          label="Find a person"
          placeholder="Search name or username"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(1);
          }}
        />
        <ErrorMessage message={people.error} retry={people.reload} />
        {people.loading ? (
          <Loading />
        ) : people.data?.items.length ? (
          <div className="people-list">
            {people.data.items.map((person) => (
              <div key={person._id}>
                <div>
                  <strong>{person.name}</strong>
                  <small>@{person.username}</small>
                </div>
                <Button
                  tone={person.following ? 'quiet' : 'primary'}
                  disabled={!user.discoverable || busy}
                  onClick={() =>
                    mutate('people/' + person._id + '/follow', person.following ? 'DELETE' : 'POST')
                  }
                >
                  {person.following ? 'Unfollow' : 'Follow'}
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <Empty title="No visible profiles">
            People appear here only after they choose to join.
          </Empty>
        )}
        <Pagination data={people.data} page={page} setPage={setPage} />
      </section>
      <section className="card">
        <h2>Community conversations</h2>
        {user.discoverable && (
          <form className="form-stack community-compose" onSubmit={post}>
            <Field label="Post title" name="title" required maxLength={100} />
            <Textarea label="Your message" name="body" required maxLength={2000} />
            <div className="form-footer">
              <Button busy={busy} type="submit">
                Publish post
              </Button>
            </div>
          </form>
        )}
        <ErrorMessage message={posts.error} retry={posts.reload} />
        {posts.loading ? (
          <Loading />
        ) : posts.data?.items.length ? (
          posts.data.items.map((post) => (
            <article className="community-post" key={post._id}>
              <div className="card-head">
                <span className="small muted">
                  {post.author.name} · @{post.author.username}
                </span>
                {post.author._id === user._id && (
                  <button
                    className="text-button danger"
                    onClick={() =>
                      setDeleting({ path: 'posts/' + post._id, label: 'post and its replies' })
                    }
                  >
                    Delete
                  </button>
                )}
              </div>
              <h3>{post.title}</h3>
              <p className="preserve-lines">{post.body}</p>
              <div className="replies">
                {post.replies.map((reply) => (
                  <div key={reply._id}>
                    <strong>{reply.author.name}</strong>
                    <p className="preserve-lines">{reply.body}</p>
                    {reply.author._id === user._id && (
                      <button
                        className="text-button danger"
                        onClick={() =>
                          setDeleting({ path: 'replies/' + reply._id, label: 'reply' })
                        }
                      >
                        Delete reply
                      </button>
                    )}
                  </div>
                ))}
              </div>
              {user.discoverable && (
                <form onSubmit={(e) => reply(e, post._id)} className="reply-form">
                  <input
                    name="body"
                    aria-label={'Reply to ' + post.title}
                    placeholder="Write a reply…"
                    maxLength={1500}
                    required
                  />
                  <Button type="submit" tone="quiet" busy={busy}>
                    Reply
                  </Button>
                </form>
              )}
            </article>
          ))
        ) : (
          <Empty title="Start a thoughtful conversation">
            Share encouragement or a training experience. Published posts are visible to signed-in
            community members.
          </Empty>
        )}
        <p className="small muted">Showing the latest 20 posts and latest 30 replies per post.</p>
      </section>
      {deleting && (
        <Confirm
          title="Delete community content?"
          busy={busy}
          onCancel={() => setDeleting(null)}
          onConfirm={async () => {
            if (await mutate(deleting.path, 'DELETE')) setDeleting(null);
          }}
        >
          This {deleting.label} will be permanently removed.
        </Confirm>
      )}
    </>
  );
}
