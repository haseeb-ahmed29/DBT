import { useState } from 'react';
import { downloadReport } from '../../lib/api';
import { Button, Field, Select, ErrorMessage } from '../../components/UI';
export default function Reports() {
  const [form, setForm] = useState({ type: 'all', format: 'pdf', from: '', to: '' }),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await downloadReport(form);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="card">
      <span className="eyebrow">YOUR DATA, WITH YOU</span>
      <h2>Download a report</h2>
      <p className="muted">Export your own activity for review or keep a copy of your records.</p>
      <form className="form-stack" onSubmit={submit}>
        <div className="form-grid">
          <Select label="Include" value={form.type} onChange={(e) => set('type', e.target.value)}>
            <option value="all">All fitness records</option>
            <option value="workouts">Workouts & routines</option>
            <option value="nutrition">Meals & nutrition</option>
            <option value="progress">Progress measurements</option>
          </Select>
          <Select
            label="File format"
            value={form.format}
            onChange={(e) => set('format', e.target.value)}
          >
            <option value="pdf">PDF · Readable report</option>
            <option value="csv">CSV · Spreadsheet</option>
            <option value="json">JSON · Full record details</option>
          </Select>
          <Field
            label="From (optional)"
            type="date"
            max={form.to || undefined}
            value={form.from}
            onChange={(e) => set('from', e.target.value)}
          />
          <Field
            label="To (optional)"
            type="date"
            min={form.from || undefined}
            value={form.to}
            onChange={(e) => set('to', e.target.value)}
          />
        </div>
        <p className="small muted">
          Exports use kg, cm, km and minutes for consistency. Leave dates blank for all dates. Up to
          10,000 records per category per export.
        </p>
        <ErrorMessage message={error} />
        <div className="form-footer">
          <Button type="submit" busy={busy}>
            Download report
          </Button>
        </div>
      </form>
    </section>
  );
}
