import { useState } from 'react';
import { api } from '../../lib/api';
import { Button, Field, Select, Textarea, ErrorMessage } from '../../components/UI';
export default function Support() {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [result, setResult] = useState(null);
  async function submit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    setBusy(true);
    setError('');
    try {
      const data = await api('/support', {
        method: 'POST',
        body: Object.fromEntries(new FormData(form))
      });
      setResult(data);
      form.reset();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <section className="card">
        <h2>A little help, when you need it</h2>
        <div className="faq">
          <details>
            <summary>Who can see my records?</summary>
            <p>
              Only you can access your workout, meal and progress records. Community visibility
              shares only your name, username, photo and content you publish.
            </p>
          </details>
          <details>
            <summary>How are calorie totals calculated?</summary>
            <p>
              You enter nutrients for each food portion. CoreX adds those values for the meal and
              the day. It does not estimate calories from food names or photos.
            </p>
          </details>
          <details>
            <summary>What do the status colors mean?</summary>
            <p>
              Green means completed or closer to your personal target. Yellow means planned, holding
              steady, or an edit action. Red means delete, an error, or further from your target.
              These labels do not evaluate medical fitness.
            </p>
          </details>
          <details>
            <summary>Why did I not receive an email reminder?</summary>
            <p>
              Email reminders must be enabled in Preferences and on the reminder or scheduled
              workout, with your correct timezone selected. The server and email service must also
              be running.
            </p>
          </details>
        </div>
      </section>
      <section className="card">
        <h2>Send feedback or report an issue</h2>
        <p className="muted">
          Your message is saved in the project and emailed to support when email delivery is
          configured.
        </p>
        {result && (
          <div className={'alert ' + (result.emailSent ? 'success' : 'neutral')} role="status">
            {result.message}
            <small className="table-sub">Reference: {result.ticketId}</small>
          </div>
        )}
        <form className="form-stack" onSubmit={submit}>
          <Select label="Topic" name="topic">
            <option value="issue">Report an issue</option>
            <option value="feedback">Share feedback</option>
            <option value="question">Ask a question</option>
          </Select>
          <Field label="Subject" name="subject" required maxLength={100} />
          <Textarea label="Message" name="message" required maxLength={3000} />
          <ErrorMessage message={error} />
          <div className="form-footer">
            <Button busy={busy} type="submit">
              Send message
            </Button>
          </div>
        </form>
      </section>
    </>
  );
}
