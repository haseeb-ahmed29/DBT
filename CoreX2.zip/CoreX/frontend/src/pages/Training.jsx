import { useEffect, useState } from 'react';
import { Dumbbell } from 'lucide-react';
import { Button, Field, Select, ErrorMessage } from '../components/UI';
import Modal from '../components/Modal';
import WorkoutForm from '../components/forms/WorkoutForm';
import { useData } from '../hooks/useData';
import { useToast } from '../context/ToastContext';

const groups = {
  Chest: /chest|pectoral/i,
  Back: /back|latissimus|^lats$|traps|rhomboid/i,
  Shoulders: /shoulder|delt/i,
  Biceps: /biceps/i,
  Triceps: /triceps/i,
  Legs: /quad|hamstring|calf|calves|adductor|abductor|tibialis/i,
  Glutes: /glute/i,
  'Abs / core': /abdominal|^abs$|core|oblique/i,
  Cardio: /cardio/i,
  'Full body': /full.body/i
};
const display = (values) => values?.join(', ') || 'Unavailable';
function signed(path, token) {
  return path && token
    ? 'https://api.musclewiki.com' + path + '?token=' + encodeURIComponent(token)
    : undefined;
}

function Player({ exercise, token, renew }) {
  const [index, setIndex] = useState(0),
    [failed, setFailed] = useState(false);
  const videos = exercise.videos,
    current = videos[index];
  useEffect(() => setFailed(false), [index, token]);
  if (!current) return <p>Demonstration unavailable.</p>;
  return (
    <>
      {videos.length > 1 && (
        <Select
          label="Demonstration angle"
          value={index}
          onChange={(e) => setIndex(Number(e.target.value))}
        >
          {videos.map((v, i) => (
            <option key={i} value={i}>
              {v.label || 'View ' + (i + 1)}
            </option>
          ))}
        </Select>
      )}
      {token && !failed && (
        <video
          key={current.path + token}
          className="training-video"
          aria-label={exercise.name + ' demonstration'}
          src={signed(current.path, token)}
          poster={signed(current.poster, token)}
          muted
          playsInline
          loop
          controls
          preload="none"
          onError={() => setFailed(true)}
        />
      )}
      {(!token || failed) && (
        <p>
          Demonstration unavailable.{' '}
          <Button
            onClick={() => {
              setFailed(false);
              renew();
            }}
          >
            Retry media
          </Button>
        </p>
      )}
    </>
  );
}

export default function Training() {
  const facets = useData('/training/filters'),
    media = useData('/training/media-token');
  const [search, setSearch] = useState(''),
    [filters, setFilters] = useState({}),
    [page, setPage] = useState(1);
  const [selected, select] = useState(null),
    [logging, log] = useState(false);
  const toast = useToast();
  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters((f) => ({ ...f, search: search.trim() }));
      setPage(1);
    }, 350);
    return () => clearTimeout(timer);
  }, [search]);
  useEffect(() => {
    if (!media.data || media.error) return;
    const timer = setTimeout(media.reload, Math.max(1000, media.data.until - Date.now() - 30000));
    return () => clearTimeout(timer);
  }, [media.data, media.error, media.reload]);
  const change = (key, value) => {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  };
  const query = new URLSearchParams({ page: String(page) });
  for (const key of ['search', 'difficulty', 'category'])
    if (filters[key]) query.set(key, filters[key]);
  const options = facets.data || {},
    muscleValues = options.muscles || [];
  const muscleGroup = groups[filters.group];
  if (muscleGroup) {
    const matches = muscleValues.filter((v) => muscleGroup.test(v));
    matches.forEach((v) => query.append('muscles', v));
  } else if (filters.group) query.set('muscles', filters.group);
  const list = useData('/training?' + query);
  const token = media.data?.token;
  const retry = () => {
    list.reload();
    facets.reload();
    media.reload();
  };
  const close = () => {
    select(null);
    log(false);
  };
  return (
    <div className="form-stack">
      <header>
        <h1>Training</h1>
        <p className="muted">Find an exercise, watch its demonstration, and log your sets.</p>
      </header>
      <section className="card form-stack" aria-label="Exercise filters">
        <Field
          label="Search exercises"
          type="search"
          maxLength={100}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="form-grid three">
          <Select
            label="Muscle group"
            value={filters.group || ''}
            onChange={(e) => change('group', e.target.value)}
          >
            <option value="">All muscle groups</option>
            {Object.entries(groups)
              .filter(([, re]) => muscleValues.some((v) => re.test(v)))
              .map(([name]) => (
                <option key={name}>{name}</option>
              ))}
            {muscleValues
              .filter((v) => !Object.keys(groups).includes(v))
              .map((v) => (
                <option key={v}>{v}</option>
              ))}
          </Select>
          {[
            ['category', 'Equipment', options.categories],
            ['difficulty', 'Difficulty', options.difficulties]
          ].map(([key, label, values]) => (
            <Select
              key={key}
              label={label}
              value={filters[key] || ''}
              onChange={(e) => change(key, e.target.value)}
            >
              <option value="">All {key === 'category' ? 'equipment' : 'levels'}</option>
              {values?.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </Select>
          ))}
        </div>
      </section>
      {(list.error || facets.error || media.error) && (
        <div role="alert">
          <ErrorMessage message={list.error || facets.error || media.error} />
          <Button onClick={retry}>Retry</Button>
        </div>
      )}
      {list.loading ? (
        <div className="training-grid" role="status" aria-label="Loading exercises">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="card training-placeholder">
              Loading exercise…
            </div>
          ))}
        </div>
      ) : (
        !list.error &&
        list.data && (
          <>
            <p role="status">{list.data.total} exercises</p>
            <div className="training-grid">
              {list.data.exercises.map((ex) => (
                <button
                  type="button"
                  key={ex.id}
                  className="card training-card"
                  onClick={() => select(ex)}
                >
                  <span className="training-preview">
                    <Dumbbell aria-hidden="true" />
                    {token && ex.videos[0]?.poster && (
                      <img
                        key={token}
                        loading="lazy"
                        alt=""
                        src={signed(ex.videos[0].poster, token)}
                        onError={(e) => {
                          e.currentTarget.hidden = true;
                        }}
                      />
                    )}
                  </span>
                  <strong>{ex.name}</strong>
                  <span>{display(ex.muscles)}</span>
                  <small>{ex.equipment || 'Equipment unavailable'}</small>
                </button>
              ))}
            </div>
            {!list.data.total && (
              <p>No exercises match your filters. Try another muscle group or search term.</p>
            )}
            {list.data.total > list.data.pageSize && (
              <nav className="training-pager" aria-label="Exercise pages">
                <Button disabled={page === 1} onClick={() => setPage(page - 1)}>
                  Previous
                </Button>
                Page {page} of {Math.ceil(list.data.total / list.data.pageSize)}
                <Button
                  disabled={page * list.data.pageSize >= list.data.total}
                  onClick={() => setPage(page + 1)}
                >
                  Next
                </Button>
              </nav>
            )}
          </>
        )
      )}
      <small className="muted">Exercise data and videos provided by MuscleWiki.com</small>
      {selected && (
        <Modal title={logging ? 'Log workout' : selected.name} onClose={close} wide>
          {logging ? (
            <WorkoutForm
              kind="session"
              exerciseName={selected.name.slice(0, 100)}
              onClose={close}
              onSaved={() => {
                close();
                toast('Workout saved');
              }}
            />
          ) : (
            <div className="form-stack">
              <Player exercise={selected} token={token} renew={media.reload} />
              <p>
                <strong>Target muscles</strong> · {display(selected.muscles)}
                <br />
                <strong>Secondary muscles</strong> · {display(selected.secondary)}
                <br />
                <strong>Equipment</strong> · {selected.equipment || 'Unavailable'}
                <br />
                <strong>Difficulty</strong> · {selected.difficulty || 'Unavailable'}
              </p>
              <h3>Instructions</h3>
              {selected.steps?.length ? (
                <ol>
                  {selected.steps.map((step, i) => (
                    <li key={i}>{step}</li>
                  ))}
                </ol>
              ) : (
                <p>Instructions unavailable.</p>
              )}
              <Button onClick={() => log(true)}>Log this exercise</Button>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}
