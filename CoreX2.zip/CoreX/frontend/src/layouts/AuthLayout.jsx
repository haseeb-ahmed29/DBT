import { Outlet, Link } from 'react-router-dom';
import Brand from '../components/Brand';
import training from '../assets/images/training.png';
export default function AuthLayout() {
  return (
    <main className="auth-layout">
      <section className="auth-form-side">
        <Link to="/login" className="brand-link">
          <Brand />
        </Link>
        <div className="auth-form">
          <Outlet />
        </div>
        <p className="auth-footer">Your pace. Your progress. Your space.</p>
      </section>
      <aside className="auth-visual">
        <img src={training} alt="Athlete preparing for a workout" />
        <div className="auth-story">
          <span className="eyebrow">A LITTLE BETTER, EVERY DAY</span>
          <h2>
            Build habits.
            <br />
            Feel the change.
          </h2>
          <p>
            Workouts, meals and progress.
            <br />
            One simple space that is yours.
          </p>
          <span className="story-pill">CoreX / Fit Zone</span>
        </div>
      </aside>
    </main>
  );
}
