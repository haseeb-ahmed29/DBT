import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword } from '../src/utils/password.js';
import {
  weekStart,
  addDays,
  localDate,
  localTime,
  safeTimezone,
  zonedDateTimeToUtc,
  literalRegex
} from '../src/utils/dates.js';
import { cleanEnv, getConfig } from '../src/config/env.js';
import { getLocalLanIps, isOriginAllowed } from '../src/middleware/auth.js';
import {
  welcomeEmail,
  passwordResetEmail,
  reminderEmail,
  workoutReminderEmail,
  supportTicketEmail
} from '../src/services/emailTemplates.js';
import { weightStatus } from '../src/controllers/dashboardController.js';
import { csvCell } from '../src/services/reports.js';
import { date, mealSchema, workoutSchema } from '../src/validators/index.js';

test('passwords are salted, verifiable, and reject a wrong password', async () => {
  const a = await hashPassword('secure-password-123'),
    b = await hashPassword('secure-password-123');
  assert.notEqual(a, b);
  assert.equal(await verifyPassword('secure-password-123', a), true);
  assert.equal(await verifyPassword('wrong', a), false);
});
test('calendar calculations handle Sunday, month boundaries and user timezones', () => {
  assert.equal(weekStart('2026-11-22'), '2026-11-16');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(localDate('Asia/Karachi', new Date('2026-11-17T22:00:00Z')), '2026-11-18');
});
test('status compares distance to a personal goal for gain and loss goals', () => {
  assert.equal(weightStatus([{ value: 80 }, { value: 79 }], 75).tone, 'success');
  assert.equal(weightStatus([{ value: 60 }, { value: 61 }], 65).tone, 'success');
  assert.equal(weightStatus([{ value: 80 }, { value: 81 }], 75).tone, 'danger');
  assert.equal(weightStatus([{ value: 80 }, { value: 80 }], 75).tone, 'warning');
  assert.equal(weightStatus([{ value: 75.1 }], 75).label, 'At your target');
  assert.equal(weightStatus([], null).tone, 'neutral');
});
test('CSV cells escape quotes and spreadsheet formulas', () => {
  assert.equal(csvCell('a"b'), '"a""b"');
  assert.equal(csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.ok(csvCell('  +SUM(1)').startsWith('"\''));
  assert.ok(csvCell('\tcommand').startsWith('"\''));
});
test('search terms are literal, not executable regular expressions', () => {
  const pattern = new RegExp(literalRegex('Bench (heavy).*'), 'i');
  assert.equal(pattern.test('Bench (heavy).*'), true);
  assert.equal(pattern.test('Bench heavy123'), false);
});
test('impossible dates and invalid nutrient values are rejected', () => {
  assert.equal(date.safeParse('2026-02-30').success, false);
  assert.equal(date.safeParse('2024-02-29').success, true);
  assert.equal(
    mealSchema.safeParse({
      date: '2026-11-17',
      mealType: 'lunch',
      foods: [{ name: 'Rice', quantity: '1 bowl', calories: -2, protein: 0, carbs: 1, fat: 0 }]
    }).success,
    false
  );
  assert.equal(
    workoutSchema.safeParse({
      kind: 'session',
      title: 'Empty',
      date: '2026-11-17',
      category: 'strength',
      status: 'completed',
      duration: 20,
      exercises: []
    }).success,
    false
  );
  assert.equal(
    workoutSchema.safeParse({
      kind: 'session',
      title: 'Planned run',
      date: '2026-11-17',
      category: 'cardio',
      status: 'planned',
      duration: 30,
      reminderEnabled: true,
      scheduledTime: '',
      exercises: [{ name: 'Run', sets: 0, reps: 0, weightKg: 0, distanceKm: 5, minutes: 30, notes: '' }]
    }).success,
    false
  );
});
test('env cleaning strips quotes/whitespace and normalizes CLIENT_URL trailing slashes', () => {
  assert.equal(cleanEnv('  "my-secret-value"  '), 'my-secret-value');
  assert.equal(cleanEnv(" 'abc123' "), 'abc123');
  const cfg = getConfig({
    mongoUri: 'mongodb://localhost/test',
    sessionSecret: 'a-very-long-random-session-secret-with-32-chars',
    clientUrl: 'http://localhost:5173///'
  });
  assert.equal(cfg.clientUrl, 'http://localhost:5173');
});
test('timezone helpers handle zoned timestamps and invalid timezone fallback', () => {
  assert.equal(safeTimezone('Invalid/Zone'), 'UTC');
  assert.equal(localTime('Asia/Karachi', new Date('2026-11-17T10:05:00Z')), '15:05');
  assert.equal(
    zonedDateTimeToUtc('2026-11-17', '15:05', 'Asia/Karachi').toISOString(),
    '2026-11-17T10:05:00.000Z'
  );
});
test('development origin checks allow localhost and local LAN IPs while production stays strict', () => {
  assert.equal(isOriginAllowed('http://localhost:5173', 'http://10.0.0.5:5173', 'development', 5000), true);
  assert.equal(isOriginAllowed('http://127.0.0.1:5173', 'http://10.0.0.5:5173', 'development', 5000), true);
  for (const ip of getLocalLanIps()) {
    assert.equal(isOriginAllowed(`http://${ip}:5173`, 'http://localhost:5173', 'development', 5000), true);
    assert.equal(isOriginAllowed(`http://${ip}:4173`, 'http://localhost:5173', 'development', 5000), true);
  }
  assert.equal(isOriginAllowed('https://attacker.test', 'http://localhost:5173', 'development', 5000), false);
  assert.equal(isOriginAllowed('http://127.0.0.1:5173', 'http://localhost:5173', 'production', 5000), false);
});
test('HTML email templates render branded responsive HTML and escape untrusted input', () => {
  const xss = '<script>alert(1)</script>';
  const welcome = welcomeEmail({ name: xss, appUrl: 'http://localhost:5173' });
  assert.ok(welcome.html.includes('#fb7359'));
  assert.ok(welcome.html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
  assert.ok(!welcome.html.includes('<script>alert(1)</script>'));
  assert.ok(welcome.html.includes('@media only screen and (max-width:600px)'));

  const reset = passwordResetEmail({
    name: 'Alice',
    resetUrl: 'http://localhost:5173/reset-password?token=' + 'a'.repeat(64)
  });
  assert.ok(reset.html.includes('Choose a new password'));
  assert.ok(reset.text.includes('token=' + 'a'.repeat(64)));

  const rem = reminderEmail({
    name: 'Alice',
    title: 'Drink water',
    type: 'goal',
    time: '09:00',
    timezone: 'Asia/Karachi',
    appUrl: 'http://localhost:5173'
  });
  assert.ok(rem.html.includes('Drink water'));
  assert.ok(rem.html.includes('09:00'));

  const workoutMail = workoutReminderEmail({
    name: 'Alice',
    title: 'Morning run',
    date: '2026-11-27',
    time: '07:30',
    timezone: 'Asia/Karachi',
    duration: 30,
    category: 'cardio',
    appUrl: 'http://localhost:5173'
  });
  assert.ok(workoutMail.html.includes('Morning run'));
  assert.ok(workoutMail.html.includes('30 min'));

  const ticket = supportTicketEmail({
    ticketId: 'T-1',
    fromEmail: 'alice@example.com',
    fromName: 'Alice',
    topic: 'issue',
    subject: 'Help <b>now</b>',
    message: 'Line 1\n\nLine 2'
  });
  assert.ok(ticket.html.includes('Help &lt;b&gt;now&lt;/b&gt;'));
});
