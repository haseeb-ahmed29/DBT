// HTTP contracts using in-memory model doubles. Does NOT validate MongoDB query/transaction behavior.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import mongoose from 'mongoose';
import request from 'supertest';
import { installMemoryModels } from './helpers/memoryModels.js';
import { SMTPServer } from 'smtp-server';
import { createApp } from '../src/app.js';
import { getConfig } from '../src/config/env.js';
import { createEmailService } from '../src/services/email.js';
import { runReminders } from '../src/services/reminders.js';
import User from '../src/models/User.js';
import AuthToken from '../src/models/AuthToken.js';
import Notification from '../src/models/Notification.js';
import Workout from '../src/models/Workout.js';
import Meal from '../src/models/Meal.js';
import Progress from '../src/models/Progress.js';
import Reminder from '../src/models/Reminder.js';
import { tokenHash } from '../src/utils/password.js';
import { localDate } from '../src/utils/dates.js';

let memory, app, store, smtp, email, alice, bob, aToken, bToken, aUser, bUser;
const inbox = [];
const password = 'Test-password-2026';
const day = localDate('Asia/Karachi');
const workout = {
  kind: 'session',
  title: 'Strength [A]',
  date: day,
  category: 'strength',
  status: 'completed',
  duration: 35,
  tags: ['upper'],
  exercises: [
    { name: 'Bench press', sets: 3, reps: 8, weightKg: 30, distanceKm: 0, minutes: 0, notes: '' }
  ],
  notes: ''
};
const meal = {
  date: day,
  mealType: 'lunch',
  foods: [
    { name: 'Rice', quantity: '1 bowl', calories: 220, protein: 5, carbs: 45, fat: 1 },
    { name: 'Chicken', quantity: '100 g', calories: 165, protein: 31, carbs: 0, fat: 3.6 }
  ],
  notes: ''
};
async function mutate(agent, token, method, path, body, expected = 200) {
  return agent[method](path).set('X-CSRF-Token', token).send(body).expect(expected);
}
async function session(agent) {
  return (await agent.get('/api/auth/session').expect(200)).body.csrfToken;
}
async function register(agent, name) {
  const token = await session(agent);
  return mutate(
    agent,
    token,
    'post',
    '/api/auth/register',
    {
      name,
      username: name.toLowerCase(),
      email: name.toLowerCase() + '@example.com',
      password,
      consent: true
    },
    201
  );
}
function latestLink(kind) {
  const message = [...inbox].reverse().find((text) => text.includes(kind));
  assert.ok(message, 'SMTP capture should contain ' + kind);
  const decoded = message.replace(/=\r?\n/g, '').replaceAll('=3D', '=');
  return decoded.match(/token=([a-f0-9]{64})/)[1];
}
before(async () => {
  memory = installMemoryModels();
  smtp = new SMTPServer({
    authOptional: true,
    disabledCommands: ['STARTTLS'],
    onData(stream, session, callback) {
      let text = '';
      stream.on('data', (chunk) => (text += chunk.toString()));
      stream.on('end', () => {
        inbox.push(text);
        callback();
      });
    }
  });
  await new Promise((resolve) => smtp.listen(0, '127.0.0.1', resolve));
  const config = getConfig({
    nodeEnv: 'test',
    mongoUri: 'mongodb://unused.test/corex_contracts',
    sessionSecret: 'local-test-secret-only-not-for-production-123456',
    clientUrl: 'http://localhost:5173',
    cloudinary: { cloud_name: 'test', api_key: 'test', api_secret: 'test' },
    smtp: {
      host: '127.0.0.1',
      port: smtp.server.address().port,
      secure: false,
      requireTLS: false,
      from: 'CoreX <test@example.com>',
      supportEmail: 'support@corex.test'
    }
  });
  email = createEmailService(config.smtp);
  // Inject only the external Cloudinary boundary; database, sessions and SMTP are real local services.
  const media = {
    enabled: true,
    uploadAvatar: async (file) => {
      assert.ok(file.buffer.length);
      return { publicId: 'test/avatar', version: 1 };
    },
    remove: async () => {},
    read: async () => Buffer.from('test-image')
  };
  ({ app, store } = createApp(config, { email, media, store: memory.store }));
  for (const model of Object.values(mongoose.models)) await model.init();
  alice = request.agent(app);
  bob = request.agent(app);
  const a = await register(alice, 'Alice'),
    b = await register(bob, 'Bob');
  aToken = a.body.csrfToken;
  bToken = b.body.csrfToken;
  aUser = a.body.user;
  bUser = b.body.user;
});
after(async () => {
  if (smtp) await new Promise((resolve) => smtp.close(resolve));
  if (store) await store.close();
  memory?.restore();
});

test('registration creates private profiles, hides secrets, and stores secure cookie flags', async () => {
  assert.equal(aUser.discoverable, false);
  assert.equal(aUser.passwordHash, undefined);
  assert.equal(aUser.sessionVersion, undefined);
  const res = await alice.get('/api/auth/session');
  assert.match(res.headers['set-cookie'].join(''), /HttpOnly/);
  assert.match(res.headers['set-cookie'].join(''), /SameSite=Lax/);
  const stored = await User.findById(aUser._id).select('+passwordHash');
  assert.notEqual(stored.passwordHash, password);
});
test('unauthenticated and forged mutations are rejected', async () => {
  await request(app).get('/api/workouts').expect(401);
  await alice.post('/api/workouts').send(workout).expect(403);
  await alice
    .post('/api/workouts')
    .set('X-CSRF-Token', aToken)
    .set('Origin', 'https://attacker.test')
    .send(workout)
    .expect(403);
});
test('duplicate and invalid registrations fail', async () => {
  const agent = request.agent(app),
    token = await session(agent);
  await mutate(
    agent,
    token,
    'post',
    '/api/auth/register',
    { name: 'Other', username: 'different', email: 'alice@example.com', password, consent: true },
    409
  );
  await mutate(
    agent,
    token,
    'post',
    '/api/auth/register',
    {
      name: 'Other',
      username: 'other',
      email: 'other@example.com',
      password: 'short',
      consent: true
    },
    400
  );
});
test('workout CRUD, literal search, notifications and owner isolation', async () => {
  const created = await mutate(
    alice,
    aToken,
    'post',
    '/api/workouts',
    { ...workout, userId: bUser._id },
    201
  );
  const id = created.body.item._id;
  assert.equal(created.body.item.userId, aUser._id);
  const result = await alice.get('/api/workouts?q=%5BA%5D').expect(200);
  assert.equal(result.body.total, 1);
  assert.equal((await bob.get('/api/workouts')).body.total, 0);
  await mutate(bob, bToken, 'put', '/api/workouts/' + id, workout, 404);
  await mutate(bob, bToken, 'delete', '/api/workouts/' + id, {}, 404);
  await mutate(alice, aToken, 'put', '/api/workouts/' + id, { ...workout, duration: 45 });
  assert.equal((await alice.get('/api/notifications')).body.unread, 1);
  await mutate(alice, aToken, 'put', '/api/workouts/' + id, { ...workout, duration: 50 });
  assert.equal((await alice.get('/api/notifications')).body.unread, 1);
  await mutate(alice, aToken, 'delete', '/api/workouts/' + id, {});
  assert.equal((await alice.get('/api/workouts')).body.total, 0);
});
test('routine entries do not count as completed sessions', async () => {
  await mutate(
    alice,
    aToken,
    'post',
    '/api/workouts',
    { ...workout, kind: 'routine', title: 'Template' },
    201
  );
  assert.equal((await alice.get('/api/dashboard')).body.weekCount, 0);
});
test('meal totals are computed server-side, editable and isolated', async () => {
  const res = await mutate(alice, aToken, 'post', '/api/meals', { ...meal, calories: 99999 }, 201),
    id = res.body.item._id;
  assert.equal(res.body.item.calories, 385);
  assert.equal(res.body.item.protein, 36);
  await mutate(bob, bToken, 'put', '/api/meals/' + id, meal, 404);
  await mutate(alice, aToken, 'put', '/api/meals/' + id, { ...meal, foods: [meal.foods[0]] });
  assert.equal((await alice.get('/api/dashboard')).body.macros.calories, 220);
  await mutate(alice, aToken, 'delete', '/api/meals/' + id, {});
  assert.equal((await alice.get('/api/dashboard')).body.macros.calories, 0);
});
test('progress CRUD enforces owner and valid numeric inputs', async () => {
  const payload = { date: day, metric: 'weight', value: 78, notes: '' };
  const res = await mutate(alice, aToken, 'post', '/api/progress', payload, 201),
    id = res.body.item._id;
  await mutate(bob, bToken, 'put', '/api/progress/' + id, payload, 404);
  await mutate(alice, aToken, 'put', '/api/progress/' + id, { ...payload, value: 77 });
  assert.equal((await alice.get('/api/dashboard')).body.latestWeight, 77);
  await mutate(alice, aToken, 'post', '/api/progress', { ...payload, value: -1 }, 400);
  await mutate(alice, aToken, 'delete', '/api/progress/' + id, {});
});
test('invalid filters, IDs, ranges and NoSQL objects return validation errors', async () => {
  await alice.get('/api/progress?page=-1').expect(400);
  await alice.get('/api/meals?from=2026-02-31').expect(400);
  await alice.get('/api/dashboard?from=2000-01-01&to=2026-11-17').expect(400);
  await mutate(alice, aToken, 'delete', '/api/workouts/not-an-id', {}, 400);
  await mutate(
    alice,
    aToken,
    'post',
    '/api/auth/login',
    { identifier: { $ne: null }, password },
    400
  );
});
test('reports export valid PDF, CSV and JSON without another user’s records', async () => {
  await mutate(alice, aToken, 'post', '/api/workouts', workout, 201);
  await mutate(
    bob,
    bToken,
    'post',
    '/api/workouts',
    { ...workout, title: 'BOB PRIVATE RECORD' },
    201
  );
  const csv = await alice.get('/api/reports?format=csv&type=all').expect(200);
  assert.ok(csv.text.includes('Strength [A]'));
  assert.ok(!csv.text.includes('BOB PRIVATE RECORD'));
  const pdf = await alice.get('/api/reports?format=pdf&type=workouts').expect(200);
  assert.equal(pdf.body.subarray(0, 5).toString(), '%PDF-');
  const json = await alice.get('/api/reports?format=json&type=all').expect(200);
  assert.equal(json.body.workouts[0].userId, undefined);
});
test('profile edits, uniqueness, preferences and password-protected email changes', async () => {
  const body = {
    name: 'Alice Updated',
    username: 'alice',
    email: 'alice@example.com',
    discoverable: false
  };
  await mutate(alice, aToken, 'patch', '/api/users/me', body);
  await mutate(alice, aToken, 'patch', '/api/users/me', { ...body, username: 'bob' }, 409);
  await mutate(
    alice,
    aToken,
    'patch',
    '/api/users/me',
    { ...body, email: 'changed@example.com' },
    400
  );
  await mutate(alice, aToken, 'patch', '/api/users/me/preferences', {
    ...aUser.settings,
    units: 'imperial',
    goals: { weeklyWorkouts: 3, dailyCalories: 2200, targetWeight: 75 }
  });
  assert.equal((await alice.get('/api/auth/session')).body.user.settings.units, 'imperial');
});
test('private avatars are authorized; upload boundary and removal work', async () => {
  await alice
    .post('/api/users/me/avatar')
    .set('X-CSRF-Token', aToken)
    .attach('avatar', Buffer.from('test-image'), 'test.png')
    .expect(200);
  await alice.get('/api/users/' + aUser._id + '/avatar').expect(200);
  await bob.get('/api/users/' + aUser._id + '/avatar').expect(404);
  await mutate(alice, aToken, 'delete', '/api/users/me/avatar', {});
  await alice.get('/api/users/' + aUser._id + '/avatar').expect(404);
});
test('community is opt-in and never returns email or fitness records', async () => {
  assert.equal((await alice.get('/api/community/people')).body.total, 0);
  await mutate(alice, aToken, 'post', '/api/community/people/' + bUser._id + '/follow', {}, 403);
  for (const [agent, token, user] of [
    [alice, aToken, aUser],
    [bob, bToken, bUser]
  ])
    await mutate(agent, token, 'patch', '/api/users/me', {
      name: user.name,
      username: user.username,
      email: user.email,
      discoverable: true
    });
  const people = await alice.get('/api/community/people?q=bo').expect(200);
  assert.equal(people.body.total, 1);
  assert.equal(people.body.items[0].email, undefined);
  assert.equal(people.body.items[0].goals, undefined);
  await mutate(alice, aToken, 'post', '/api/community/people/' + bUser._id + '/follow', {});
  const post = await mutate(
    bob,
    bToken,
    'post',
    '/api/community/posts',
    { title: 'Small wins', body: 'A good session today.' },
    201
  );
  await mutate(
    alice,
    aToken,
    'post',
    '/api/community/posts/' + post.body.item._id + '/replies',
    { body: 'Well done.' },
    201
  );
  const feed = await alice.get('/api/community/posts').expect(200);
  assert.equal(feed.body.items[0].replies.length, 1);
  assert.equal(feed.body.items[0].author.email, undefined);
  await mutate(alice, aToken, 'delete', '/api/community/posts/' + post.body.item._id, {}, 404);
  await mutate(bob, bToken, 'delete', '/api/community/posts/' + post.body.item._id, {});
});
test('reminder scheduling sends emails without verification and prevents duplicates', async () => {
  const beforeInbox = inbox.length;
  const reminder = await mutate(
    alice,
    aToken,
    'post',
    '/api/reminders',
    { title: 'Move now', type: 'workout', time: '15:00', days: [2], enabled: true, email: true },
    201
  );
  await runReminders(email, new Date('2026-11-17T10:01:00Z'));
  await runReminders(email, new Date('2026-11-17T10:02:00Z'));
  assert.equal(await Notification.countDocuments({ userId: aUser._id, type: 'reminder' }), 1);
  const sentEmails = inbox.slice(beforeInbox).filter((msg) => msg.includes('Move now'));
  assert.equal(sentEmails.length, 1);
  assert.ok(sentEmails[0].includes('alice@example.com'));
  assert.ok(sentEmails[0].includes('text/html'));
  await mutate(bob, bToken, 'delete', '/api/reminders/' + reminder.body.item._id, {}, 404);
  await mutate(alice, aToken, 'delete', '/api/reminders/' + reminder.body.item._id, {});
});
test('scheduled workout reminders deliver both in-app notification and email once', async () => {
  const beforeInbox = inbox.length;
  const scheduled = await mutate(
    alice,
    aToken,
    'post',
    '/api/workouts',
    {
      ...workout,
      title: 'Evening scheduled run',
      date: '2026-11-17',
      status: 'planned',
      scheduledTime: '18:30',
      reminderEnabled: true,
      reminderEmail: true
    },
    201
  );
  await runReminders(email, new Date('2026-11-17T13:25:00Z'));
  assert.equal(
    await Notification.countDocuments({ userId: aUser._id, title: 'Scheduled workout · Evening scheduled run' }),
    0
  );
  await runReminders(email, new Date('2026-11-17T13:31:00Z'));
  await runReminders(email, new Date('2026-11-17T13:32:00Z'));
  assert.equal(
    await Notification.countDocuments({ userId: aUser._id, title: 'Scheduled workout · Evening scheduled run' }),
    1
  );
  const workoutEmails = inbox
    .slice(beforeInbox)
    .filter((msg) => msg.includes('Evening scheduled run'));
  assert.equal(workoutEmails.length, 1);
  assert.ok(workoutEmails[0].includes('alice@example.com'));
  await mutate(alice, aToken, 'delete', '/api/workouts/' + scheduled.body.item._id, {});
});
test('notification read state is scoped to its owner', async () => {
  const item = (await alice.get('/api/notifications')).body.items[0];
  await mutate(bob, bToken, 'patch', '/api/notifications/' + item._id + '/read', {}, 404);
  await mutate(alice, aToken, 'patch', '/api/notifications/read-all', {});
  assert.equal((await alice.get('/api/notifications')).body.unread, 0);
});
test('email verification endpoints are removed and emailVerifiedAt is omitted', async () => {
  assert.equal((await alice.get('/api/auth/session')).body.user.emailVerifiedAt, undefined);
  await mutate(alice, aToken, 'post', '/api/auth/verification', {}, 404);
  await mutate(alice, aToken, 'post', '/api/auth/verify-email', { token: 'a'.repeat(64) }, 404);
});
test('support persists the ticket and submits mail over SMTP', async () => {
  const res = await mutate(
    alice,
    aToken,
    'post',
    '/api/support',
    { topic: 'issue', subject: 'Test report', message: 'Check local SMTP integration.' },
    201
  );
  assert.equal(res.body.emailSent, true);
  assert.ok(inbox.some((message) => message.includes('Test report')));
});
test('password changes keep current session but revoke other sessions', async () => {
  const other = request.agent(app),
    csrf = await session(other);
  await mutate(other, csrf, 'post', '/api/auth/login', { identifier: 'alice', password });
  await mutate(alice, aToken, 'patch', '/api/users/me/password', {
    currentPassword: password,
    newPassword: 'Updated-password-2026'
  });
  await other.get('/api/workouts').expect(401);
  await alice.get('/api/workouts').expect(200);
});
test('SMTP reset link is hashed, single-use and revokes all old sessions', async () => {
  const anonymous = request.agent(app),
    token = await session(anonymous);
  await mutate(anonymous, token, 'post', '/api/auth/forgot-password', {
    email: 'alice@example.com'
  });
  const resetToken = latestLink('reset-password');
  const stored = await AuthToken.findOne({ userId: aUser._id, purpose: 'reset' });
  assert.equal(stored.digest, tokenHash(resetToken));
  assert.notEqual(stored.digest, resetToken);
  await mutate(anonymous, token, 'post', '/api/auth/reset-password', {
    token: resetToken,
    password: 'Final-password-2026'
  });
  await alice.get('/api/workouts').expect(401);
  await mutate(
    anonymous,
    token,
    'post',
    '/api/auth/reset-password',
    { token: resetToken, password: 'Final-password-2026' },
    400
  );
  alice = request.agent(app);
  const newCsrf = await session(alice);
  const login = await mutate(alice, newCsrf, 'post', '/api/auth/login', {
    identifier: 'alice',
    password: 'Final-password-2026'
  });
  aToken = login.body.csrfToken;
});
test('account deletion issues a transaction and removes only owned records (model double)', async () => {
  await mutate(alice, aToken, 'delete', '/api/users/me', { password: 'wrong-password' }, 400);
  await mutate(alice, aToken, 'delete', '/api/users/me', { password: 'Final-password-2026' });
  assert.equal(await User.countDocuments({ _id: aUser._id }), 0);
  for (const model of [Workout, Meal, Progress, Reminder, Notification])
    assert.equal(await model.countDocuments({ userId: aUser._id }), 0);
  assert.equal(await Workout.countDocuments({ userId: bUser._id }), 1);
  await alice.get('/api/workouts').expect(401);
});
