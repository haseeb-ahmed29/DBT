import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import request from 'supertest';
import trainingRoutes from '../src/routes/trainingRoutes.js';
import { errorHandler } from '../src/middleware/error.js';
function app(provider, key = 'test-only') {
  const server = express();
  server.use(trainingRoutes(provider, () => key));
  server.use(errorHandler);
  return server;
}
test('Training paginates and filters upstream, normalizes licensed streams and reuses metadata', async () => {
  let calls = 0;
  const server = app(async (url, options) => {
    calls++;
    assert.equal(options.headers['X-API-Key'], 'test-only');
    if (url.includes('?')) {
      const params = new URL(url).searchParams;
      assert.equal(params.get('offset'), '8');
      assert.deepEqual(params.getAll('muscles'), ['Biceps', 'Triceps']);
      assert.equal(params.get('search'), 'curl');
      return Response.json({ total: 9, results: [{ id: 42 }] });
    }
    return Response.json({
      id: 42,
      name: 'Test record',
      primary_muscles: ['Biceps'],
      videos: [{ url: '/stream/videos/branded/test.mp4' }, { url: 'https://example.com/test.mp4' }]
    });
  });
  for (let i = 0; i < 2; i++) {
    const { body } = await request(server)
      .get('/?page=2&search=curl&muscles=Biceps&muscles=Triceps')
      .expect(200);
    assert.equal(body.total, 9);
    assert.equal(body.exercises[0].videos.length, 1);
    assert.equal(body.exercises[0].videos[0].path, '/stream/videos/branded/test.mp4');
  }
  assert.equal(calls, 2);
});
test('Training handles missing credentials, invalid pages and provider throttling', async () => {
  await request(app(null, '')).get('/').expect(503);
  let calls = 0;
  const server = app(async () => {
    calls++;
    return new Response(null, { status: 429, headers: { 'Retry-After': '30' } });
  });
  await request(server).get('/?page=0').expect(400);
  await request(server).get('/').expect(429);
  await request(server).get('/filters').expect(429);
  assert.equal(calls, 1);
});
