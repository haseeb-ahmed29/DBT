import { timingSafeEqual } from 'node:crypto';
import { networkInterfaces } from 'node:os';
import User from '../models/User.js';
import { ApiError } from '../utils/errors.js';

export function getLocalLanIps() {
  const ips = [];
  for (const entries of Object.values(networkInterfaces())) {
    for (const info of entries || []) {
      if (info.family === 'IPv4' && !info.internal) ips.push(info.address);
    }
  }
  return [...new Set(ips)];
}

export async function requireAuth(req, res, next) {
  if (!req.session.userId) throw new ApiError(401, 'Please sign in.');
  const user = await User.findById(req.session.userId);
  if (!user || user.sessionVersion !== req.session.version) {
    req.session.destroy(() => {});
    throw new ApiError(401, 'Your session has expired. Please sign in.');
  }
  req.user = user;
  next();
}

export function getAllowedOrigins(clientUrl, nodeEnv = 'development', apiPort = null) {
  const urls = String(clientUrl || 'http://localhost:5173')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
  const origins = new Set();
  const devPorts = new Set();
  for (const raw of urls) {
    const url = new URL(raw);
    origins.add(url.origin);
    devPorts.add(url.port || '5173');
  }
  if (nodeEnv === 'development') {
    devPorts.add('5173');
    devPorts.add('4173');
    if (apiPort) devPorts.add(String(apiPort));
    const hosts = ['localhost', '127.0.0.1', ...getLocalLanIps()];
    for (const port of devPorts) {
      const suffix = port === '80' ? '' : ':' + port;
      for (const host of hosts) origins.add('http://' + host + suffix);
    }
  }
  return origins;
}

export function isOriginAllowed(origin, clientUrl, nodeEnv = 'development', apiPort = null) {
  if (!origin) return true;
  return getAllowedOrigins(clientUrl, nodeEnv, apiPort).has(origin);
}

export function csrfProtection(clientUrl, nodeEnv = 'development', apiPort = null) {
  return (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    if (req.headers.origin && !isOriginAllowed(req.headers.origin, clientUrl, nodeEnv, apiPort))
      throw new ApiError(403, 'Request origin is not allowed.');
    const actual = Buffer.from(req.get('X-CSRF-Token') || '');
    const expected = Buffer.from(req.session.csrfToken || '');
    if (!actual.length || actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
      throw new ApiError(403, 'Session protection expired. Refresh the page and retry.');
    }
    next();
  };
}
