import { ZodError } from 'zod';

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);
  if (error instanceof ZodError) {
    return res
      .status(400)
      .json({
        message: error.issues[0]?.message || 'Please check your input.',
        fields: error.issues.map((issue) => ({
          field: issue.path.join('.'),
          message: issue.message
        }))
      });
  }
  if (error.code === 11000)
    return res
      .status(409)
      .json({
        message: 'That email or username is already in use, or this record already exists.'
      });
  if (error.code === 'LIMIT_FILE_SIZE')
    return res.status(400).json({ message: 'Choose an image smaller than 5 MB.' });
  if (error.name === 'MulterError')
    return res.status(400).json({ message: 'Invalid image upload request.' });
  if (error.name === 'CastError') return res.status(400).json({ message: 'Invalid record value.' });
  const status = error.status || 500;
  if (status >= 500)
    console.error(JSON.stringify({ level: 'error', path: req.path, message: error.message }));
  res
    .status(status)
    .json({ message: status === 500 ? 'Something went wrong. Please try again.' : error.message });
}
