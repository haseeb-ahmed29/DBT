import mongoose from 'mongoose';
import { ApiError } from '../utils/errors.js';
import { querySchema } from '../validators/index.js';

export const validate = (schema) => (req, res, next) => {
  req.body = schema.parse(req.body);
  next();
};
export const validateQuery = (req, res, next) => {
  req.filters = querySchema.parse(req.query);
  next();
};
export function validId(req, res, next) {
  if (!mongoose.isObjectIdOrHexString(req.params.id)) throw new ApiError(400, 'Invalid record ID.');
  next();
}
