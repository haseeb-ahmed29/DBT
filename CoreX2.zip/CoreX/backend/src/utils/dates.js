export function safeTimezone(timeZone = 'Asia/Karachi') {
  try {
    new Intl.DateTimeFormat('en-CA', { timeZone });
    return timeZone;
  } catch {
    return 'UTC';
  }
}

export function localDate(timeZone = 'Asia/Karachi', value = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: safeTimezone(timeZone),
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(value);
}

export function localTime(timeZone = 'Asia/Karachi', value = new Date()) {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: safeTimezone(timeZone),
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23'
  }).format(value);
}

export function zonedDateTimeToUtc(dateStr, timeStr, timeZone = 'Asia/Karachi') {
  const zone = safeTimezone(timeZone);
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);
  const target = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
  const partsFormat = new Intl.DateTimeFormat('en-CA', {
    timeZone: zone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
  });
  let utcMs = target;
  for (let i = 0; i < 2; i++) {
    const parts = Object.fromEntries(
      partsFormat
        .formatToParts(new Date(utcMs))
        .filter((part) => part.type !== 'literal')
        .map((part) => [part.type, Number(part.value)])
    );
    const inZone = Date.UTC(
      parts.year,
      parts.month - 1,
      parts.day,
      parts.hour === 24 ? 0 : parts.hour,
      parts.minute,
      parts.second,
      0
    );
    utcMs += target - inZone;
  }
  return new Date(utcMs);
}

export function addDays(date, days) {
  const value = new Date(date + 'T12:00:00Z');
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function weekStart(date) {
  const day = new Date(date + 'T12:00:00Z').getUTCDay();
  return addDays(date, -(day === 0 ? 6 : day - 1));
}

export function dayRange(start, end) {
  const dates = [];
  for (let date = start; date <= end; date = addDays(date, 1)) dates.push(date);
  return dates;
}

export function dateFilter(query) {
  const date = {};
  if (query.from) date.$gte = query.from;
  if (query.to) date.$lte = query.to;
  return Object.keys(date).length ? { date } : {};
}

export const literalRegex = (text) => text.replace(/[.*+?^$\{\}()|[\]\\]/g, '\\$&');

export function pagination(query) {
  return {
    page: query.page || 1,
    limit: query.limit || 20,
    skip: ((query.page || 1) - 1) * (query.limit || 20)
  };
}
