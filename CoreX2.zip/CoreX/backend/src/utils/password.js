import { randomBytes, scrypt, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const derive = promisify(scrypt);
const parameters = { N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 };

export async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const key = await derive(password, salt, 64, parameters);
  return ['scrypt', salt, key.toString('hex')].join('$');
}

export async function verifyPassword(password, stored) {
  const [algorithm, salt, digest] = (stored || '').split('$');
  if (algorithm !== 'scrypt' || !salt || !digest) return false;
  const expected = Buffer.from(digest, 'hex');
  const actual = await derive(password, salt, 64, parameters);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export const randomToken = () => randomBytes(32).toString('hex');
export const tokenHash = (value) => createHash('sha256').update(value).digest('hex');
