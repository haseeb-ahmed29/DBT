import User from '../models/User.js';
import Workout from '../models/Workout.js';
import Meal from '../models/Meal.js';
import Progress from '../models/Progress.js';
import { hashPassword } from '../utils/password.js';
import { localDate, addDays } from '../utils/dates.js';
export async function seedDemo({ email, password, username = 'corex_demo', name = 'Alex Morgan' }) {
  if (await User.exists({ $or: [{ email }, { username }] }))
    throw new Error(
      'Demo email or username already exists. Seed never overwrites accounts. Choose a new email/username.'
    );
  const user = await User.create({
    email,
    username,
    name,
    passwordHash: await hashPassword(password),
    consentAt: new Date(),
    goals: { weeklyWorkouts: 4, dailyCalories: 2200, targetWeight: 75 }
  });
  const today = localDate(user.settings.timezone);
  const exercise = (name, sets, reps, weightKg) => ({
    name,
    sets,
    reps,
    weightKg,
    distanceKm: 0,
    minutes: 0,
    notes: ''
  });
  await Workout.insertMany([
    ...[0, 1, 3, 5, 8, 10, 13, 15, 18, 22, 25].map((offset, index) => ({
      userId: user._id,
      date: addDays(today, -offset),
      kind: 'session',
      title: index % 2 ? 'Full body strength' : 'Upper body strength',
      category: 'strength',
      status: 'completed',
      duration: 35 + (index % 3) * 5,
      tags: ['gym'],
      notes: '',
      exercises: [
        exercise('Bench press', 3, 10, 30),
        exercise('Dumbbell rows', 3, 12, 15),
        exercise('Shoulder press', 3, 10, 12)
      ]
    })),
    {
      userId: user._id,
      date: today,
      kind: 'routine',
      title: 'Everyday strength',
      category: 'strength',
      status: 'planned',
      duration: 40,
      tags: ['full body'],
      exercises: [exercise('Squats', 3, 10, 20), exercise('Push-ups', 3, 12, 0)],
      notes: 'Warm up before your session.'
    },
    {
      userId: user._id,
      date: addDays(today, 1),
      kind: 'session',
      title: 'Evening walk',
      category: 'cardio',
      status: 'planned',
      duration: 30,
      tags: ['outdoors'],
      exercises: [{ ...exercise('Brisk walk', 0, 0, 0), minutes: 30, distanceKm: 2.5 }],
      notes: ''
    }
  ]);
  const meals = [];
  for (let offset = 0; offset < 30; offset++) {
    const date = addDays(today, -offset);
    for (const [type, name, calories, protein, carbs, fat] of [
      ['breakfast', 'Oats, yogurt & fruit', 480, 22, 65, 15],
      ['lunch', 'Chicken rice bowl', 650, 42, 75, 20],
      ['snack', 'Banana & almonds', 260, 6, 34, 12]
    ])
      meals.push({
        userId: user._id,
        date,
        mealType: type,
        calories: calories + (offset % 3) * 10,
        protein,
        carbs,
        fat,
        foods: [
          {
            name,
            quantity: '1 serving',
            calories: calories + (offset % 3) * 10,
            protein,
            carbs,
            fat
          }
        ],
        notes: ''
      });
    if (offset > 0)
      meals.push({
        userId: user._id,
        date,
        mealType: 'dinner',
        calories: 620,
        protein: 30,
        carbs: 70,
        fat: 23,
        foods: [
          {
            name: 'Vegetables, rice & lentils',
            quantity: '1 plate',
            calories: 620,
            protein: 30,
            carbs: 70,
            fat: 23
          }
        ],
        notes: ''
      });
  }
  await Meal.insertMany(meals);
  await Progress.insertMany(
    [28, 24, 20, 16, 12, 8, 4, 0].flatMap((offset, index) => [
      {
        userId: user._id,
        date: addDays(today, -offset),
        metric: 'weight',
        value: 79.5 - index * 0.25,
        notes: 'Morning check-in',
        exercise: ''
      },
      {
        userId: user._id,
        date: addDays(today, -offset),
        metric: 'lift',
        value: 25 + Math.floor(index / 2) * 2.5,
        exercise: 'Bench press',
        notes: ''
      }
    ])
  );
  return user;
}
