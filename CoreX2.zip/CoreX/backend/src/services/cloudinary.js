import { v2 as cloudinary } from 'cloudinary';
import sharp from 'sharp';
import { randomUUID } from 'node:crypto';
import { ApiError } from '../utils/errors.js';

export function createMediaService(config) {
  const cloudConfig = {
    cloud_name: config.cloud_name?.trim(),
    api_key: config.api_key?.trim(),
    api_secret: config.api_secret?.trim()
  };
  const enabled = Boolean(cloudConfig.cloud_name && cloudConfig.api_key && cloudConfig.api_secret);
  cloudinary.config(cloudConfig);
  return {
    enabled,
    async uploadAvatar(file, userId) {
      if (!enabled)
        throw new ApiError(
          503,
          'Add your Cloudinary credentials to backend/.env to upload profile photos.'
        );
      if (!file) throw new ApiError(400, 'Select a profile photo.');
      let buffer;
      try {
        const image = sharp(file.buffer, { limitInputPixels: 25000000 });
        const metadata = await image.metadata();
        if (!['jpeg', 'png', 'webp'].includes(metadata.format))
          throw new Error('Unsupported image');
        buffer = await image
          .rotate()
          .resize(400, 400, { fit: 'cover' })
          .webp({ quality: 85 })
          .toBuffer();
      } catch {
        throw new ApiError(400, 'Choose a valid JPG, PNG or WebP image, up to 25 megapixels.');
      }
      return new Promise((resolve, reject) => {
        cloudinary.uploader
          .upload_stream(
            {
              resource_type: 'image',
              type: 'authenticated',
              public_id: 'corex/avatars/' + userId + '/' + randomUUID()
            },
            (error, result) => {
              if (error) {
                const detail = error?.message || 'Unknown Cloudinary error';
                const status = error?.http_code;
                console.error(
                  JSON.stringify({
                    level: 'error',
                    service: 'cloudinary',
                    action: 'uploadAvatar',
                    httpCode: status,
                    message: detail
                  })
                );
                const message =
                  status === 403
                    ? 'Photo upload failed: Cloudinary denied permission (HTTP 403). Check that the API key in backend/.env has upload (create) permissions and your Cloudinary account is active.'
                    : status === 401 || /api_key|cloud_name|signature/i.test(detail)
                      ? 'Photo upload failed: Cloudinary rejected the credentials in backend/.env (' +
                        detail +
                        ').'
                      : 'Photo upload failed (' + detail + '). Check Cloudinary configuration and retry.';
                return reject(new ApiError(502, message));
              }
              resolve({
                publicId: result.public_id,
                version: result.version,
                url: result.secure_url || ''
              });
            }
          )
          .end(buffer);
      });
    },
    async remove(publicId) {
      if (enabled && publicId) {
        try {
          await cloudinary.uploader.destroy(publicId, {
            resource_type: 'image',
            type: 'authenticated',
            invalidate: true
          });
        } catch (error) {
          console.error(
            JSON.stringify({
              level: 'error',
              service: 'cloudinary',
              action: 'remove',
              message: error?.message || 'Destroy failed'
            })
          );
        }
      }
    },
    async read(avatar) {
      if (!enabled) throw new ApiError(503, 'Cloudinary is not configured.');
      const url = cloudinary.url(avatar.publicId, {
        resource_type: 'image',
        type: 'authenticated',
        secure: true,
        sign_url: true,
        version: avatar.version,
        format: 'webp'
      });
      let response = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!response.ok && avatar.url) {
        console.error(
          JSON.stringify({
            level: 'warn',
            service: 'cloudinary',
            action: 'readSignedFallback',
            status: response.status
          })
        );
        response = await fetch(avatar.url, { signal: AbortSignal.timeout(15000) });
      }
      if (!response.ok) {
        console.error(
          JSON.stringify({
            level: 'error',
            service: 'cloudinary',
            action: 'read',
            status: response.status
          })
        );
        throw new ApiError(502, 'Profile photo is temporarily unavailable.');
      }
      return Buffer.from(await response.arrayBuffer());
    }
  };
}
