import nodemailer from 'nodemailer';
import { ApiError } from '../utils/errors.js';
import { genericEmail } from './emailTemplates.js';

export function createEmailService(config) {
  const enabled = Boolean(config.host && config.from);
  const transport = enabled
    ? nodemailer.createTransport({
        host: config.host,
        port: config.port,
        secure: config.secure,
        requireTLS: config.requireTLS,
        auth: config.user ? { user: config.user, pass: config.pass } : undefined,
        connectionTimeout: 10000,
        greetingTimeout: 10000,
        socketTimeout: 15000
      })
    : null;
  return {
    enabled,
    requireConfigured() {
      if (!enabled)
        throw new ApiError(503, 'Email is not configured. Add SMTP credentials to backend/.env.');
    },
    async verify() {
      if (!enabled) return false;
      await transport.verify();
      return true;
    },
    async send(to, subject, content) {
      this.requireConfigured();
      const payload =
        content && typeof content === 'object'
          ? { text: content.text || '', html: content.html || genericEmail({ subject, text: content.text || '' }).html }
          : genericEmail({ subject, text: String(content ?? '') });
      try {
        await transport.sendMail({
          from: config.from,
          to,
          subject,
          text: payload.text,
          html: payload.html
        });
      } catch (error) {
        console.error(
          JSON.stringify({
            level: 'error',
            service: 'email',
            action: 'send',
            code: error?.code || '',
            responseCode: error?.responseCode || null,
            command: error?.command || '',
            message: error?.message || 'SMTP send failed'
          })
        );
        throw error;
      }
    }
  };
}
