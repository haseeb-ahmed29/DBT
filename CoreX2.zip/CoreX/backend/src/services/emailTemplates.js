function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatParagraphsHtml(text) {
  return String(text ?? '')
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter(Boolean)
    .map(
      (block) =>
        '<p style="margin:0 0 14px;color:#4a5160;font-size:15px;line-height:1.65;">' +
        escapeHtml(block).replaceAll('\n', '<br />') +
        '</p>'
    )
    .join('');
}

export function renderEmailLayout({
  preheader = '',
  eyebrow = 'COREX · FIT ZONE',
  title,
  intro = '',
  bodyHtml = '',
  details = [],
  ctaLabel = '',
  ctaUrl = '',
  footerNote = 'CoreX · Fit Zone — Personal Fitness Tracker'
}) {
  const detailRows = details
    .filter((item) => item && item.value != null && item.value !== '')
    .map(
      ({ label, value }) =>
        '<tr>' +
        '<td style="padding:8px 0;color:#68707e;font-size:13px;font-weight:600;width:130px;vertical-align:top;">' +
        escapeHtml(label) +
        '</td>' +
        '<td style="padding:8px 0;color:#252830;font-size:14px;font-weight:500;vertical-align:top;">' +
        escapeHtml(value) +
        '</td>' +
        '</tr>'
    )
    .join('');

  const detailsCard = detailRows
    ? '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:20px 0;background:#f7f8fc;border:1px solid #e9ebf1;border-radius:14px;">' +
      '<tr><td style="padding:14px 18px;">' +
      '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">' +
      detailRows +
      '</table>' +
      '</td></tr></table>'
    : '';

  const ctaBlock =
    ctaLabel && ctaUrl
      ? '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0 10px;">' +
        '<tr><td style="border-radius:12px;background:#fb7359;">' +
        '<a href="' +
        escapeHtml(ctaUrl) +
        '" target="_blank" rel="noopener noreferrer" style="display:inline-block;padding:13px 24px;font-size:14px;font-weight:700;color:#321d17;text-decoration:none;border-radius:12px;">' +
        escapeHtml(ctaLabel) +
        '</a>' +
        '</td></tr></table>' +
        '<p style="margin:12px 0 0;color:#68707e;font-size:12px;line-height:1.6;word-break:break-all;">' +
        'If the button does not work, open this link:<br />' +
        '<a href="' +
        escapeHtml(ctaUrl) +
        '" style="color:#d4563d;text-decoration:underline;">' +
        escapeHtml(ctaUrl) +
        '</a>' +
        '</p>'
      : '';

  return (
    '<!DOCTYPE html>' +
    '<html lang="en">' +
    '<head>' +
    '<meta charset="utf-8" />' +
    '<meta name="viewport" content="width=device-width, initial-scale=1.0" />' +
    '<title>' +
    escapeHtml(title) +
    '</title>' +
    '<style>' +
    '@media only screen and (max-width:600px){' +
    '.cx-wrap{padding:16px 10px !important;}' +
    '.cx-card-body{padding:24px 20px !important;}' +
    '.cx-title{font-size:21px !important;}' +
    '}' +
    '</style>' +
    '</head>' +
    '<body style="margin:0;padding:0;background-color:#f7f8fc;font-family:\'DM Sans\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;color:#252830;">' +
    (preheader
      ? '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">' +
        escapeHtml(preheader) +
        '</div>'
      : '') +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f7f8fc;">' +
    '<tr><td align="center" class="cx-wrap" style="padding:36px 16px;">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:580px;">' +
    '<tr><td style="padding:0 4px 18px;">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>' +
    '<td style="vertical-align:middle;">' +
    '<span style="display:inline-block;background:#10141a;color:#ffffff;padding:8px 14px;border-radius:10px;font-size:15px;font-weight:700;letter-spacing:-0.4px;">' +
    'Core<span style="color:#fb7359;font-style:italic;">X</span>' +
    '</span>' +
    '</td>' +
    '<td align="right" style="vertical-align:middle;font-size:10px;font-weight:700;letter-spacing:1.8px;color:#68707e;">' +
    'FIT ZONE' +
    '</td>' +
    '</tr></table>' +
    '</td></tr>' +
    '<tr><td style="background:#ffffff;border:1px solid #e9ebf1;border-radius:20px;overflow:hidden;box-shadow:0 8px 28px rgba(32,42,71,0.06);">' +
    '<div style="height:4px;background:#fb7359;font-size:0;line-height:0;">&nbsp;</div>' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">' +
    '<tr><td class="cx-card-body" style="padding:32px 32px 28px;">' +
    '<p style="margin:0 0 10px;font-size:10px;font-weight:700;letter-spacing:1.8px;text-transform:uppercase;color:#d4563d;">' +
    escapeHtml(eyebrow) +
    '</p>' +
    '<h1 class="cx-title" style="margin:0 0 14px;font-size:24px;line-height:1.25;letter-spacing:-0.6px;color:#252830;font-weight:700;">' +
    escapeHtml(title) +
    '</h1>' +
    (intro
      ? '<p style="margin:0 0 16px;color:#4a5160;font-size:15px;line-height:1.65;">' +
        escapeHtml(intro) +
        '</p>'
      : '') +
    bodyHtml +
    detailsCard +
    ctaBlock +
    '</td></tr></table>' +
    '</td></tr>' +
    '<tr><td style="padding:18px 8px 0;text-align:center;color:#68707e;font-size:12px;line-height:1.6;">' +
    escapeHtml(footerNote) +
    '</td></tr>' +
    '</table>' +
    '</td></tr></table>' +
    '</body></html>'
  );
}

export function welcomeEmail({ name, appUrl }) {
  const subject = 'Welcome to CoreX';
  const text =
    'Welcome, ' +
    name +
    '.\nYour personal fitness tracker is ready.\n\nOpen CoreX: ' +
    appUrl;
  const html = renderEmailLayout({
    preheader: 'Your CoreX personal fitness workspace is ready.',
    eyebrow: 'WELCOME TO YOUR FIT ZONE',
    title: 'Welcome, ' + name + '.',
    intro:
      'Your private space for workouts, nutrition, and daily progress is ready. Small steps build lasting habits.',
    details: [
      { label: 'Workspace', value: 'Private personal tracker' },
      { label: 'Included', value: 'Workouts, meals, progress & reminders' }
    ],
    ctaLabel: 'Open your dashboard',
    ctaUrl: appUrl,
    footerNote: 'CoreX · Fit Zone — Your pace. Your progress. Your space.'
  });
  return { subject, text, html };
}

export function passwordResetEmail({ name, resetUrl, expiresMinutes = 30 }) {
  const subject = 'Reset your CoreX password';
  const text =
    'Open this link within ' +
    expiresMinutes +
    ' minutes to choose a new password.\n\n' +
    resetUrl +
    '\n\nIf you did not request this, you can ignore this email.';
  const html = renderEmailLayout({
    preheader: 'Reset your CoreX password within ' + expiresMinutes + ' minutes.',
    eyebrow: 'ACCOUNT SECURITY',
    title: 'Reset your password',
    intro:
      (name ? 'Hi ' + name + ', we' : 'We') +
      ' received a request to reset the password for your CoreX account.',
    bodyHtml:
      '<p style="margin:0 0 14px;color:#4a5160;font-size:14px;line-height:1.65;">' +
      'If you did not request a password reset, you can safely ignore this message and your current password will stay unchanged.' +
      '</p>',
    details: [
      { label: 'Link validity', value: expiresMinutes + ' minutes (single use)' },
      { label: 'Security', value: 'Updating your password signs out older sessions' }
    ],
    ctaLabel: 'Choose a new password',
    ctaUrl: resetUrl,
    footerNote: 'CoreX · Fit Zone — Sent because a password reset was requested for your account.'
  });
  return { subject, text, html };
}

export function reminderEmail({ name, title, type, time, timezone, appUrl }) {
  const subject = 'CoreX reminder · ' + title;
  const text =
    title +
    '\nScheduled for ' +
    time +
    ' (' +
    timezone +
    ').\n\nManage reminders in CoreX: ' +
    appUrl +
    '/settings?tab=reminders';
  const html = renderEmailLayout({
    preheader: title + ' — scheduled for ' + time + ' (' + timezone + ').',
    eyebrow: 'SCHEDULED REMINDER',
    title,
    intro:
      (name ? 'Hi ' + name + ', here' : 'Here') +
      ' is your scheduled CoreX nudge to stay consistent today.',
    details: [
      { label: 'Category', value: type ? type[0].toUpperCase() + type.slice(1) : 'Reminder' },
      { label: 'Scheduled time', value: time },
      { label: 'Timezone', value: timezone }
    ],
    ctaLabel: 'Open reminders',
    ctaUrl: appUrl ? appUrl + '/settings?tab=reminders' : '',
    footerNote: 'CoreX · Fit Zone — Manage your reminder schedule anytime in Settings.'
  });
  return { subject, text, html };
}

export function workoutReminderEmail({
  name,
  title,
  date,
  time,
  timezone,
  duration,
  category,
  appUrl
}) {
  const subject = 'CoreX workout reminder · ' + title;
  const text =
    'Time for your scheduled workout: ' +
    title +
    '\nScheduled for ' +
    date +
    ' at ' +
    time +
    ' (' +
    timezone +
    ').\nDuration: ' +
    (duration || 0) +
    ' min.' +
    (appUrl ? '\nOpen workouts: ' + appUrl + '/workouts' : '');
  const html = renderEmailLayout({
    preheader: 'Time for ' + title + ' (' + date + ' at ' + time + ').',
    eyebrow: 'WORKOUT REMINDER',
    title,
    intro:
      (name ? 'Hi ' + name + ', it' : 'It') +
      ' is time for your scheduled workout session. A short session is still a step forward.',
    details: [
      { label: 'Date', value: date },
      { label: 'Scheduled time', value: time + ' (' + timezone + ')' },
      {
        label: 'Category',
        value: category ? category[0].toUpperCase() + category.slice(1) : 'Workout'
      },
      { label: 'Planned duration', value: (duration || 0) + ' min' }
    ],
    ctaLabel: 'View workout in CoreX',
    ctaUrl: appUrl ? appUrl + '/workouts' : '',
    footerNote: 'CoreX · Fit Zone — One day at a time.'
  });
  return { subject, text, html };
}

export function supportTicketEmail({ ticketId, fromEmail, fromName, topic, subject: title, message }) {
  const subject = 'CoreX support: ' + title;
  const text =
    'Ticket: ' +
    ticketId +
    '\nFrom: ' +
    fromEmail +
    '\nTopic: ' +
    topic +
    '\n\n' +
    message;
  const html = renderEmailLayout({
    preheader: 'Support ticket ' + ticketId + ' from ' + fromEmail,
    eyebrow: 'SUPPORT TICKET',
    title,
    intro: 'A new support message was submitted through CoreX.',
    details: [
      { label: 'Ticket ID', value: ticketId },
      { label: 'From', value: fromName ? fromName + ' (' + fromEmail + ')' : fromEmail },
      { label: 'Topic', value: topic }
    ],
    bodyHtml:
      '<div style="padding:16px 18px;background:#f7f8fc;border:1px solid #e9ebf1;border-radius:12px;">' +
      formatParagraphsHtml(message) +
      '</div>',
    footerNote: 'CoreX · Fit Zone — Support Inbox Delivery'
  });
  return { subject, text, html };
}

export function genericEmail({ subject, text }) {
  const html = renderEmailLayout({
    preheader: subject,
    eyebrow: 'COREX NOTIFICATION',
    title: subject,
    bodyHtml: formatParagraphsHtml(text)
  });
  return { subject, text, html };
}
