import Reminder from '../models/Reminder.js';
import Workout from '../models/Workout.js';
import User from '../models/User.js';
import { localDate, localTime, safeTimezone, zonedDateTimeToUtc } from '../utils/dates.js';
import { notify } from './notifications.js';
import { reminderEmail, workoutReminderEmail } from './emailTemplates.js';

const MAX_WORKOUT_CATCHUP_MS = 24 * 60 * 60 * 1000;

async function sendNotificationEmail({ email, user, subject, content, context }) {
  if (!email.enabled) return { sent: false, error: 'SMTP is not configured.' };
  if (!user.email) return { sent: false, error: 'User has no email address.' };
  if (user.settings?.notifications?.email === false) {
    return { sent: false, error: 'User disabled email notifications.' };
  }
  try {
    await email.send(user.email, subject, content);
    return { sent: true, error: '' };
  } catch (error) {
    const message = error?.message || 'Email delivery failed';
    console.error(
      JSON.stringify({
        level: 'error',
        service: 'reminders',
        context,
        userId: user._id?.toString(),
        code: error?.code || '',
        responseCode: error?.responseCode || null,
        message
      })
    );
    return { sent: false, error: message };
  }
}

async function processRecurringReminders(email, now, appUrl) {
  const cursor = Reminder.find({ enabled: true }).cursor();
  for await (const reminder of cursor) {
    try {
      const user = await User.findById(reminder.userId);
      if (!user) continue;
      const timezone = safeTimezone(user.settings?.timezone);
      const date = localDate(timezone, now);
      const day = new Date(date + 'T12:00:00Z').getUTCDay();
      const time = localTime(timezone, now);
      if (!reminder.days.includes(day) || time < reminder.time) continue;
      const claimed = await Reminder.findOneAndUpdate(
        {
          _id: reminder._id,
          enabled: true,
          lastSentDate: { $ne: date }
        },
        { lastSentDate: date }
      );
      if (!claimed) continue;
      await notify(
        user,
        'reminder',
        reminder.title,
        'Scheduled for ' + reminder.time + ' · ' + timezone,
        '/settings?tab=reminders',
        'reminder:' + reminder._id + ':' + date
      );
      if (reminder.email) {
        const mail = reminderEmail({
          name: user.name,
          title: reminder.title,
          type: reminder.type,
          time: reminder.time,
          timezone,
          appUrl
        });
        const result = await sendNotificationEmail({
          email,
          user,
          subject: mail.subject,
          content: mail,
          context: 'recurring-reminder:' + reminder._id
        });
        if (result.sent) {
          await Reminder.updateOne(
            { _id: reminder._id },
            { $set: { lastEmailAt: now, lastEmailError: '' } }
          );
        } else if (email.enabled && user.settings?.notifications?.email !== false) {
          await Reminder.updateOne(
            { _id: reminder._id },
            { $set: { lastEmailError: result.error } }
          );
        }
      }
    } catch (error) {
      console.error(
        JSON.stringify({
          level: 'error',
          service: 'reminders',
          context: 'recurring-reminder-loop',
          reminderId: reminder?._id?.toString(),
          message: error?.message || 'Unexpected reminder processing error'
        })
      );
    }
  }
}

async function processScheduledWorkouts(email, now, appUrl) {
  const cursor = Workout.find({
    kind: 'session',
    reminderEnabled: true,
    reminderSentAt: null
  }).cursor();
  for await (const workout of cursor) {
    try {
      if (!workout.date || !workout.scheduledTime) continue;
      const user = await User.findById(workout.userId);
      if (!user) continue;
      const timezone = safeTimezone(user.settings?.timezone);
      const scheduledAt = zonedDateTimeToUtc(workout.date, workout.scheduledTime, timezone);
      const elapsedMs = now.getTime() - scheduledAt.getTime();
      if (elapsedMs < 0 || elapsedMs > MAX_WORKOUT_CATCHUP_MS) continue;
      const claimed = await Workout.findOneAndUpdate(
        {
          _id: workout._id,
          reminderEnabled: true,
          reminderSentAt: null
        },
        { $set: { reminderSentAt: now } }
      );
      if (!claimed) continue;
      await notify(
        user,
        'reminder',
        'Scheduled workout · ' + workout.title,
        'Scheduled for ' + workout.date + ' at ' + workout.scheduledTime + ' · ' + timezone,
        '/workouts',
        'workout-reminder:' + workout._id + ':' + workout.date + ':' + workout.scheduledTime
      );
      if (workout.reminderEmail !== false) {
        const mail = workoutReminderEmail({
          name: user.name,
          title: workout.title,
          date: workout.date,
          time: workout.scheduledTime,
          timezone,
          duration: workout.duration,
          category: workout.category,
          appUrl
        });
        const result = await sendNotificationEmail({
          email,
          user,
          subject: mail.subject,
          content: mail,
          context: 'workout-reminder:' + workout._id
        });
        if (!result.sent && email.enabled && user.settings?.notifications?.email !== false) {
          await Workout.updateOne(
            { _id: workout._id },
            { $set: { reminderEmailError: result.error } }
          );
        } else if (result.sent && workout.reminderEmailError) {
          await Workout.updateOne({ _id: workout._id }, { $set: { reminderEmailError: '' } });
        }
      }
    } catch (error) {
      console.error(
        JSON.stringify({
          level: 'error',
          service: 'reminders',
          context: 'scheduled-workout-loop',
          workoutId: workout?._id?.toString(),
          message: error?.message || 'Unexpected workout reminder error'
        })
      );
    }
  }
}

export async function runReminders(email, now = new Date(), appUrl = 'http://localhost:5173') {
  await processRecurringReminders(email, now, appUrl);
  await processScheduledWorkouts(email, now, appUrl);
}

export function startReminderWorker(email, appUrl = 'http://localhost:5173') {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await runReminders(email, new Date(), appUrl);
    } catch (error) {
      console.error(
        JSON.stringify({
          level: 'error',
          service: 'reminders',
          context: 'worker-tick',
          message: error?.message || 'Reminder worker failed'
        })
      );
    } finally {
      running = false;
    }
  };
  const timer = setInterval(tick, 15000);
  timer.unref();
  tick();
  return () => clearInterval(timer);
}
