import Progress from '../models/Progress.js';
import { dateFilter, literalRegex, pagination } from '../utils/dates.js';
import { requireResult } from '../utils/errors.js';

export async function listProgress(req, res) {
  const query = req.filters;
  const filter = { userId: req.user._id, ...dateFilter(query) };
  if (query.metric) filter.metric = query.metric;
  if (query.q) {
    const pattern = { $regex: literalRegex(query.q), $options: 'i' };
    filter.$or = [{ exercise: pattern }, { notes: pattern }];
  }
  const { page, limit, skip } = pagination(query);
  const [items, total] = await Promise.all([
    Progress.find(filter).sort({ date: -1, createdAt: -1 }).skip(skip).limit(limit),
    Progress.countDocuments(filter)
  ]);
  res.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}
export async function createProgress(req, res) {
  const item = await Progress.create({ ...req.body, userId: req.user._id });
  res.status(201).json({ item, message: 'Progress logged.' });
}
export async function updateProgress(req, res) {
  const item = requireResult(
    await Progress.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, req.body, {
      new: true
    })
  );
  res.json({ item, message: 'Progress updated.' });
}
export async function deleteProgress(req, res) {
  requireResult(await Progress.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Progress deleted.' });
}
