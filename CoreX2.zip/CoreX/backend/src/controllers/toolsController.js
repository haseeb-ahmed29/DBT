import Reminder from '../models/Reminder.js';
import Notification from '../models/Notification.js';
import SupportTicket from '../models/SupportTicket.js';
import { requireResult } from '../utils/errors.js';
import { supportTicketEmail } from '../services/emailTemplates.js';

export const listReminders = async (req, res) =>
  res.json({ items: await Reminder.find({ userId: req.user._id }).sort({ time: 1 }) });
export const createReminder = async (req, res) =>
  res.status(201).json({ item: await Reminder.create({ ...req.body, userId: req.user._id }) });
export const updateReminder = async (req, res) => {
  const existing = requireResult(
    await Reminder.findOne({ _id: req.params.id, userId: req.user._id })
  );
  const sameDays =
    existing.days.length === req.body.days.length &&
    [...existing.days].sort().every((d, idx) => d === [...req.body.days].sort()[idx]);
  const scheduleChanged =
    existing.time !== req.body.time ||
    !sameDays ||
    (!existing.enabled && req.body.enabled);
  const update = {
    ...req.body,
    lastEmailError: '',
    ...(scheduleChanged ? { $unset: { lastSentDate: '' } } : {})
  };
  const item = requireResult(
    await Reminder.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, update, {
      new: true
    })
  );
  res.json({ item });
};
export const deleteReminder = async (req, res) => {
  requireResult(await Reminder.findOneAndDelete({ _id: req.params.id, userId: req.user._id }));
  res.json({ message: 'Reminder deleted.' });
};
export const listNotifications = async (req, res) => {
  const [items, unread] = await Promise.all([
    Notification.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(50),
    Notification.countDocuments({ userId: req.user._id, read: false })
  ]);
  res.json({ items, unread });
};
export const markNotification = async (req, res) => {
  requireResult(
    await Notification.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      { read: true }
    )
  );
  res.json({ message: 'Marked as read.' });
};
export const markAllNotifications = async (req, res) => {
  await Notification.updateMany({ userId: req.user._id, read: false }, { read: true });
  res.json({ message: 'All marked as read.' });
};
export function supportController({ email, config }) {
  return async (req, res) => {
    const ticket = await SupportTicket.create({ ...req.body, userId: req.user._id });
    if (
      email.enabled &&
      config.smtp.supportEmail &&
      !config.smtp.supportEmail.includes('example.com')
    ) {
      try {
        const supportMail = supportTicketEmail({
          ticketId: ticket.id,
          fromEmail: req.user.email,
          fromName: req.user.name,
          topic: ticket.topic,
          subject: ticket.subject,
          message: ticket.message
        });
        await email.send(config.smtp.supportEmail, supportMail.subject, supportMail);
        ticket.emailSent = true;
        await ticket.save();
      } catch (error) {
        console.error(
          'Support email delivery failed; ticket remains saved:',
          error?.message || error
        );
      }
    }
    res
      .status(201)
      .json({
        message: ticket.emailSent
          ? 'Your message has been sent to support.'
          : 'Your message is saved. Email delivery is not available yet.',
        ticketId: ticket.id,
        emailSent: ticket.emailSent
      });
  };
}
