import Workout from '../models/Workout.js';
import Meal from '../models/Meal.js';
import Progress from '../models/Progress.js';
import { dateFilter } from '../utils/dates.js';
import { toCsv, sendPdf } from '../services/reports.js';
import { ApiError } from '../utils/errors.js';
export async function report(req, res) {
  const type = req.filters.type || 'all';
  const format = req.filters.format || 'csv';
  const query = { userId: req.user._id, ...dateFilter(req.filters) };
  const collections = { workouts: Workout, nutrition: Meal, progress: Progress };
  const data = {};
  for (const [name, model] of Object.entries(collections)) {
    if (type === 'all' || type === name) {
      data[name] = await model
        .find(query)
        .sort({ date: 1, createdAt: 1 })
        .limit(10001)
        .select('-userId -__v')
        .lean();
      if (data[name].length > 10000)
        throw new ApiError(
          400,
          'Choose a shorter date range (maximum 10,000 records per category).'
        );
    }
  }
  const rows = [['Category', 'Date', 'Item', 'Value', 'Unit / details']];
  for (const w of data.workouts || [])
    rows.push([
      'Workout',
      w.date,
      w.title,
      w.duration,
      'minutes; ' +
        w.kind +
        '; ' +
        w.status +
        '; ' +
        w.exercises
          .map((e) => e.name + ': ' + e.sets + 'x' + e.reps + ', ' + e.weightKg + 'kg')
          .join('; ')
    ]);
  for (const m of data.nutrition || [])
    rows.push([
      'Nutrition',
      m.date,
      m.mealType,
      m.calories,
      'kcal; P ' +
        m.protein +
        'g; C ' +
        m.carbs +
        'g; F ' +
        m.fat +
        'g; ' +
        m.foods.map((f) => f.name + ' (' + f.quantity + ')').join('; ')
    ]);
  for (const p of data.progress || [])
    rows.push([
      'Progress',
      p.date,
      p.metric + (p.exercise ? ': ' + p.exercise : ''),
      p.value,
      ['weight', 'lift'].includes(p.metric)
        ? 'kg'
        : p.metric === 'runTime'
          ? 'minutes (fixed route)'
          : 'cm'
    ]);
  res.attachment('corex-' + type + '.' + format).set('Cache-Control', 'no-store');
  if (format === 'json')
    return res.json({
      exportedAt: new Date().toISOString(),
      units: 'Canonical metric units: kg, cm, km, minutes.',
      ...data
    });
  if (format === 'pdf')
    return sendPdf(
      res,
      rows,
      req.user,
      (req.filters.from || 'Beginning') + ' to ' + (req.filters.to || 'Latest')
    );
  res.type('text/csv; charset=utf-8').send(toCsv(rows));
}
