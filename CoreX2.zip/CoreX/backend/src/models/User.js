import mongoose from 'mongoose';

const schema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true, lowercase: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    passwordHash: { type: String, required: true, select: false },
    sessionVersion: { type: Number, default: 0 },
    avatar: { publicId: String, version: Number, url: String },
    consentAt: { type: Date, required: true },
    discoverable: { type: Boolean, default: false },
    settings: {
      units: { type: String, enum: ['metric', 'imperial'], default: 'metric' },
      theme: { type: String, enum: ['light', 'dark'], default: 'light' },
      timezone: { type: String, default: 'Asia/Karachi' },
      notifications: {
        workout: { type: Boolean, default: true },
        goal: { type: Boolean, default: true },
        reminder: { type: Boolean, default: true },
        follow: { type: Boolean, default: true },
        forum: { type: Boolean, default: true },
        email: { type: Boolean, default: true }
      }
    },
    goals: {
      weeklyWorkouts: { type: Number, default: 4 },
      dailyCalories: { type: Number, default: 2000 },
      targetWeight: { type: Number, default: null }
    }
  },
  { timestamps: true }
);

export default mongoose.model('User', schema);
