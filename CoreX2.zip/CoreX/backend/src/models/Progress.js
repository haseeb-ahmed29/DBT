import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: String,
    metric: {
      type: String,
      enum: ['weight', 'waist', 'chest', 'hips', 'runTime', 'lift'],
      required: true
    },
    value: Number,
    exercise: String,
    notes: String
  },
  { timestamps: true }
);
schema.index({ userId: 1, metric: 1, date: -1 });
export default mongoose.model('Progress', schema);
