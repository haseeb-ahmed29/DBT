import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    topic: String,
    subject: String,
    message: String,
    emailSent: { type: Boolean, default: false }
  },
  { timestamps: true }
);
schema.index({ userId: 1, createdAt: -1 });
export default mongoose.model('SupportTicket', schema);
