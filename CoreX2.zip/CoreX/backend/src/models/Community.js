import mongoose from 'mongoose';
const id = mongoose.Schema.Types.ObjectId;
const follow = new mongoose.Schema(
  { follower: { type: id, ref: 'User' }, following: { type: id, ref: 'User' } },
  { timestamps: true }
);
follow.index({ follower: 1, following: 1 }, { unique: true });
const post = new mongoose.Schema(
  { userId: { type: id, ref: 'User' }, title: String, body: String },
  { timestamps: true }
);
post.index({ createdAt: -1 });
const reply = new mongoose.Schema(
  { postId: { type: id, ref: 'Post' }, userId: { type: id, ref: 'User' }, body: String },
  { timestamps: true }
);
reply.index({ postId: 1, createdAt: 1 });
export const Follow = mongoose.model('Follow', follow);
export const Post = mongoose.model('Post', post);
export const Reply = mongoose.model('Reply', reply);
