import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  purpose: { type: String, enum: ['reset', 'verify'], required: true },
  digest: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true },
  sessionVersion: Number,
  email: String
});
schema.index({ userId: 1, purpose: 1 }, { unique: true });
schema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
export default mongoose.model('AuthToken', schema);
