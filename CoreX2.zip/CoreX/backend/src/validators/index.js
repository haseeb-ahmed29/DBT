import { z } from 'zod';

const text = (max) => z.string().trim().min(1).max(max);
const note = z.string().trim().max(1500).default('');
const positive = z.number().finite().min(0).max(100000);
export const password = z.string().min(10, 'Use at least 10 characters.').max(128);
export const date = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((value) => {
    const parsed = new Date(value + 'T12:00:00Z');
    return !isNaN(parsed) && parsed.toISOString().slice(0, 10) === value;
  }, 'Use a valid date.');
export const registerSchema = z.object({
  name: text(80),
  username: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9_.]{3,30}$/, 'Username must be 3–30 letters, numbers, dots or underscores.'),
  email: z.email().trim().toLowerCase().max(254),
  password,
  consent: z.literal(true)
});
export const loginSchema = z.object({
  identifier: text(254),
  password: z.string().min(1).max(128)
});
export const emailSchema = z.object({ email: z.email().trim().toLowerCase().max(254) });
export const resetSchema = z.object({ token: z.string().regex(/^[a-f0-9]{64}$/), password });
export const profileSchema = registerSchema
  .pick({ name: true, username: true, email: true })
  .extend({ currentPassword: z.string().max(128).optional(), discoverable: z.boolean() });
export const passwordSchema = z.object({
  currentPassword: z.string().min(1).max(128),
  newPassword: password
});
export const preferencesSchema = z.object({
  units: z.enum(['metric', 'imperial']),
  theme: z.enum(['light', 'dark']),
  timezone: text(80).refine((value) => {
    try {
      new Intl.DateTimeFormat('en', { timeZone: value });
      return true;
    } catch {
      return false;
    }
  }, 'Choose a valid timezone.'),
  notifications: z.object({
    workout: z.boolean(),
    goal: z.boolean(),
    reminder: z.boolean(),
    follow: z.boolean(),
    forum: z.boolean(),
    email: z.boolean()
  }),
  goals: z.object({
    weeklyWorkouts: z.number().int().min(1).max(30),
    dailyCalories: z.number().int().min(1).max(20000),
    targetWeight: z.number().min(1).max(600).nullable()
  })
});
const exercise = z.object({
  name: text(100),
  sets: z.number().int().min(0).max(100),
  reps: z.number().int().min(0).max(1000),
  weightKg: positive,
  restSeconds: z.number().int().min(0).max(86400).optional(),
  distanceKm: positive,
  minutes: positive,
  notes: note
});
export const workoutSchema = z
  .object({
    kind: z.enum(['session', 'routine']),
    title: text(100),
    date,
    category: z.enum(['strength', 'cardio', 'mobility', 'other']),
    tags: z.array(text(25)).max(8).default([]),
    notes: note,
    status: z.enum(['planned', 'completed']),
    duration: z.number().min(0).max(1440),
    scheduledTime: z
      .string()
      .regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Use HH:MM 24-hour time.')
      .or(z.literal(''))
      .default(''),
    reminderEnabled: z.boolean().default(false),
    reminderEmail: z.boolean().default(true),
    exercises: z.array(exercise).min(1).max(40)
  })
  .refine((value) => !value.reminderEnabled || value.kind === 'session', {
    path: ['reminderEnabled'],
    message: 'Scheduled reminders are available for workout sessions.'
  })
  .refine((value) => !value.reminderEnabled || value.scheduledTime.length > 0, {
    path: ['scheduledTime'],
    message: 'Choose a scheduled time for the workout reminder.'
  });
export const mealSchema = z.object({
  date,
  mealType: z.enum(['breakfast', 'lunch', 'dinner', 'snack']),
  notes: note,
  foods: z
    .array(
      z.object({
        name: text(100),
        quantity: text(80),
        calories: positive,
        protein: positive,
        carbs: positive,
        fat: positive
      })
    )
    .min(1)
    .max(40)
});
export const progressSchema = z
  .object({
    date,
    metric: z.enum(['weight', 'waist', 'chest', 'hips', 'runTime', 'lift']),
    value: z.number().finite().positive().max(100000),
    exercise: z.string().trim().max(100).default(''),
    notes: note
  })
  .refine((value) => value.metric !== 'lift' || value.exercise.length > 0, {
    path: ['exercise'],
    message: 'Enter an exercise name for a lift.'
  });
export const reminderSchema = z.object({
  title: text(100),
  type: z.enum(['workout', 'meal', 'goal']),
  time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  days: z
    .array(z.number().int().min(0).max(6))
    .min(1)
    .max(7)
    .transform((days) => [...new Set(days)]),
  enabled: z.boolean(),
  email: z.boolean()
});
export const supportSchema = z.object({
  topic: z.enum(['issue', 'feedback', 'question']),
  subject: text(100),
  message: text(3000)
});
export const postSchema = z.object({ title: text(100), body: text(2000) });
export const replySchema = z.object({ body: text(1500) });
export const querySchema = z
  .object({
    q: z.string().trim().max(100).default(''),
    from: date.optional(),
    to: date.optional(),
    page: z.coerce.number().int().min(1).max(10000).default(1),
    limit: z.coerce.number().int().min(1).max(100).default(20),
    category: z.enum(['strength', 'cardio', 'mobility', 'other']).optional(),
    kind: z.enum(['session', 'routine']).optional(),
    status: z.enum(['planned', 'completed']).optional(),
    mealType: z.enum(['breakfast', 'lunch', 'dinner', 'snack']).optional(),
    metric: z.enum(['weight', 'waist', 'chest', 'hips', 'runTime', 'lift']).optional(),
    format: z.enum(['csv', 'pdf', 'json']).optional(),
    type: z.enum(['workouts', 'nutrition', 'progress', 'all']).optional()
  })
  .refine((value) => !value.from || !value.to || value.from <= value.to, {
    message: 'Start date must be before end date.'
  });
